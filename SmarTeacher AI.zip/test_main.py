"""
Test script for SMART TEACHER AI main application.

This script tests the functionality of the integrated SMART TEACHER AI system.
"""

import os
import sys
import json
import unittest
from typing import Dict, List, Any

# Add parent directory to path to import main module
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from smart_teacher_ai.main import SmartTeacherAI

class TestSmartTeacherAI(unittest.TestCase):
    """Test cases for the SMART TEACHER AI main application."""
    
    def setUp(self):
        """Set up test environment."""
        self.smart_teacher = SmartTeacherAI()
        
        # Sample data for testing
        self.student_info = {
            "name": "John Doe",
            "id": "001",
            "class": "Form 4A",
            "admission_number": "F4A001",
            "gender": "Male",
            "date_of_birth": "2008-05-15",
            "parent_name": "Mr. and Mrs. Doe",
            "parent_email": "doe@example.com",
            "parent_phone": "123-456-7890",
            "address": "123 Main Street, City"
        }
        
        self.class_data = {
            "class_info": {"name": "Form 4A", "term": "Term 1", "year": "2025"},
            "subjects": ["Mathematics", "English", "Biology", "Physics", "Chemistry"],
            "students": [
                {
                    "id": "001",
                    "name": "John Doe",
                    "marks": {"Mathematics": 85, "English": 78, "Biology": 92, "Physics": 88, "Chemistry": 90}
                },
                {
                    "id": "002",
                    "name": "Jane Smith",
                    "marks": {"Mathematics": 92, "English": 85, "Biology": 78, "Physics": 76, "Chemistry": 82}
                },
                {
                    "id": "003",
                    "name": "Bob Johnson",
                    "marks": {"Mathematics": 65, "English": 72, "Biology": 68, "Physics": 70, "Chemistry": 75}
                }
            ]
        }
        
        self.term_data = {
            "term": "Term 1",
            "academic_year": "2025",
            "start_date": "2025-01-15",
            "end_date": "2025-04-15",
            "next_term_begins": "2025-05-10",
            "subjects": [
                {
                    "name": "Mathematics",
                    "mark": 85,
                    "grade": "A",
                    "comment": "Excellent performance in Mathematics. Shows strong analytical skills."
                },
                {
                    "name": "English",
                    "mark": 78,
                    "grade": "B+",
                    "comment": "Good performance in English. Writing skills are improving."
                },
                {
                    "name": "Biology",
                    "mark": 92,
                    "grade": "A+",
                    "comment": "Outstanding performance in Biology. Shows exceptional understanding of concepts."
                },
                {
                    "name": "Physics",
                    "mark": 88,
                    "grade": "A",
                    "comment": "Very good performance in Physics. Demonstrates strong problem-solving abilities."
                },
                {
                    "name": "Chemistry",
                    "mark": 90,
                    "grade": "A+",
                    "comment": "Excellent performance in Chemistry. Lab work is particularly impressive."
                }
            ]
        }
        
        self.teacher_info = {
            "name": "Jane Smith",
            "title": "Form 4A Class Teacher",
            "email": "jsmith@example.edu",
            "contact": "jsmith@example.edu, Tel: 098-765-4321"
        }
    
    def test_lesson_plan_generator(self):
        """Test the Lesson Plan Generator module."""
        print("\nTesting Lesson Plan Generator...")
        
        # Test generating a lesson plan
        lesson_plan_result = self.smart_teacher.generate_lesson_plan(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            duration=40,
            objectives=[
                "Define photosynthesis and explain its importance",
                "Identify the reactants and products of photosynthesis",
                "Describe the process of photosynthesis in plants"
            ]
        )
        
        # Verify the result
        self.assertIn("lesson_plan", lesson_plan_result)
        lesson_plan = lesson_plan_result["lesson_plan"]
        self.assertEqual(lesson_plan["metadata"]["subject"], "Biology")
        self.assertEqual(lesson_plan["metadata"]["topic"], "Photosynthesis")
        self.assertEqual(lesson_plan["metadata"]["class_level"], "Form 2")
        self.assertEqual(lesson_plan["metadata"]["duration"], 40)
        
        print("✓ Lesson Plan Generator test passed")
        
        # Test generating a scheme of work
        scheme_result = self.smart_teacher.generate_scheme_of_work(
            subject="Biology",
            class_level="Form 2",
            term="Term 1",
            weeks=10
        )
        
        # Verify the result
        self.assertIn("scheme_of_work", scheme_result)
        scheme = scheme_result["scheme_of_work"]
        self.assertEqual(scheme["metadata"]["subject"], "Biology")
        self.assertEqual(scheme["metadata"]["class_level"], "Form 2")
        self.assertEqual(scheme["metadata"]["term"], "Term 1")
        self.assertEqual(scheme["metadata"]["weeks"], 10)
        self.assertEqual(len(scheme["weekly_plans"]), 10)
        
        print("✓ Scheme of Work Generator test passed")
    
    def test_teaching_materials_assistant(self):
        """Test the Teaching Materials Assistant module."""
        print("\nTesting Teaching Materials Assistant...")
        
        # Test generating teaching notes
        notes_result = self.smart_teacher.generate_teaching_notes(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            template_type="standard",
            length="medium"
        )
        
        # Verify the result
        self.assertIn("teaching_notes", notes_result)
        notes = notes_result["teaching_notes"]
        self.assertEqual(notes["metadata"]["subject"], "Biology")
        self.assertEqual(notes["metadata"]["topic"], "Photosynthesis")
        self.assertEqual(notes["metadata"]["class_level"], "Form 2")
        self.assertEqual(notes["metadata"]["template_type"], "standard")
        self.assertEqual(notes["metadata"]["length"], "medium")
        
        print("✓ Teaching Notes Generator test passed")
        
        # Test generating a handout
        handout_result = self.smart_teacher.generate_handout(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            handout_type="worksheet"
        )
        
        # Verify the result
        self.assertIn("handout", handout_result)
        handout = handout_result["handout"]
        self.assertEqual(handout["metadata"]["subject"], "Biology")
        self.assertEqual(handout["metadata"]["topic"], "Photosynthesis")
        self.assertEqual(handout["metadata"]["class_level"], "Form 2")
        self.assertEqual(handout["metadata"]["handout_type"], "worksheet")
        
        print("✓ Handout Generator test passed")
        
        # Test generating a presentation
        presentation_result = self.smart_teacher.generate_presentation(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            presentation_type="standard",
            num_slides=10
        )
        
        # Verify the result
        self.assertIn("presentation", presentation_result)
        presentation = presentation_result["presentation"]
        self.assertEqual(presentation["metadata"]["subject"], "Biology")
        self.assertEqual(presentation["metadata"]["topic"], "Photosynthesis")
        self.assertEqual(presentation["metadata"]["class_level"], "Form 2")
        self.assertEqual(presentation["metadata"]["presentation_type"], "standard")
        self.assertEqual(presentation["metadata"]["num_slides"], 10)
        
        print("✓ Presentation Generator test passed")
        
        # Test suggesting videos
        videos_result = self.smart_teacher.suggest_videos(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            num_suggestions=5
        )
        
        # Verify the result
        self.assertIn("video_suggestions", videos_result)
        videos = videos_result["video_suggestions"]
        self.assertEqual(len(videos), 5)
        
        print("✓ Video Suggestions test passed")
    
    def test_assessment_tools(self):
        """Test the Assessment Tools module."""
        print("\nTesting Assessment Tools...")
        
        # Test generating an assessment
        assessment_result = self.smart_teacher.generate_assessment(
            subject="Biology",
            topic="Photosynthesis",
            class_level="Form 2",
            assessment_type="Quiz",
            difficulty="medium",
            num_questions=5
        )
        
        # Verify the result
        self.assertIn("assessment", assessment_result)
        self.assertIn("answer_key", assessment_result)
        assessment = assessment_result["assessment"]
        answer_key = assessment_result["answer_key"]
        self.assertEqual(assessment["metadata"]["subject"], "Biology")
        self.assertEqual(assessment["metadata"]["topic"], "Photosynthesis")
        self.assertEqual(assessment["metadata"]["class_level"], "Form 2")
        self.assertEqual(assessment["metadata"]["assessment_type"], "Quiz")
        self.assertEqual(assessment["metadata"]["difficulty"], "medium")
        self.assertEqual(assessment["metadata"]["num_questions"], 5)
        self.assertEqual(len(assessment["questions"]), 5)
        
        print("✓ Assessment Generator test passed")
        
        # Test auto-marking
        # Create sample student answers
        student_answers = []
        for i, question in enumerate(assessment["questions"]):
            student_answers.append({
                "question_number": i + 1,
                "answer": question["correct_answer"] if "correct_answer" in question else "Sample Answer",
                "student_info": {"name": "John Doe", "id": "12345"}
            })
        
        marking_result = self.smart_teacher.auto_mark_assessment(
            assessment=assessment,
            student_answers=student_answers
        )
        
        # Verify the result
        self.assertIn("marking_results", marking_result)
        marking_results = marking_result["marking_results"]
        self.assertEqual(marking_results["student_info"]["name"], "John Doe")
        self.assertEqual(marking_results["assessment_info"]["subject"], "Biology")
        self.assertEqual(marking_results["assessment_info"]["topic"], "Photosynthesis")
        
        print("✓ Auto-Marking test passed")
    
    def test_performance_analyzer(self):
        """Test the Performance Analyzer module."""
        print("\nTesting Performance Analyzer...")
        
        # Test analyzing class performance
        class_analysis_result = self.smart_teacher.analyze_class_performance(
            class_data=self.class_data
        )
        
        # Verify the result
        self.assertIn("analysis_results", class_analysis_result)
        self.assertIn("visualizations", class_analysis_result)
        analysis_results = class_analysis_result["analysis_results"]
        self.assertEqual(analysis_results["metadata"]["class_name"], "Form 4A")
        self.assertEqual(analysis_results["metadata"]["term"], "Term 1")
        self.assertEqual(analysis_results["metadata"]["year"], "2025")
        self.assertEqual(analysis_results["metadata"]["num_students"], 3)
        self.assertEqual(analysis_results["metadata"]["num_subjects"], 5)
        
        print("✓ Class Performance Analysis test passed")
        
        # Test analyzing student performance
        student_data = {
            "id": "001",
            "name": "John Doe",
            "class": "Form 4A",
            "term": "Term 1",
            "year": "2025",
            "marks": {"Mathematics": 85, "English": 78, "Biology": 92, "Physics": 88, "Chemistry": 90}
        }
        
        student_analysis_result = self.smart_teacher.analyze_student_performance(
            student_data=student_data,
            class_data=self.class_data
        )
        
        # Verify the result
        self.assertIn("analysis_results", student_analysis_result)
        self.assertIn("visualizations", student_analysis_result)
        analysis_results = student_analysis_result["analysis_results"]
        self.assertEqual(analysis_results["metadata"]["student_id"], "001")
        self.assertEqual(analysis_results["metadata"]["student_name"], "John Doe")
        self.assertEqual(analysis_results["metadata"]["class"], "Form 4A")
        
        print("✓ Student Performance Analysis test passed")
        
        # Test analyzing subject performance
        subject_data = {
            "subject": "Mathematics",
            "class_info": {"name": "Form 4A", "term": "Term 1", "year": "2025"},
            "students": [
                {"id": "001", "name": "John Doe", "mark": 85},
                {"id": "002", "name": "Jane Smith", "mark": 92},
                {"id": "003", "name": "Bob Johnson", "mark": 65}
            ]
        }
        
        subject_analysis_result = self.smart_teacher.analyze_subject_performance(
            subject_data=subject_data
        )
        
        # Verify the result
        self.assertIn("analysis_results", subject_analysis_result)
        self.assertIn("visualizations", subject_analysis_result)
        analysis_results = subject_analysis_result["analysis_results"]
        self.assertEqual(analysis_results["metadata"]["subject"], "Mathematics")
        self.assertEqual(analysis_results["metadata"]["class_name"], "Form 4A")
        
        print("✓ Subject Performance Analysis test passed")
    
    def test_communication_generator(self):
        """Test the Communication Generator module."""
        print("\nTesting Communication Generator...")
        
        # Test generating a parent letter
        content_params = {
            "performance_description": "performing well in most subjects",
            "subject": "Mathematics",
            "specific_achievements": "John has shown particular strength in algebra and problem-solving.",
            "areas_for_improvement": "John needs to work on geometry concepts and showing all steps in his solutions.",
            "suggestions": "Regular practice with geometry problems and maintaining a math journal would be beneficial."
        }
        
        letter_result = self.smart_teacher.generate_parent_letter(
            template_type="academic_progress",
            student_info=self.student_info,
            content_params=content_params,
            teacher_info=self.teacher_info
        )
        
        # Verify the result
        self.assertIn("letter", letter_result)
        letter = letter_result["letter"]
        self.assertEqual(letter["metadata"]["template_type"], "academic_progress")
        self.assertEqual(letter["metadata"]["student_name"], "John Doe")
        self.assertEqual(letter["metadata"]["class"], "Form 4A")
        
        print("✓ Parent Letter Generator test passed")
        
        # Test generating a report comment
        performance_data = {"mark": 85}
        
        comment_result = self.smart_teacher.generate_report_comment(
            student_info=self.student_info,
            subject="Mathematics",
            performance_data=performance_data,
            comment_type="auto",
            length=
(Content truncated due to size limit. Use line ranges to read in chunks)