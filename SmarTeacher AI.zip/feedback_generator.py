"""
Feedback Generator Module for SMART TEACHER AI

This module provides comprehensive feedback generation for essay and non-structured
answer assessments, creating personalized, actionable feedback for students.
"""

import os
import json
import datetime
import random
from typing import Dict, List, Any, Optional, Tuple

class FeedbackGenerator:
    """
    Generates detailed, personalized feedback for essay and non-structured answer assessments.
    Integrates analysis results, rubric assessments, and teacher input to create actionable feedback.
    """
    
    def __init__(self, templates_dir: str = "../data/feedback_templates"):
        """
        Initialize the Feedback Generator.
        
        Args:
            templates_dir: Directory containing feedback templates
        """
        self.templates_dir = templates_dir
        self._ensure_directory_exists()
        self.feedback_templates = self._load_feedback_templates()
        
        # Define feedback components
        self.strength_phrases = [
            "You demonstrated excellent {area}.",
            "Your {area} is a notable strength in this work.",
            "I was particularly impressed with your {area}.",
            "You showed strong skills in {area}.",
            "Your {area} stands out as exceptional."
        ]
        
        self.improvement_phrases = [
            "You could improve your {area} by {suggestion}.",
            "Consider enhancing your {area} through {suggestion}.",
            "Your {area} would benefit from {suggestion}.",
            "To strengthen your {area}, try {suggestion}.",
            "Work on developing your {area} by {suggestion}."
        ]
        
        self.encouragement_phrases = [
            "I can see your effort in this work.",
            "You're making good progress in your understanding.",
            "Keep developing these skills - you're on the right track.",
            "I appreciate the thought you've put into this response.",
            "Your ideas show potential for further development."
        ]
        
        # Learning strategies by skill area
        self.learning_strategies = {
            "content": [
                "reviewing key concepts in your textbook or class notes",
                "creating concept maps to visualize relationships between ideas",
                "discussing the topic with peers to gain different perspectives",
                "researching additional sources to deepen your understanding",
                "practicing explaining the concepts in your own words"
            ],
            "organization": [
                "creating detailed outlines before writing",
                "using topic sentences to begin each paragraph",
                "practicing logical transitions between ideas",
                "studying example essays with strong organizational structures",
                "revising your work with a focus on structure and flow"
            ],
            "language": [
                "reading your work aloud to catch awkward phrasing",
                "using grammar checking tools to identify common errors",
                "expanding your vocabulary through regular reading",
                "practicing varying your sentence structure",
                "keeping a journal of new words and phrases"
            ],
            "analysis": [
                "questioning assumptions in the material you read",
                "considering multiple perspectives on the topic",
                "practicing identifying strengths and weaknesses in arguments",
                "connecting ideas across different subjects or contexts",
                "asking 'why' and 'how' questions about the content"
            ],
            "evidence": [
                "collecting specific examples, quotes, or data to support your points",
                "practicing proper citation methods",
                "evaluating the credibility of sources",
                "incorporating a variety of evidence types",
                "connecting evidence clearly to your claims"
            ]
        }
    
    def _ensure_directory_exists(self):
        """Ensure the templates directory exists."""
        os.makedirs(self.templates_dir, exist_ok=True)
    
    def _load_feedback_templates(self) -> Dict[str, Any]:
        """Load feedback templates from files."""
        templates = {
            "general": {
                "excellent": "Your work demonstrates an exceptional understanding of {topic}. {strengths_summary}. This is an outstanding response that shows mastery of the subject matter.",
                "good": "Your work shows a strong understanding of {topic}. {strengths_summary}. {improvements_summary}. Overall, this is a good response that demonstrates solid knowledge.",
                "satisfactory": "Your work shows a basic understanding of {topic}. {strengths_summary}. {improvements_summary}. With some focused effort on the areas mentioned, you can significantly improve your work.",
                "needs_improvement": "Your work shows some understanding of {topic}, but needs further development. {strengths_summary}. {improvements_summary}. I recommend reviewing the key concepts and seeking additional support if needed."
            },
            "english_essay": {
                "excellent": "Your essay demonstrates sophisticated writing skills and a deep understanding of {topic}. {strengths_summary}. Your writing shows maturity and insight that sets it apart.",
                "good": "Your essay shows strong writing skills and a good understanding of {topic}. {strengths_summary}. {improvements_summary}. With some refinement, your writing could reach an excellent standard.",
                "satisfactory": "Your essay shows adequate writing skills and a basic understanding of {topic}. {strengths_summary}. {improvements_summary}. Focus on these areas to enhance the quality of your writing.",
                "needs_improvement": "Your essay shows developing writing skills but needs significant improvement in several areas. {improvements_summary}. {strengths_summary}. Regular practice and attention to these elements will help you improve."
            },
            "science_explanation": {
                "excellent": "Your explanation demonstrates a comprehensive understanding of {topic} with precise scientific terminology. {strengths_summary}. Your work shows a level of clarity and accuracy that is exemplary.",
                "good": "Your explanation shows a strong understanding of {topic} with good use of scientific terminology. {strengths_summary}. {improvements_summary}. Continue developing these skills to reach excellence.",
                "satisfactory": "Your explanation shows a basic understanding of {topic} with some use of scientific terminology. {strengths_summary}. {improvements_summary}. Focus on these areas to enhance your scientific explanations.",
                "needs_improvement": "Your explanation shows some understanding of {topic} but lacks clarity and scientific precision. {improvements_summary}. {strengths_summary}. Reviewing key scientific concepts and terminology will help you improve."
            },
            "mathematics_problem": {
                "excellent": "Your solution demonstrates exceptional mathematical reasoning and precision. {strengths_summary}. Your work shows a thorough understanding of the mathematical concepts involved.",
                "good": "Your solution shows strong mathematical reasoning with minor errors. {strengths_summary}. {improvements_summary}. With attention to detail, your mathematical work could reach excellence.",
                "satisfactory": "Your solution shows adequate mathematical reasoning but contains some errors. {strengths_summary}. {improvements_summary}. Focus on these areas to strengthen your mathematical skills.",
                "needs_improvement": "Your solution shows some mathematical understanding but contains significant errors. {improvements_summary}. {strengths_summary}. Regular practice and review of fundamental concepts will help you improve."
            },
            "history_essay": {
                "excellent": "Your essay demonstrates comprehensive historical knowledge and sophisticated analysis. {strengths_summary}. Your work shows a nuanced understanding of historical context and significance.",
                "good": "Your essay shows strong historical knowledge and good analytical skills. {strengths_summary}. {improvements_summary}. Developing these aspects will enhance your historical writing.",
                "satisfactory": "Your essay shows adequate historical knowledge with basic analysis. {strengths_summary}. {improvements_summary}. Focus on these areas to deepen your historical understanding and writing.",
                "needs_improvement": "Your essay shows limited historical knowledge and minimal analysis. {improvements_summary}. {strengths_summary}. Reviewing key historical concepts and practicing analytical writing will help you improve."
            }
        }
        
        # In a production environment, this would load from files
        return templates
    
    def generate_comprehensive_feedback(self, 
                                      assessment_results: Dict[str, Any],
                                      text_analysis: Dict[str, Any],
                                      student_info: Optional[Dict[str, Any]] = None,
                                      teacher_notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Generate comprehensive feedback based on assessment results and text analysis.
        
        Args:
            assessment_results: Results from rubric-based assessment
            text_analysis: Results from text analysis
            student_info: Optional information about the student
            teacher_notes: Optional notes from the teacher
            
        Returns:
            Dictionary containing comprehensive feedback
        """
        # Extract key information
        overall_score = assessment_results["overall_score"]["percentage"]
        grade = assessment_results["overall_score"]["grade"]
        criterion_scores = assessment_results["criterion_scores"]
        subject = assessment_results["metadata"].get("subject", "General")
        
        # Determine performance level
        if overall_score >= 85:
            performance_level = "excellent"
        elif overall_score >= 70:
            performance_level = "good"
        elif overall_score >= 50:
            performance_level = "satisfactory"
        else:
            performance_level = "needs_improvement"
        
        # Identify strengths and areas for improvement
        strengths = [cs for cs in criterion_scores if cs["score"] >= 4]
        improvements = [cs for cs in criterion_scores if cs["score"] <= 2]
        
        # Generate summary statements
        strengths_summary = self._generate_strengths_summary(strengths)
        improvements_summary = self._generate_improvements_summary(improvements)
        
        # Select appropriate feedback template
        template_key = self._select_template_key(subject)
        feedback_template = self.feedback_templates[template_key][performance_level]
        
        # Extract topic from text analysis if available
        topic = text_analysis.get("metadata", {}).get("topic", "the subject")
        
        # Fill in the template
        overall_feedback = feedback_template.format(
            topic=topic,
            strengths_summary=strengths_summary,
            improvements_summary=improvements_summary if improvements else "Continue practicing to maintain your high standard"
        )
        
        # Generate specific feedback for each criterion
        criterion_feedback = []
        for cs in criterion_scores:
            criterion_feedback.append({
                "criterion": cs["criterion"],
                "score": f"{cs['score']}/{cs['max_score']}",
                "feedback": cs["feedback"] if "feedback" in cs else self._generate_criterion_feedback(cs, text_analysis)
            })
        
        # Generate learning recommendations
        learning_recommendations = self._generate_learning_recommendations(criterion_scores, text_analysis)
        
        # Generate next steps
        next_steps = self._generate_next_steps(criterion_scores, text_analysis)
        
        # Add personalization if student info is available
        personalized_intro = ""
        if student_info and "name" in student_info:
            personalized_intro = f"Hi {student_info['name']}, "
            
            # Add context-specific personalization
            if "previous_scores" in student_info:
                prev_score = student_info["previous_scores"].get(subject, 0)
                if overall_score > prev_score + 5:
                    personalized_intro += f"I'm really impressed with your improvement in {subject}! "
                elif overall_score < prev_score - 5:
                    personalized_intro += f"I notice this score is lower than your usual performance in {subject}. Let's work together to get back on track. "
            
            if "learning_style" in student_info:
                learning_style = student_info["learning_style"]
                if learning_style == "visual":
                    personalized_intro += "I've included some visual learning strategies in the recommendations below. "
                elif learning_style == "auditory":
                    personalized_intro += "You might find it helpful to discuss these concepts aloud as part of your study strategy. "
                elif learning_style == "kinesthetic":
                    personalized_intro += "Try the hands-on activities in the recommendations to reinforce these concepts. "
        
        # Compile the comprehensive feedback
        feedback = {
            "metadata": {
                "date_generated": datetime.datetime.now().isoformat(),
                "subject": subject,
                "grade": grade,
                "percentage": overall_score
            },
            "summary": {
                "personalized_introduction": personalized_intro,
                "overall_feedback": overall_feedback,
                "performance_level": performance_level
            },
            "detailed_feedback": {
                "criterion_feedback": criterion_feedback,
                "strengths": [{"area": s["criterion"], "comment": s["feedback"]} for s in strengths],
                "areas_for_improvement": [{"area": i["criterion"], "comment": i["feedback"]} for i in improvements]
            },
            "learning_recommendations": learning_recommendations,
            "next_steps": next_steps
        }
        
        # Add teacher notes if provided
        if teacher_notes:
            feedback["teacher_notes"] = teacher_notes
        
        # Add text analysis insights
        feedback["text_analysis_insights"] = self._extract_text_analysis_insights(text_analysis)
        
        return feedback
    
    def generate_quick_feedback(self, 
                              assessment_results: Dict[str, Any],
                              feedback_type: str = "standard") -> Dict[str, Any]:
        """
        Generate quick feedback based on assessment results.
        
        Args:
            assessment_results: Results from rubric-based assessment
            feedback_type: Type of feedback to generate ("brief", "standard", "detailed")
            
        Returns:
            Dictionary containing quick feedback
        """
        # Extract key information
        overall_score = assessment_results["overall_score"]["percentage"]
        grade = assessment_results["overall_score"]["grade"]
        criterion_scores = assessment_results["criterion_scores"]
        
        # Determine performance level
        if overall_score >= 
(Content truncated due to size limit. Use line ranges to read in chunks)