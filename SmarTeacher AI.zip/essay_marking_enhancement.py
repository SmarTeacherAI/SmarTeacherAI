"""
Essay Marking Enhancement Module for SMART TEACHER AI

This module extends the Assessment Tools with advanced capabilities for marking
essays and non-structured answers using AI-powered text analysis.
"""

import os
import json
import datetime
from typing import Dict, List, Any, Optional
import re

class EssayMarkingEnhancement:
    """
    Provides advanced essay and non-structured answer marking capabilities.
    Integrates with AI models to analyze text content and provide detailed feedback.
    """
    
    def __init__(self, rubrics_dir: str = "../templates/rubrics"):
        """
        Initialize the Essay Marking Enhancement module.
        
        Args:
            rubrics_dir: Directory containing marking rubrics
        """
        self.rubrics_dir = rubrics_dir
        self.sample_rubrics = self._load_sample_rubrics()
        
    def _load_sample_rubrics(self) -> Dict[str, Any]:
        """Load sample rubrics for different subjects and levels."""
        # In a production environment, this would load from a database or API
        # For now, we'll use a placeholder with sample rubrics
        return {
            "english_essay": {
                "name": "English Essay Evaluation",
                "description": "Rubric for evaluating English essays",
                "total_marks": 100,
                "criteria": [
                    {
                        "name": "Content and Understanding",
                        "description": "Depth of understanding of the topic and quality of content",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Exceptional depth of understanding with insightful content"},
                            {"score": 4, "description": "Strong understanding with relevant and detailed content"},
                            {"score": 3, "description": "Adequate understanding with mostly relevant content"},
                            {"score": 2, "description": "Limited understanding with some irrelevant content"},
                            {"score": 1, "description": "Poor understanding with mostly irrelevant content"}
                        ]
                    },
                    {
                        "name": "Organization and Structure",
                        "description": "Logical flow and organization of ideas",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Exceptionally well-organized with seamless transitions"},
                            {"score": 4, "description": "Well-organized with clear transitions"},
                            {"score": 3, "description": "Adequately organized with some transitions"},
                            {"score": 2, "description": "Somewhat disorganized with abrupt transitions"},
                            {"score": 1, "description": "Poorly organized with little logical flow"}
                        ]
                    },
                    {
                        "name": "Language and Style",
                        "description": "Grammar, vocabulary, and writing style",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Sophisticated language with flawless grammar"},
                            {"score": 4, "description": "Strong language with minor grammatical errors"},
                            {"score": 3, "description": "Adequate language with some grammatical errors"},
                            {"score": 2, "description": "Limited language with frequent grammatical errors"},
                            {"score": 1, "description": "Poor language with pervasive grammatical errors"}
                        ]
                    },
                    {
                        "name": "Critical Thinking",
                        "description": "Analysis, evaluation, and original insights",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Exceptional analysis with original insights"},
                            {"score": 4, "description": "Strong analysis with some original thinking"},
                            {"score": 3, "description": "Adequate analysis with conventional thinking"},
                            {"score": 2, "description": "Limited analysis with minimal original thought"},
                            {"score": 1, "description": "Poor analysis with no original thinking"}
                        ]
                    },
                    {
                        "name": "Evidence and Support",
                        "description": "Use of examples, quotations, and supporting details",
                        "weight": 0.1,
                        "levels": [
                            {"score": 5, "description": "Comprehensive evidence with excellent integration"},
                            {"score": 4, "description": "Strong evidence with good integration"},
                            {"score": 3, "description": "Adequate evidence with some integration"},
                            {"score": 2, "description": "Limited evidence with poor integration"},
                            {"score": 1, "description": "Minimal or no evidence"}
                        ]
                    }
                ]
            },
            "science_explanation": {
                "name": "Science Explanation Evaluation",
                "description": "Rubric for evaluating scientific explanations",
                "total_marks": 50,
                "criteria": [
                    {
                        "name": "Scientific Accuracy",
                        "description": "Accuracy of scientific concepts and principles",
                        "weight": 0.4,
                        "levels": [
                            {"score": 5, "description": "Completely accurate with precise terminology"},
                            {"score": 4, "description": "Mostly accurate with appropriate terminology"},
                            {"score": 3, "description": "Generally accurate with some terminology errors"},
                            {"score": 2, "description": "Several inaccuracies with terminology problems"},
                            {"score": 1, "description": "Mostly inaccurate with incorrect terminology"}
                        ]
                    },
                    {
                        "name": "Clarity of Explanation",
                        "description": "Clarity and comprehensibility of the explanation",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Exceptionally clear and easy to understand"},
                            {"score": 4, "description": "Clear and mostly easy to understand"},
                            {"score": 3, "description": "Adequately clear with some confusing parts"},
                            {"score": 2, "description": "Somewhat unclear and difficult to follow"},
                            {"score": 1, "description": "Very unclear and confusing"}
                        ]
                    },
                    {
                        "name": "Use of Examples",
                        "description": "Use of relevant examples to illustrate concepts",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Excellent examples that perfectly illustrate concepts"},
                            {"score": 4, "description": "Good examples that clearly illustrate concepts"},
                            {"score": 3, "description": "Adequate examples that somewhat illustrate concepts"},
                            {"score": 2, "description": "Limited examples with weak connection to concepts"},
                            {"score": 1, "description": "No examples or irrelevant examples"}
                        ]
                    },
                    {
                        "name": "Completeness",
                        "description": "Completeness of the explanation covering all aspects",
                        "weight": 0.1,
                        "levels": [
                            {"score": 5, "description": "Comprehensive coverage of all aspects"},
                            {"score": 4, "description": "Thorough coverage of most aspects"},
                            {"score": 3, "description": "Adequate coverage of key aspects"},
                            {"score": 2, "description": "Partial coverage with significant omissions"},
                            {"score": 1, "description": "Minimal coverage with major omissions"}
                        ]
                    }
                ]
            }
        }
    
    def get_available_rubrics(self) -> List[Dict[str, str]]:
        """
        Get a list of available rubrics.
        
        Returns:
            List of dictionaries containing rubric information
        """
        return [
            {"id": rubric_id, "name": rubric["name"], "description": rubric["description"]}
            for rubric_id, rubric in self.sample_rubrics.items()
        ]
    
    def get_rubric_details(self, rubric_id: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific rubric.
        
        Args:
            rubric_id: Identifier for the rubric
            
        Returns:
            Dictionary containing rubric details
        """
        if rubric_id in self.sample_rubrics:
            return self.sample_rubrics[rubric_id]
        else:
            return {"error": f"Rubric '{rubric_id}' not found"}
    
    def create_custom_rubric(self, rubric_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a custom rubric.
        
        Args:
            rubric_data: Dictionary containing rubric information
            
        Returns:
            Dictionary containing the created rubric
        """
        # Validate rubric data
        required_fields = ["name", "description", "total_marks", "criteria"]
        for field in required_fields:
            if field not in rubric_data:
                return {"error": f"Missing required field: {field}"}
        
        # Validate criteria
        for criterion in rubric_data["criteria"]:
            if "name" not in criterion or "weight" not in criterion or "levels" not in criterion:
                return {"error": f"Invalid criterion format: {criterion}"}
        
        # In a production environment, this would save to a database
        # For now, we'll just return the rubric with a generated ID
        rubric_id = f"custom_{len(self.sample_rubrics) + 1}"
        
        # Add timestamp
        rubric_data["created_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        return {
            "rubric_id": rubric_id,
            "rubric": rubric_data
        }
    
    def analyze_essay(self, 
                     essay_text: str, 
                     subject: str, 
                     topic: str, 
                     rubric_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Analyze an essay using AI-powered text analysis.
        
        Args:
            essay_text: The text of the essay to analyze
            subject: The subject of the essay
            topic: The topic of the essay
            rubric_id: Optional identifier for a specific rubric to use
            
        Returns:
            Dictionary containing analysis results
        """
        # In a production environment, this would use an AI model for analysis
        # For now, we'll use rule-based analysis for demonstration
        
        # Select appropriate rubric
        if rubric_id and rubric_id in self.sample_rubrics:
            rubric = self.sample_rubrics[rubric_id]
        elif "english" in subject.lower() or "language" in subject.lower():
            rubric = self.sample_rubrics["english_essay"]
        elif any(s in subject.lower() for s in ["science", "biology", "chemistry", "physics"]):
            rubric = self.sample_rubrics["science_explanation"]
        else:
            rubric = self.sample_rubrics["english_essay"]  # Default to English essay rubric
        
        # Basic text analysis
        word_count = len(essay_text.split())
        sentence_count = len(re.split(r'[.!?]+', essay_text))
        avg_sentence_length = word_count / sentence_count if sentence_count > 0 else 0
        paragraph_count = len(essay_text.split('\n\n'))
        
        # Keyword analysis (in a real implementation, this would be more sophisticated)
        keywords = self._extract_keywords(essay_text, topic)
        
        # Grammar check (simplified)
        grammar_issues = self._check_grammar(essay_text)
        
        # Structure analysis
        has_introduction = self._has_introduction(essay_text)
        has_conclusion = self._has_conclusion(essay_text)
        
        # Generate scores for each criterion
        criterion_scores = []
        total_score = 0
        weighted_total = 0
        
        for criterion in rubric["criteria"]:
            # In a real implementation, this would use AI to determine the appropriate score
            # For now, we'll use a simplified scoring approach
            score = self._calculate_criterion_score(criterion, essay_text, keywords, grammar_issues, 
                                                  has_introduction, has_conclusion, word_count)
            
            weighted_score = score * criterion["weight"] * (rubric["total_marks"] / 5)  # Normalize to total marks
            total_score += weighted_score
            weighted_total += criterion["weight"]
            
            # Find the corresponding level description
            level_description = next((level["description"] for level in criterion["levels"] if level["score"] == score), "")
            
            criterion_scores.append({
                "criterion": criterion["name"],
                "description": criterion["description"],
                "score": score,
                "max_score": 5,
                "weighted_score": weighted_score,
                "level_description": level_description,
                "feedback": self._generate_criterion_feedback(criterion, score, essay_text)
            })
        
        # Calculate final percentage
        percentage = (total_score / rubric["total_marks"]) * 100
        
        # Generate overall feedback
        overall_feedback = self._generate_overall_feedback(criterion_scores, percentage, subject, topic)
        
        # Create the analysis result
        analysis_result = {
            "metadata": {
                "subject": subject,
                "topic": topic,
                "rubric_used": rubric["name"],
                "date_analyzed": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "text_statistics": {
                "word_count": word_count,
                "sentence_count": sentence_count,
                "average_sentence_length": round(avg_sentence_length, 1),
                "paragraph_count": paragraph_count,
                "keywords_used": keywords
            },
            "criterion_scores": criterion_scores,
            "overall_score": {
                "raw_score": round(total_score, 1),
                "total_possible": rubric["total_marks"],
                "percentage": round(percentage, 1),
                "grade": self._calculate_grade(percentage)
            },
            "feedback": {
                "overall_feedback": overall_feedback,
                "grammar_issues": grammar_issues,
                "structure_feedback": self._generate_structure_feedback(has_introduction, has_conclusion, paragraph_count)
            
(Content truncated due to size limit. Use line ranges to read in chunks)