import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

// Components
import TimetableView from '../components/timetables/TimetableView';
import SchoolDataManager from '../components/timetables/SchoolDataManager';
import TimetableGenerator from '../components/timetables/TimetableGenerator';
import TimetableExport from '../components/timetables/TimetableExport';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Alert from '../components/common/Alert';

const Timetables = () => {
  const [activeTab, setActiveTab] = useState('view');
  const [timetables, setTimetables] = useState([]);
  const [selectedTimetable, setSelectedTimetable] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch timetables when component mounts
    fetchTimetables();
  }, []);

  const fetchTimetables = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/api/timetables', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setTimetables(response.data.data);
      
      // Select the first timetable if available
      if (response.data.data.length > 0) {
        setSelectedTimetable(response.data.data[0]);
      }
      
      setError(null);
    } catch (err) {
      console.error('Error fetching timetables:', err);
      setError('Failed to load timetables. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleTimetableSelect = (timetableId) => {
    const selected = timetables.find(t => t.id === timetableId);
    setSelectedTimetable(selected);
  };

  const handleTimetableCreate = async (newTimetable) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('/api/timetables', newTimetable, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // Add the new timetable to the list
      setTimetables([...timetables, response.data.data]);
      
      // Select the newly created timetable
      setSelectedTimetable(response.data.data);
      
      // Switch to view tab
      setActiveTab('view');
      
      setError(null);
    } catch (err) {
      console.error('Error creating timetable:', err);
      setError('Failed to create timetable. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleTimetableGenerate = async (params) => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post('/api/timetables/generate', params, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // Add the generated timetable to the list
      setTimetables([...timetables, response.data.data]);
      
      // Select the newly generated timetable
      setSelectedTimetable(response.data.data);
      
      // Switch to view tab
      setActiveTab('view');
      
      setError(null);
    } catch (err) {
      console.error('Error generating timetable:', err);
      setError('Failed to generate timetable. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  const handleTimetableDelete = async (timetableId) => {
    if (!window.confirm('Are you sure you want to delete this timetable?')) {
      return;
    }
    
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/api/timetables/${timetableId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      // Remove the deleted timetable from the list
      const updatedTimetables = timetables.filter(t => t.id !== timetableId);
      setTimetables(updatedTimetables);
      
      // If the deleted timetable was selected, select another one
      if (selectedTimetable && selectedTimetable.id === timetableId) {
        setSelectedTimetable(updatedTimetables.length > 0 ? updatedTimetables[0] : null);
      }
      
      setError(null);
    } catch (err) {
      console.error('Error deleting timetable:', err);
      setError('Failed to delete timetable. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-fluid py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h1 className="h3">Timetable Generator</h1>
        <div className="btn-group">
          <button 
            className={`btn ${activeTab === 'view' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setActiveTab('view')}
          >
            View Timetables
          </button>
          <button 
            className={`btn ${activeTab === 'generate' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setActiveTab('generate')}
          >
            Generate Timetable
          </button>
          <button 
            className={`btn ${activeTab === 'school-data' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setActiveTab('school-data')}
          >
            Manage School Data
          </button>
          <button 
            className={`btn ${activeTab === 'export' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setActiveTab('export')}
          >
            Export
          </button>
        </div>
      </div>

      {error && <Alert type="danger" message={error} />}

      {loading ? (
        <LoadingSpinner />
      ) : (
        <div className="row">
          {activeTab === 'view' && (
            <TimetableView 
              timetables={timetables} 
              selectedTimetable={selectedTimetable}
              onTimetableSelect={handleTimetableSelect}
              onTimetableDelete={handleTimetableDelete}
            />
          )}
          
          {activeTab === 'generate' && (
            <TimetableGenerator 
              onTimetableGenerate={handleTimetableGenerate}
              onTimetableCreate={handleTimetableCreate}
            />
          )}
          
          {activeTab === 'school-data' && (
            <SchoolDataManager />
          )}
          
          {activeTab === 'export' && (
            <TimetableExport 
              timetables={timetables}
              selectedTimetable={selectedTimetable}
              onTimetableSelect={handleTimetableSelect}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default Timetables;
