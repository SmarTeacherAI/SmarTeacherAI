"""
SMART TEACHER AI - Main Application

This is the main entry point for the SMART TEACHER AI application, which provides
a comprehensive suite of tools to assist teachers with various tasks.
"""

import os
import sys
import argparse
from datetime import datetime

# Import modules
from modules.lesson_plan_generator import LessonPlanGenerator
from modules.teaching_materials_assistant import TeachingMaterialsAssistant
from modules.assessment_tools import AssessmentTools
from modules.performance_analyzer import PerformanceAnalyzer
from modules.communication_generator import CommunicationGenerator
from modules.report_card_generator import ReportCardGenerator
from modules.timetable_generator import TimetableGenerator

# Import essay marking modules
from modules.text_analyzer import TextAnalyzer
from modules.rubric_manager import RubricManager
from modules.essay_marking_enhancement import EssayMarkingEnhancement
from modules.feedback_generator import FeedbackGenerator
from modules.human_verification_workflow import HumanVerificationWorkflow, VerificationInterface

class SmartTeacherAI:
    """
    Main class for the SMART TEACHER AI application.
    Integrates all modules and provides a unified interface.
    """
    
    def __init__(self):
        """Initialize the SMART TEACHER AI application."""
        self.version = "1.0.0"
        self.modules = {}
        self._initialize_modules()
        print(f"SMART TEACHER AI v{self.version} initialized")
        
    def _initialize_modules(self):
        """Initialize all modules."""
        # Core modules
        self.modules["lesson_plan"] = LessonPlanGenerator()
        self.modules["teaching_materials"] = TeachingMaterialsAssistant()
        self.modules["assessment"] = AssessmentTools()
        self.modules["performance"] = PerformanceAnalyzer()
        self.modules["communication"] = CommunicationGenerator()
        self.modules["report_card"] = ReportCardGenerator()
        self.modules["timetable"] = TimetableGenerator()
        
        # Essay marking modules
        self.modules["text_analyzer"] = TextAnalyzer()
        self.modules["rubric_manager"] = RubricManager()
        self.modules["essay_marking"] = EssayMarkingEnhancement()
        self.modules["feedback_generator"] = FeedbackGenerator()
        self.modules["verification"] = HumanVerificationWorkflow()
        self.modules["verification_interface"] = VerificationInterface(self.modules["verification"])
        
        print("All modules initialized successfully")
    
    def run(self):
        """Run the SMART TEACHER AI application."""
        self._display_welcome()
        self._main_menu()
    
    def _display_welcome(self):
        """Display welcome message."""
        print("\n" + "="*60)
        print(f"Welcome to SMART TEACHER AI v{self.version}")
        print("Your comprehensive AI companion for teaching tasks")
        print("="*60)
        print(f"Current date: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        print("="*60 + "\n")
    
    def _main_menu(self):
        """Display main menu and handle user input."""
        while True:
            print("\nMAIN MENU:")
            print("1. Lesson Plan & Scheme of Work Generator")
            print("2. Teaching Materials Assistant")
            print("3. Assessment Tools & Auto-Marking")
            print("4. Essay & Non-Structured Answer Marking")
            print("5. Student Performance Analyzer")
            print("6. Parent Communication Generator")
            print("7. Report Card Generator")
            print("8. Timetable Generator")
            print("9. Settings")
            print("10. Help & Documentation")
            print("0. Exit")
            
            choice = input("\nEnter your choice (0-10): ")
            
            if choice == "1":
                self._lesson_plan_menu()
            elif choice == "2":
                self._teaching_materials_menu()
            elif choice == "3":
                self._assessment_menu()
            elif choice == "4":
                self._essay_marking_menu()
            elif choice == "5":
                self._performance_menu()
            elif choice == "6":
                self._communication_menu()
            elif choice == "7":
                self._report_card_menu()
            elif choice == "8":
                self._timetable_menu()
            elif choice == "9":
                self._settings_menu()
            elif choice == "10":
                self._help_menu()
            elif choice == "0":
                print("\nThank you for using SMART TEACHER AI. Goodbye!")
                sys.exit(0)
            else:
                print("\nInvalid choice. Please try again.")
    
    def _lesson_plan_menu(self):
        """Display lesson plan menu and handle user input."""
        print("\nLESSON PLAN & SCHEME OF WORK GENERATOR")
        print("1. Create New Lesson Plan")
        print("2. Generate Scheme of Work")
        print("3. View Saved Plans")
        print("4. Edit Existing Plan")
        print("5. Export Plan")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["lesson_plan"].create_lesson_plan()
        elif choice == "2":
            self.modules["lesson_plan"].generate_scheme_of_work()
        elif choice == "3":
            self.modules["lesson_plan"].view_saved_plans()
        elif choice == "4":
            self.modules["lesson_plan"].edit_plan()
        elif choice == "5":
            self.modules["lesson_plan"].export_plan()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _teaching_materials_menu(self):
        """Display teaching materials menu and handle user input."""
        print("\nTEACHING MATERIALS ASSISTANT")
        print("1. Generate Lesson Notes")
        print("2. Create Student Handout")
        print("3. Design Presentation Slides")
        print("4. Find Educational Videos")
        print("5. Create Interactive Activities")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["teaching_materials"].generate_notes()
        elif choice == "2":
            self.modules["teaching_materials"].create_handout()
        elif choice == "3":
            self.modules["teaching_materials"].design_presentation()
        elif choice == "4":
            self.modules["teaching_materials"].find_videos()
        elif choice == "5":
            self.modules["teaching_materials"].create_activities()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _assessment_menu(self):
        """Display assessment menu and handle user input."""
        print("\nASSESSMENT TOOLS & AUTO-MARKING")
        print("1. Create Multiple Choice Test")
        print("2. Generate Short Answer Questions")
        print("3. Auto-Mark Submissions")
        print("4. View Assessment Results")
        print("5. Export Results")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["assessment"].create_multiple_choice()
        elif choice == "2":
            self.modules["assessment"].generate_short_answer()
        elif choice == "3":
            self.modules["assessment"].auto_mark()
        elif choice == "4":
            self.modules["assessment"].view_results()
        elif choice == "5":
            self.modules["assessment"].export_results()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _essay_marking_menu(self):
        """Display essay marking menu and handle user input."""
        print("\nESSAY & NON-STRUCTURED ANSWER MARKING")
        print("1. Upload Essay for Analysis")
        print("2. Manage Assessment Rubrics")
        print("3. Review AI-Marked Essays")
        print("4. Generate Student Feedback")
        print("5. View Marking Statistics")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self._upload_essay_workflow()
        elif choice == "2":
            self._manage_rubrics_workflow()
        elif choice == "3":
            self._review_essays_workflow()
        elif choice == "4":
            self._generate_feedback_workflow()
        elif choice == "5":
            self._view_marking_statistics()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _upload_essay_workflow(self):
        """Handle essay upload and analysis workflow."""
        print("\nUPLOAD ESSAY FOR ANALYSIS")
        
        # Get essay details
        subject = input("Subject: ")
        grade_level = input("Grade Level: ")
        title = input("Essay Title: ")
        
        print("\nEnter essay text (type 'END' on a new line when finished):")
        lines = []
        while True:
            line = input()
            if line == "END":
                break
            lines.append(line)
        
        essay_text = "\n".join(lines)
        
        # Analyze essay
        print("\nAnalyzing essay...")
        analysis_result = self.modules["text_analyzer"].analyze_text(
            text=essay_text,
            title=title,
            subject=subject,
            grade_level=grade_level
        )
        
        # Select rubric
        print("\nSelect a rubric for assessment:")
        rubrics = self.modules["rubric_manager"].get_all_rubrics()
        for i, rubric in enumerate(rubrics):
            print(f"{i+1}. {rubric['name']} ({rubric['subject']})")
        
        rubric_choice = int(input("\nEnter rubric number: ")) - 1
        rubric_id = rubrics[rubric_choice]["id"]
        
        # Mark essay
        print("\nMarking essay...")
        marking_result = self.modules["rubric_manager"].apply_rubric(
            rubric_id=rubric_id,
            essay_analysis=analysis_result
        )
        
        # Display results
        print("\nESSAY ASSESSMENT RESULTS")
        print(f"Overall Score: {marking_result['overall_score']['raw_score']}/{marking_result['overall_score']['total_possible']} ({marking_result['overall_score']['percentage']}%)")
        print(f"Grade: {marking_result['overall_score']['grade']}")
        
        print("\nCriterion Scores:")
        for cs in marking_result['criterion_scores']:
            print(f"- {cs['criterion']}: {cs['score']}/{cs['max_score']} ({cs['weighted_score']} points)")
        
        # Create verification task
        print("\nCreating verification task for teacher review...")
        verification_result = self.modules["verification"].create_verification_task(
            assessment_id=f"assessment_{datetime.now().strftime('%Y%m%d%H%M%S')}",
            assessment_results=marking_result,
            essay_text=essay_text,
            priority="normal"
        )
        
        print(f"Verification task created: {verification_result['verification_id']}")
        print("The essay has been queued for teacher verification.")
    
    def _manage_rubrics_workflow(self):
        """Handle rubric management workflow."""
        print("\nMANAGE ASSESSMENT RUBRICS")
        print("1. View Available Rubrics")
        print("2. Create New Rubric")
        print("3. Duplicate Existing Rubric")
        print("4. Delete Rubric")
        print("0. Back to Essay Marking Menu")
        
        choice = input("\nEnter your choice (0-4): ")
        
        if choice == "1":
            rubrics = self.modules["rubric_manager"].get_all_rubrics()
            print("\nAVAILABLE RUBRICS:")
            for i, rubric in enumerate(rubrics):
                print(f"{i+1}. {rubric['name']} ({rubric['subject']}, {rubric['level']})")
        
        elif choice == "2":
            print("\nCREATE NEW RUBRIC")
            subject = input("Subject: ")
            level = input("Education Level: ")
            assessment_type = input("Assessment Type: ")
            
            template = self.modules["rubric_manager"].generate_rubric_template(
                subject=subject,
                level=level,
                assessment_type=assessment_type
            )
            
            print(f"\nTemplate generated: {template['name']}")
            print("Edit the template as needed and save.")
            
            # In a real application, this would open a UI for editing the template
            print("Template editing UI would open here.")
        
        elif choice == "3":
            rubrics = self.modules["rubric_manager"].get_all_rubrics()
            print("\nSELECT RUBRIC TO DUPLICATE:")
            for i, rubric in enumerate(rubrics):
                print(f"{i+1}. {rubric['name']} ({rubric['subject']})")
            
            rubric_choice = int(input("\nEnter rubric number: ")) - 1
            rubric_id = rubrics[rubric_choice]["id"]
            new_name = input("New name for duplicated rubric: ")
            
            result = self.modules["rubric_manager"].duplicate_rubric(
                rubric_id=rubric_id,
                new_name=new_name
            )
            
            if "success" in result:
                print(f"Rubric duplicated successfully: {result['rubric']['name']}")
            else:
                print(f"Error duplicating rubric: {result.get('error', 'Unknown error')}")
        
        elif choice == "4":
            user_rubrics = self.modules["rubric_manager"].get_user_rubrics()
            if not user_rubrics:
                print("\nNo user-created rubrics available to delete.")
                return
                
            print("\nSELECT RUBRIC TO DELETE:")
            for i, rubric in enumerate(user_rubrics):
                print(f"{i+1}. {rubric['name']} ({rubric['subject']})")
            
            rubric_choice = int(input("\nEnter rubric number: ")) - 1
            rubric_id = user_rubrics[rubric_choice]["id"]
            
            confirm = input(f"Are you sure you want to delete '{user_rubrics[rubric_choice]['name']}'? (y/n): ")
            if confirm.lower() == 'y':
                result = self.modules["rubric_manager"].delete_rubric(rubric_id=rubric_id)
                if "success" in result:
                    print("Rubric deleted successfully.")
                else:
                    print(f"Error deleting rubric: {result.get('error', 'Unknown error')}")
            else:
                print("Deletion cancelled.")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _review_essays_workflow(self):
        """Handle essay review workflow."""
        print("\nREVIEW AI-MARKED ESSAYS")
        
        # Get pending verification tasks
        pending_tasks = self.modules["verification"].get_pending_verification_tasks()
        
        if not pending_tasks:
            print("No essays pending review.")
            return
        
        print("\nESSAYS PENDING REVIEW:")
        for i, task in enumerate(pending_tasks):
            print(f"{i+1}. {task.get('subject', 'Unknown')} - {task.get('student_name', 'Unknown Student')} (Priority: {task['priority']})")
        
        task_choice = int(input("\nEnter essay number to review (0 to cancel): "))
        if task_choice == 0:
            return
        
        verification_id = pending_tasks[task_choice-1]["verification_id"]
        
        # Start verification
        self.modules["verification"].start_verification(
            verification_id=verification_id,
            teacher_id="current_teacher"  # In a real app, this would be the logged-in teacher
        )
        
        # Get verification task details
        task_details = self.modules["verification_interface"].get_verification_task_details(verification_id)
        
        # Display essay and assessment
        print("\nESSAY TEXT:")
        print(task_details["essay_text"][:500] + "..." if len(task_details["essay_text"]) > 500 else task_details["essay_text"])
        
        print("\nAI ASSESSMENT:")
        print(f"Overall Score: {task_details['original_assessment']['overall_score']['percentage']}%")
        print(f"Grade: {task_details['original_assessment']['overall_score']['grade']}")
        
        print("\nCRITERION SCORES:")
        for cs in task_details['original_assessment']['criterion_scores']:
            print(f"- {cs['criterion']}: {cs['score']}/{cs['max_score']}")
        
        # Get verification decision
        print("\nVERIFICATION OPTIONS:")
        print("1. Approve without changes")
        print("2. Approve with adjustments")
        print("3. Reject and mark manually")
        print("0. Cancel and return to menu")
        
        decision = input("\nEnter your choice (0-3): ")
        
        if decision == "0":
            return
        elif decision == "1":
            # Approve without changes
            result = self.modules["verification_interface"].submit_teacher_adjustments(
                verification_id=verification_id,
                adjustments={},
                verification_result="approved"
            )
            print("Assessment approved without changes.")
        elif decision == "2":
            # Approve with adjustments
            print("\nPreparing adjustment interface...")
            # In a real application, this would open a UI for making adjustments
            print("Adjustment UI would open here.")
            print("For this demo, we'll simulate some adjustments.")
            
            # Simulate adjustments
            adjustments = {
                "criterion_adjustments": {
                    task_details['original_assessment']['criterion_scores'][0]['criterion']: {
                        "original": task_details['original_assessment']['criterion_scores'][0]['score'],
                        "adjusted": task_details['original_assessment']['criterion_scores'][0]['score'] + 1,
                        "max_score": task_details['original_assessment']['criterion_scores'][0]['max_score'],
                        "original_feedback": "Original feedback would be here.",
                        "adjusted_feedback": "Adjusted feedback would be here."
                    }
                },
                "teacher_notes": "Sample adjustment for demonstration purposes."
            }
            
            result = self.modules["verification_interface"].submit_teacher_adjustments(
                verification_id=verification_id,
                adjustments=adjustments,
                verification_result="adjusted"
            )
            print("Assessment approved with adjustments.")
        elif decision == "3":
            # Reject and mark manually
            result = self.modules["verification_interface"].submit_teacher_adjustments(
                verification_id=verification_id,
                adjustments={},
                verification_result="rejected"
            )
            print("Assessment rejected for manual marking.")
        else:
            print("Invalid choice.")
    
    def _generate_feedback_workflow(self):
        """Handle feedback generation workflow."""
        print("\nGENERATE STUDENT FEEDBACK")
        
        # Get completed verifications
        # In a real application, this would retrieve actual completed verifications
        print("Select an assessment to generate feedback for:")
        print("1. Sample Assessment 1")
        print("2. Sample Assessment 2")
        print("0. Cancel")
        
        choice = input("\nEnter your choice (0-2): ")
        
        if choice == "0":
            return
        
        # In a real application, this would use actual assessment data
        sample_assessment = {
            "metadata": {
                "rubric_id": "default_english_essay",
                "rubric_name": "English Essay Evaluation",
                "subject": "English",
                "level": "Secondary",
                "date_marked": "2025-04-16T12:00:00"
            },
            "criterion_scores": [
                {
                    "criterion": "Content and Understanding",
                    "description": "Depth of understanding of the topic and quality of content",
                    "score": 4,
                    "max_score": 5,
                    "weighted_score": 24.0,
                    "level_description": "Strong understanding with relevant and detailed content",
                    "feedback": "Excellent work on content and understanding. Your understanding of the topic is evident throughout your work."
                },
                {
                    "criterion": "Organization and Structure",
                    "description": "Logical flow and organization of ideas",
                    "score": 3,
                    "max_score": 5,
                    "weighted_score": 12.0,
                    "level_description": "Adequately organized with some transitions",
                    "feedback": "Satisfactory work on organization and structure. To enhance your essay, focus on strengthening transitions between paragraphs and ideas."
                },
                {
                    "criterion": "Language and Style",
                    "description": "Grammar, vocabulary, and writing style",
                    "score": 4,
                    "max_score": 5,
                    "weighted_score": 16.0,
                    "level_description": "Strong language with minor grammatical errors",
                    "feedback": "Excellent work on language and style. Your writing demonstrates a strong command of language and grammar."
                },
                {
                    "criterion": "Critical Thinking",
                    "description": "Analysis, evaluation, and original insights",
                    "score": 2,
                    "max_score": 5,
                    "weighted_score": 8.0,
                    "level_description": "Limited analysis with minimal original thought",
                    "feedback": "This area needs improvement: critical thinking. Move beyond simple description to analyze why events occur, how concepts relate, and what implications they have."
                },
                {
                    "criterion": "Evidence and Support",
                    "description": "Use of examples, quotations, and supporting details",
                    "score": 3,
                    "max_score": 5,
                    "weighted_score": 6.0,
                    "level_description": "Adequate evidence with some integration",
                    "feedback": "Satisfactory work on evidence and support. To strengthen your work, incorporate more specific examples and evidence to support your claims."
                }
            ],
            "overall_score": {
                "raw_score": 66.0,
                "total_possible": 100,
                "percentage": 66.0,
                "grade": "C+"
            },
            "feedback": {
                "overall_feedback": "Your essay shows a basic understanding of the topic. Your strengths include content and understanding and language and style. Focus on improving your critical thinking to enhance your overall performance. Your essay shows a basic understanding of the subject matter, but needs more depth and development.",
                "ai_confidence": "Medium"
            }
        }
        
        # Sample text analysis
        sample_analysis = {
            "metadata": {
                "topic": "The Impact of Climate Change"
            },
            "text_statistics": {
                "word_count": 750,
                "sentence_count": 35,
                "average_sentence_length": 21.4,
                "paragraph_count": 6,
                "average_paragraph_length": 125.0,
                "readability_score": 65.2
            }
        }
        
        # Generate feedback
        print("\nSelect feedback type:")
        print("1. Comprehensive Feedback")
        print("2. Quick Feedback")
        print("3. Comparative Feedback")
        print("0. Cancel")
        
        feedback_choice = input("\nEnter your choice (0-3): ")
        
        if feedback_choice == "0":
            return
        elif feedback_choice == "1":
            feedback = self.modules["feedback_generator"].generate_comprehensive_feedback(
                assessment_results=sample_assessment,
                text_analysis=sample_analysis,
                student_info={"name": "John Smith", "learning_style": "visual"}
            )
            print("\nComprehensive feedback generated.")
        elif feedback_choice == "2":
            feedback = self.modules["feedback_generator"].generate_quick_feedback(
                assessment_results=sample_assessment,
                feedback_type="standard"
            )
            print("\nQuick feedback generated.")
        elif feedback_choice == "3":
            feedback = self.modules["feedback_generator"].generate_comparative_feedback(
                current_assessment=sample_assessment,
                previous_assessments=[sample_assessment]  # In a real app, this would use actual previous assessments
            )
            print("\nComparative feedback generated.")
        else:
            print("Invalid choice.")
            return
        
        # Format feedback
        print("\nSelect output format:")
        print("1. Text")
        print("2. HTML")
        print("3. Markdown")
        
        format_choice = input("\nEnter your choice (1-3): ")
        
        if format_choice == "1":
            formatted_feedback = self.modules["feedback_generator"].format_feedback_for_export(
                feedback=feedback,
                format_type="text"
            )
        elif format_choice == "2":
            formatted_feedback = self.modules["feedback_generator"].format_feedback_for_export(
                feedback=feedback,
                format_type="html"
            )
        elif format_choice == "3":
            formatted_feedback = self.modules["feedback_generator"].format_feedback_for_export(
                feedback=feedback,
                format_type="markdown"
            )
        else:
            print("Invalid choice. Using text format.")
            formatted_feedback = self.modules["feedback_generator"].format_feedback_for_export(
                feedback=feedback,
                format_type="text"
            )
        
        # Display preview
        print("\nFEEDBACK PREVIEW:")
        print(formatted_feedback[:500] + "..." if len(formatted_feedback) > 500 else formatted_feedback)
        
        # Save feedback
        save_choice = input("\nSave feedback to file? (y/n): ")
        if save_choice.lower() == 'y':
            filename = f"feedback_{datetime.now().strftime('%Y%m%d%H%M%S')}.txt"
            with open(filename, 'w') as f:
                f.write(formatted_feedback)
            print(f"Feedback saved to {filename}")
    
    def _view_marking_statistics(self):
        """Display essay marking statistics."""
        print("\nESSAY MARKING STATISTICS")
        
        # In a real application, this would retrieve actual statistics
        print("\nTime Period: All Time")
        print("Total Essays Marked: 42")
        print("Average Score: 72.5%")
        print("Grade Distribution: A: 15%, B: 35%, C: 30%, D: 15%, F: 5%")
        
        print("\nVerification Statistics:")
        print("Approved without changes: 65%")
        print("Approved with adjustments: 30%")
        print("Rejected for manual marking: 5%")
        
        print("\nCommon Adjustment Areas:")
        print("1. Critical Thinking (45% of adjustments)")
        print("2. Evidence and Support (30% of adjustments)")
        print("3. Content and Understanding (15% of adjustments)")
        
        input("\nPress Enter to return to the Essay Marking Menu...")
    
    def _timetable_menu(self):
        """Display timetable generator menu and handle user input."""
        print("\nTIMETABLE GENERATOR")
        print("1. Create New Timetable")
        print("2. Manage School Data")
        print("3. View Timetables")
        print("4. Edit Timetable")
        print("5. Export Timetable")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self._create_timetable_workflow()
        elif choice == "2":
            self._manage_school_data_workflow()
        elif choice == "3":
            self._view_timetables_workflow()
        elif choice == "4":
            self._edit_timetable_workflow()
        elif choice == "5":
            self._export_timetable_workflow()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _create_timetable_workflow(self):
        """Handle timetable creation workflow."""
        print("\nCREATE NEW TIMETABLE")
        
        # Check if there's existing data
        if not self.modules["timetable"].teachers or not self.modules["timetable"].classes:
            print("\nNo school data found. You need to set up teachers, classes, subjects, and rooms first.")
            create_sample = input("Would you like to create sample data for demonstration? (y/n): ")
            
            if create_sample.lower() == 'y':
                sample_data = self.modules["timetable"].create_sample_data()
                print(f"\nCreated sample data with {sample_data['teachers']} teachers, {sample_data['classes']} classes, "
                      f"{sample_data['subjects']} subjects, and {sample_data['rooms']} rooms.")
            else:
                print("\nPlease use the 'Manage School Data' option to set up your school data first.")
                return
        
        # Configure timetable settings
        print("\nTIMETABLE CONFIGURATION")
        
        days_per_week = input("Number of school days per week [5]: ") or "5"
        periods_per_day = input("Number of periods per day [8]: ") or "8"
        optimization_level = input("Optimization level (basic/standard/advanced) [standard]: ") or "standard"
        
        config = self.modules["timetable"].configure({
            "days_per_week": int(days_per_week),
            "periods_per_day": int(periods_per_day),
            "optimization_level": optimization_level
        })
        
        print("\nGenerating timetable... This may take a moment.")
        result = self.modules["timetable"].generate_timetable()
        
        if result["success"]:
            print(f"\nTimetable generated successfully in {result['generation_time']:.2f} seconds.")
            
            if "warnings" in result and result["warnings"]:
                print("\nWarnings:")
                for warning in result["warnings"]:
                    print(f"- {warning}")
            
            # Show statistics
            stats = result["statistics"]
            print("\nTIMETABLE STATISTICS:")
            print(f"Total allocations: {stats['total_allocations']}")
            
            print("\nTeacher Hours (sample):")
            teacher_count = 0
            for teacher_id, hours in stats["teacher_hours"].items():
                if teacher_count >= 3:  # Show only first 3 teachers
                    break
                teacher_name = self.modules["timetable"].teachers[teacher_id]["name"]
                print(f"- {teacher_name}: {hours} hours")
                teacher_count += 1
            
            print("\nRoom Utilization (sample):")
            room_count = 0
            for room_id, data in stats["room_utilization"].items():
                if room_count >= 3:  # Show only first 3 rooms
                    break
                room_name = self.modules["timetable"].rooms[room_id]["name"]
                print(f"- {room_name}: {data['hours']} hours ({data['utilization_percent']:.1f}%)")
                room_count += 1
            
            # Ask if user wants to view a specific timetable
            view_timetable = input("\nWould you like to view a specific timetable? (y/n): ")
            if view_timetable.lower() == 'y':
                self._view_timetables_workflow()
            
        else:
            print("\nFailed to generate timetable.")
            if "errors" in result:
                print("\nErrors:")
                for error in result["errors"]:
                    print(f"- {error}")
    
    def _manage_school_data_workflow(self):
        """Handle school data management workflow."""
        print("\nMANAGE SCHOOL DATA")
        print("1. Manage Teachers")
        print("2. Manage Classes")
        print("3. Manage Subjects")
        print("4. Manage Rooms")
        print("5. Import Data")
        print("6. Export Data")
        print("0. Back to Timetable Menu")
        
        choice = input("\nEnter your choice (0-6): ")
        
        if choice == "1":
            self._manage_teachers_workflow()
        elif choice == "2":
            self._manage_classes_workflow()
        elif choice == "3":
            self._manage_subjects_workflow()
        elif choice == "4":
            self._manage_rooms_workflow()
        elif choice == "5":
            self._import_school_data()
        elif choice == "6":
            self._export_school_data()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _manage_teachers_workflow(self):
        """Handle teacher management workflow."""
        print("\nMANAGE TEACHERS")
        print("1. View All Teachers")
        print("2. Add New Teacher")
        print("3. Edit Teacher")
        print("4. Set Teacher Preferences")
        print("0. Back to School Data Menu")
        
        choice = input("\nEnter your choice (0-4): ")
        
        if choice == "1":
            if not self.modules["timetable"].teachers:
                print("\nNo teachers found.")
                return
                
            print("\nALL TEACHERS:")
            for teacher_id, teacher in self.modules["timetable"].teachers.items():
                subjects = ", ".join(teacher["subjects"])
                print(f"ID: {teacher_id}, Name: {teacher['name']}, Subjects: {subjects}")
        
        elif choice == "2":
            print("\nADD NEW TEACHER")
            teacher_id = input("Teacher ID: ")
            name = input("Teacher Name: ")
            
            # Show available subjects
            if self.modules["timetable"].subjects:
                print("\nAvailable Subjects:")
                for subject_id, subject in self.modules["timetable"].subjects.items():
                    print(f"- {subject_id}: {subject['name']}")
                
                subjects_input = input("\nSubjects (comma-separated IDs): ")
                subjects = [s.strip() for s in subjects_input.split(",")]
            else:
                print("\nNo subjects defined yet. Please add subjects first.")
                subjects = []
            
            max_hours = input("Maximum teaching hours per week [25]: ") or "25"
            
            result = self.modules["timetable"].add_teacher(
                teacher_id=teacher_id,
                name=name,
                subjects=subjects,
                max_hours=int(max_hours)
            )
            
            print(f"\nTeacher '{name}' added successfully.")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _manage_classes_workflow(self):
        """Handle class management workflow."""
        print("\nMANAGE CLASSES")
        print("1. View All Classes")
        print("2. Add New Class")
        print("3. Add Subject to Class")
        print("0. Back to School Data Menu")
        
        choice = input("\nEnter your choice (0-3): ")
        
        if choice == "1":
            if not self.modules["timetable"].classes:
                print("\nNo classes found.")
                return
                
            print("\nALL CLASSES:")
            for class_id, class_data in self.modules["timetable"].classes.items():
                print(f"ID: {class_id}, Name: {class_data['name']}, Grade: {class_data['grade_level']}")
                
                if class_data["subjects"]:
                    print("  Subjects:")
                    for subject in class_data["subjects"]:
                        subject_name = self.modules["timetable"].subjects.get(subject["subject_id"], {}).get("name", subject["subject_id"])
                        print(f"  - {subject_name}: {subject['hours_per_week']} hours/week")
        
        elif choice == "2":
            print("\nADD NEW CLASS")
            class_id = input("Class ID: ")
            name = input("Class Name: ")
            
            # Show available teachers for homeroom
            if self.modules["timetable"].teachers:
                print("\nAvailable Teachers:")
                for teacher_id, teacher in self.modules["timetable"].teachers.items():
                    print(f"- {teacher_id}: {teacher['name']}")
                
                homeroom_teacher = input("\nHomeroom Teacher ID: ")
            else:
                print("\nNo teachers defined yet. Please add teachers first.")
                homeroom_teacher = ""
            
            grade_level = input("Grade Level: ")
            
            result = self.modules["timetable"].add_class(
                class_id=class_id,
                name=name,
                homeroom_teacher=homeroom_teacher,
                grade_level=int(grade_level)
            )
            
            print(f"\nClass '{name}' added successfully.")
        
        elif choice == "3":
            if not self.modules["timetable"].classes:
                print("\nNo classes found. Please add a class first.")
                return
                
            if not self.modules["timetable"].subjects:
                print("\nNo subjects found. Please add subjects first.")
                return
            
            print("\nADD SUBJECT TO CLASS")
            
            # Select class
            print("\nAvailable Classes:")
            for class_id, class_data in self.modules["timetable"].classes.items():
                print(f"- {class_id}: {class_data['name']}")
            
            class_id = input("\nClass ID: ")
            
            # Select subject
            print("\nAvailable Subjects:")
            for subject_id, subject in self.modules["timetable"].subjects.items():
                print(f"- {subject_id}: {subject['name']}")
            
            subject_id = input("\nSubject ID: ")
            hours_per_week = input("Hours per week: ")
            
            # Select teacher
            print("\nAvailable Teachers:")
            for teacher_id, teacher in self.modules["timetable"].teachers.items():
                if subject_id in teacher["subjects"]:
                    print(f"- {teacher_id}: {teacher['name']}")
            
            teacher_id = input("\nTeacher ID (optional): ")
            
            result = self.modules["timetable"].add_class_subject(
                class_id=class_id,
                subject_id=subject_id,
                hours_per_week=int(hours_per_week),
                teacher_id=teacher_id if teacher_id else None
            )
            
            print(f"\nSubject added to class successfully.")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _manage_subjects_workflow(self):
        """Handle subject management workflow."""
        print("\nMANAGE SUBJECTS")
        print("1. View All Subjects")
        print("2. Add New Subject")
        print("3. Set Subject Constraints")
        print("0. Back to School Data Menu")
        
        choice = input("\nEnter your choice (0-3): ")
        
        if choice == "1":
            if not self.modules["timetable"].subjects:
                print("\nNo subjects found.")
                return
                
            print("\nALL SUBJECTS:")
            for subject_id, subject in self.modules["timetable"].subjects.items():
                specialized = "Requires specialized room" if subject.get("requires_specialized_room") else "General room"
                print(f"ID: {subject_id}, Name: {subject['name']}, {specialized}")
        
        elif choice == "2":
            print("\nADD NEW SUBJECT")
            subject_id = input("Subject ID: ")
            name = input("Subject Name: ")
            
            requires_specialized = input("Requires specialized room? (y/n): ")
            requires_specialized_room = requires_specialized.lower() == 'y'
            
            preferred_room_type = ""
            if requires_specialized_room:
                preferred_room_type = input("Preferred room type: ")
            
            consecutive_preferred = input("Consecutive periods preferred? (y/n): ")
            consecutive_periods_preferred = consecutive_preferred.lower() == 'y'
            
            result = self.modules["timetable"].add_subject(
                subject_id=subject_id,
                name=name,
                requires_specialized_room=requires_specialized_room,
                preferred_room_type=preferred_room_type,
                consecutive_periods_preferred=consecutive_periods_preferred
            )
            
            print(f"\nSubject '{name}' added successfully.")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _manage_rooms_workflow(self):
        """Handle room management workflow."""
        print("\nMANAGE ROOMS")
        print("1. View All Rooms")
        print("2. Add New Room")
        print("0. Back to School Data Menu")
        
        choice = input("\nEnter your choice (0-2): ")
        
        if choice == "1":
            if not self.modules["timetable"].rooms:
                print("\nNo rooms found.")
                return
                
            print("\nALL ROOMS:")
            for room_id, room in self.modules["timetable"].rooms.items():
                print(f"ID: {room_id}, Name: {room['name']}, Type: {room['room_type']}, Capacity: {room['capacity']}")
        
        elif choice == "2":
            print("\nADD NEW ROOM")
            room_id = input("Room ID: ")
            name = input("Room Name: ")
            capacity = input("Capacity: ")
            
            print("\nRoom Types:")
            print("- general: General classroom")
            print("- science: Science laboratory")
            print("- computer: Computer lab")
            print("- gym: Gymnasium")
            print("- art: Art studio")
            print("- music: Music room")
            print("- other: Other specialized room")
            
            room_type = input("\nRoom Type [general]: ") or "general"
            
            result = self.modules["timetable"].add_room(
                room_id=room_id,
                name=name,
                capacity=int(capacity),
                room_type=room_type
            )
            
            print(f"\nRoom '{name}' added successfully.")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _import_school_data(self):
        """Handle school data import workflow."""
        print("\nIMPORT SCHOOL DATA")
        
        file_path = input("Enter path to JSON data file: ")
        
        if not os.path.exists(file_path):
            print(f"\nFile not found: {file_path}")
            return
        
        result = self.modules["timetable"].import_data(file_path)
        
        if "error" in result:
            print(f"\nError importing data: {result['error']}")
        else:
            print(f"\nData imported successfully:")
            print(f"- {result['teachers']} teachers")
            print(f"- {result['classes']} classes")
            print(f"- {result['subjects']} subjects")
            print(f"- {result['rooms']} rooms")
    
    def _export_school_data(self):
        """Handle school data export workflow."""
        print("\nEXPORT SCHOOL DATA")
        
        file_path = input("Enter path for output JSON file: ")
        
        result = self.modules["timetable"].export_data(file_path)
        
        if result:
            print(f"\nData exported successfully to {file_path}")
        else:
            print("\nError exporting data")
    
    def _view_timetables_workflow(self):
        """Handle timetable viewing workflow."""
        print("\nVIEW TIMETABLES")
        print("1. View Master Timetable")
        print("2. View Teacher Timetable")
        print("3. View Class Timetable")
        print("4. View Room Timetable")
        print("0. Back to Timetable Menu")
        
        choice = input("\nEnter your choice (0-4): ")
        
        if choice == "1":
            print("\nMASTER TIMETABLE")
            print("The master timetable is too large to display in the console.")
            print("Please export it to view the complete timetable.")
        
        elif choice == "2":
            if not self.modules["timetable"].teachers:
                print("\nNo teachers found.")
                return
                
            print("\nSelect a teacher:")
            for teacher_id, teacher in self.modules["timetable"].teachers.items():
                print(f"- {teacher_id}: {teacher['name']}")
            
            teacher_id = input("\nTeacher ID: ")
            
            if teacher_id not in self.modules["timetable"].teachers:
                print(f"\nTeacher ID '{teacher_id}' not found.")
                return
            
            timetable = self.modules["timetable"].print_teacher_timetable(teacher_id)
            print(f"\n{timetable}")
        
        elif choice == "3":
            if not self.modules["timetable"].classes:
                print("\nNo classes found.")
                return
                
            print("\nSelect a class:")
            for class_id, class_data in self.modules["timetable"].classes.items():
                print(f"- {class_id}: {class_data['name']}")
            
            class_id = input("\nClass ID: ")
            
            if class_id not in self.modules["timetable"].classes:
                print(f"\nClass ID '{class_id}' not found.")
                return
            
            timetable = self.modules["timetable"].print_class_timetable(class_id)
            print(f"\n{timetable}")
        
        elif choice == "4":
            if not self.modules["timetable"].rooms:
                print("\nNo rooms found.")
                return
                
            print("\nSelect a room:")
            for room_id, room in self.modules["timetable"].rooms.items():
                print(f"- {room_id}: {room['name']}")
            
            room_id = input("\nRoom ID: ")
            
            if room_id not in self.modules["timetable"].rooms:
                print(f"\nRoom ID '{room_id}' not found.")
                return
            
            timetable = self.modules["timetable"].print_room_timetable(room_id)
            print(f"\n{timetable}")
        
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _edit_timetable_workflow(self):
        """Handle timetable editing workflow."""
        print("\nEDIT TIMETABLE")
        print("This feature is not implemented in the demo version.")
        print("In a full implementation, this would allow manual adjustments to the generated timetable.")
        
        input("\nPress Enter to return to the Timetable Menu...")
    
    def _export_timetable_workflow(self):
        """Handle timetable export workflow."""
        print("\nEXPORT TIMETABLE")
        print("1. Export as JSON")
        print("2. Export as CSV")
        print("3. Export as HTML")
        print("4. Export as PDF")
        print("0. Back to Timetable Menu")
        
        choice = input("\nEnter your choice (0-4): ")
        
        if choice == "0":
            return
        
        if not self.modules["timetable"].master_timetable:
            print("\nNo timetable has been generated yet. Please create a timetable first.")
            return
        
        file_path = input("Enter output file path: ")
        
        if choice == "1":
            format_type = "json"
        elif choice == "2":
            format_type = "csv"
        elif choice == "3":
            format_type = "html"
        elif choice == "4":
            format_type = "pdf"
        else:
            print("Invalid choice. Please try again.")
            return
        
        result = self.modules["timetable"].export_timetable(format_type, file_path)
        
        if "success" in result and result["success"]:
            print(f"\nTimetable exported successfully to {file_path}")
        else:
            print(f"\nError exporting timetable: {result.get('error', 'Unknown error')}")
    
    def _performance_menu(self):
        """Display performance menu and handle user input."""
        print("\nSTUDENT PERFORMANCE ANALYZER")
        print("1. Analyze Individual Student")
        print("2. Generate Class Report")
        print("3. Track Progress Over Time")
        print("4. Identify Learning Gaps")
        print("5. Export Analytics")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["performance"].analyze_student()
        elif choice == "2":
            self.modules["performance"].generate_class_report()
        elif choice == "3":
            self.modules["performance"].track_progress()
        elif choice == "4":
            self.modules["performance"].identify_gaps()
        elif choice == "5":
            self.modules["performance"].export_analytics()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _communication_menu(self):
        """Display communication menu and handle user input."""
        print("\nPARENT COMMUNICATION GENERATOR")
        print("1. Generate Parent Letter")
        print("2. Create Report Comments")
        print("3. Compose Email Template")
        print("4. Draft SMS Notification")
        print("5. Schedule Communications")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["communication"].generate_letter()
        elif choice == "2":
            self.modules["communication"].create_comments()
        elif choice == "3":
            self.modules["communication"].compose_email()
        elif choice == "4":
            self.modules["communication"].draft_sms()
        elif choice == "5":
            self.modules["communication"].schedule_communications()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _report_card_menu(self):
        """Display report card menu and handle user input."""
        print("\nREPORT CARD GENERATOR")
        print("1. Generate Individual Report Card")
        print("2. Create Class Report Cards")
        print("3. Customize Report Template")
        print("4. View Saved Reports")
        print("5. Export Reports")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "1":
            self.modules["report_card"].generate_individual()
        elif choice == "2":
            self.modules["report_card"].create_class_reports()
        elif choice == "3":
            self.modules["report_card"].customize_template()
        elif choice == "4":
            self.modules["report_card"].view_saved()
        elif choice == "5":
            self.modules["report_card"].export_reports()
        elif choice == "0":
            return
        else:
            print("Invalid choice. Please try again.")
    
    def _settings_menu(self):
        """Display settings menu and handle user input."""
        print("\nSETTINGS")
        print("1. User Profile")
        print("2. Preferences")
        print("3. Data Management")
        print("4. Integration Settings")
        print("5. About SMART TEACHER AI")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-5): ")
        
        if choice == "5":
            self._display_about()
        elif choice == "0":
            return
        else:
            print("This feature is not implemented in the demo version.")
    
    def _help_menu(self):
        """Display help menu and handle user input."""
        print("\nHELP & DOCUMENTATION")
        print("1. User Guide")
        print("2. Tutorial Videos")
        print("3. FAQ")
        print("4. Contact Support")
        print("0. Back to Main Menu")
        
        choice = input("\nEnter your choice (0-4): ")
        
        if choice == "1":
            print("\nOpening User Guide...")
            print("The User Guide would open here in a real application.")
        elif choice == "0":
            return
        else:
            print("This feature is not implemented in the demo version.")
    
    def _display_about(self):
        """Display information about the application."""
        print("\nABOUT SMART TEACHER AI")
        print(f"Version: {self.version}")
        print("Developed by: SMART TEACHER AI Development Team")
        print("Copyright © 2025 SMART TEACHER AI")
        print("\nSMART TEACHER AI is a comprehensive AI companion designed to help")
        print("teachers with tasks such as lesson planning, teaching materials creation,")
        print("assessment and marking, student performance analysis, parent communication,")
        print("report card generation, and timetable generation.")
        
        input("\nPress Enter to return to the Settings Menu...")


def main():
    """Main function to run the application."""
    parser = argparse.ArgumentParser(description="SMART TEACHER AI - Teacher's AI Companion")
    parser.add_argument('--version', action='version', version='SMART TEACHER AI v1.0.0')
    args = parser.parse_args()
    
    app = SmartTeacherAI()
    app.run()


if __name__ == "__main__":
    main()
