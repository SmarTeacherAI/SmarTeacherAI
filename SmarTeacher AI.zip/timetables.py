"""
SMART TEACHER AI - Timetable Generator API

This module provides API endpoints for the Timetable Generator functionality.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
import json
import os
from datetime import datetime

# Create blueprint
timetables_bp = Blueprint('timetables', __name__)

# Mock database for development (will be replaced with actual database)
TIMETABLES_DB = []
SCHOOL_DATA_DB = {
    'teachers': {},
    'classes': {},
    'subjects': {},
    'rooms': {}
}

@timetables_bp.route('/api/timetables', methods=['GET'])
@jwt_required()
def get_timetables():
    """Get all timetables for the current user."""
    current_user = get_jwt_identity()
    
    # Filter timetables by user (in a real app, this would query the database)
    user_timetables = [timetable for timetable in TIMETABLES_DB if timetable.get('user_id') == current_user]
    
    return jsonify({
        'success': True,
        'data': user_timetables
    }), 200

@timetables_bp.route('/api/timetables/<timetable_id>', methods=['GET'])
@jwt_required()
def get_timetable(timetable_id):
    """Get a specific timetable by ID."""
    current_user = get_jwt_identity()
    
    # Find the timetable (in a real app, this would query the database)
    timetable = next((t for t in TIMETABLES_DB if t.get('id') == timetable_id and t.get('user_id') == current_user), None)
    
    if not timetable:
        return jsonify({
            'success': False,
            'message': 'Timetable not found'
        }), 404
    
    return jsonify({
        'success': True,
        'data': timetable
    }), 200

@timetables_bp.route('/api/timetables', methods=['POST'])
@jwt_required()
def create_timetable():
    """Create a new timetable."""
    current_user = get_jwt_identity()
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'school_year', 'term']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # Create new timetable
    new_timetable = {
        'id': f'timetable_{len(TIMETABLES_DB) + 1}',
        'user_id': current_user,
        'name': data['name'],
        'school_year': data['school_year'],
        'term': data['term'],
        'days_per_week': data.get('days_per_week', 5),
        'periods_per_day': data.get('periods_per_day', 8),
        'master_timetable': {},
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat()
    }
    
    # Save to database (in a real app, this would insert into the database)
    TIMETABLES_DB.append(new_timetable)
    
    return jsonify({
        'success': True,
        'message': 'Timetable created successfully',
        'data': new_timetable
    }), 201

@timetables_bp.route('/api/timetables/<timetable_id>', methods=['PUT'])
@jwt_required()
def update_timetable(timetable_id):
    """Update an existing timetable."""
    current_user = get_jwt_identity()
    data = request.get_json()
    
    # Find the timetable (in a real app, this would query the database)
    timetable_index = next((i for i, t in enumerate(TIMETABLES_DB) 
                          if t.get('id') == timetable_id and t.get('user_id') == current_user), None)
    
    if timetable_index is None:
        return jsonify({
            'success': False,
            'message': 'Timetable not found'
        }), 404
    
    # Update timetable fields
    for key, value in data.items():
        if key not in ['id', 'user_id', 'created_at']:
            TIMETABLES_DB[timetable_index][key] = value
    
    # Update timestamp
    TIMETABLES_DB[timetable_index]['updated_at'] = datetime.now().isoformat()
    
    return jsonify({
        'success': True,
        'message': 'Timetable updated successfully',
        'data': TIMETABLES_DB[timetable_index]
    }), 200

@timetables_bp.route('/api/timetables/<timetable_id>', methods=['DELETE'])
@jwt_required()
def delete_timetable(timetable_id):
    """Delete a timetable."""
    current_user = get_jwt_identity()
    
    # Find the timetable (in a real app, this would query the database)
    timetable_index = next((i for i, t in enumerate(TIMETABLES_DB) 
                          if t.get('id') == timetable_id and t.get('user_id') == current_user), None)
    
    if timetable_index is None:
        return jsonify({
            'success': False,
            'message': 'Timetable not found'
        }), 404
    
    # Delete the timetable
    deleted_timetable = TIMETABLES_DB.pop(timetable_index)
    
    return jsonify({
        'success': True,
        'message': 'Timetable deleted successfully',
        'data': deleted_timetable
    }), 200

@timetables_bp.route('/api/timetables/generate', methods=['POST'])
@jwt_required()
def generate_timetable():
    """Generate a timetable based on provided parameters."""
    current_user = get_jwt_identity()
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'school_year', 'term', 'days_per_week', 'periods_per_day']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # Check if we have school data
    if not SCHOOL_DATA_DB['teachers'] or not SCHOOL_DATA_DB['classes'] or not SCHOOL_DATA_DB['subjects'] or not SCHOOL_DATA_DB['rooms']:
        return jsonify({
            'success': False,
            'message': 'School data is incomplete. Please add teachers, classes, subjects, and rooms before generating a timetable.'
        }), 400
    
    # In a real app, this would call a timetable generation algorithm
    # For now, we'll create a template-based timetable
    
    days_per_week = int(data['days_per_week'])
    periods_per_day = int(data['periods_per_day'])
    
    # Create empty master timetable
    master_timetable = {}
    
    # Days of the week
    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'][:days_per_week]
    
    # Generate timetable for each class
    for class_id, class_data in SCHOOL_DATA_DB['classes'].items():
        master_timetable[class_id] = {}
        
        for day in days:
            master_timetable[class_id][day] = {}
            
            for period in range(1, periods_per_day + 1):
                # Assign a subject and teacher for this period
                # In a real app, this would use a complex algorithm to optimize the timetable
                # For now, we'll just assign subjects randomly
                
                if not class_data['subjects']:
                    # No subjects for this class
                    master_timetable[class_id][day][str(period)] = {
                        'subject_id': None,
                        'teacher_id': None,
                        'room_id': None
                    }
                    continue
                
                # Get a subject for this class
                subject_index = (int(class_id.replace('class_', '')) + int(day[0]) + period) % len(class_data['subjects'])
                subject = class_data['subjects'][subject_index]
                subject_id = subject['subject_id']
                
                # Find a teacher for this subject
                teacher_id = None
                for tid, teacher in SCHOOL_DATA_DB['teachers'].items():
                    if subject_id in teacher['subjects']:
                        teacher_id = tid
                        break
                
                # Find a room for this subject
                room_id = None
                subject_data = SCHOOL_DATA_DB['subjects'].get(subject_id, {})
                requires_specialized = subject_data.get('requires_specialized_room', False)
                preferred_room_type = subject_data.get('preferred_room_type', '')
                
                if requires_specialized and preferred_room_type:
                    # Find a specialized room
                    for rid, room in SCHOOL_DATA_DB['rooms'].items():
                        if room['room_type'] == preferred_room_type:
                            room_id = rid
                            break
                
                if not room_id:
                    # Use any available room
                    if SCHOOL_DATA_DB['rooms']:
                        room_id = list(SCHOOL_DATA_DB['rooms'].keys())[0]
                
                master_timetable[class_id][day][str(period)] = {
                    'subject_id': subject_id,
                    'teacher_id': teacher_id,
                    'room_id': room_id
                }
    
    # Create the generated timetable
    generated_timetable = {
        'id': f'timetable_{len(TIMETABLES_DB) + 1}',
        'user_id': current_user,
        'name': data['name'],
        'school_year': data['school_year'],
        'term': data['term'],
        'days_per_week': days_per_week,
        'periods_per_day': periods_per_day,
        'days': days,
        'master_timetable': master_timetable,
        'created_at': datetime.now().isoformat(),
        'updated_at': datetime.now().isoformat(),
        'generation_time': 1.5,  # Simulated generation time in seconds
        'statistics': {
            'total_allocations': days_per_week * periods_per_day * len(SCHOOL_DATA_DB['classes']),
            'teacher_hours': {},
            'room_utilization': {}
        }
    }
    
    # Calculate statistics
    for class_id, days_data in master_timetable.items():
        for day, periods_data in days_data.items():
            for period, allocation in periods_data.items():
                teacher_id = allocation['teacher_id']
                room_id = allocation['room_id']
                
                if teacher_id:
                    if teacher_id not in generated_timetable['statistics']['teacher_hours']:
                        generated_timetable['statistics']['teacher_hours'][teacher_id] = 0
                    generated_timetable['statistics']['teacher_hours'][teacher_id] += 1
                
                if room_id:
                    if room_id not in generated_timetable['statistics']['room_utilization']:
                        generated_timetable['statistics']['room_utilization'][room_id] = {
                            'hours': 0,
                            'utilization_percent': 0
                        }
                    generated_timetable['statistics']['room_utilization'][room_id]['hours'] += 1
    
    # Calculate room utilization percentages
    total_periods = days_per_week * periods_per_day
    for room_id, data in generated_timetable['statistics']['room_utilization'].items():
        data['utilization_percent'] = (data['hours'] / total_periods) * 100
    
    # Save to database (in a real app, this would insert into the database)
    TIMETABLES_DB.append(generated_timetable)
    
    return jsonify({
        'success': True,
        'message': 'Timetable generated successfully',
        'data': generated_timetable
    }), 201

@timetables_bp.route('/api/timetables/<timetable_id>/class/<class_id>', methods=['GET'])
@jwt_required()
def get_class_timetable(timetable_id, class_id):
    """Get timetable for a specific class."""
    current_user = get_jwt_identity()
    
    # Find the timetable (in a real app, this would query the database)
    timetable = next((t for t in TIMETABLES_DB if t.get('id') == timetable_id and t.get('user_id') == current_user), None)
    
    if not timetable:
        return jsonify({
            'success': False,
            'message': 'Timetable not found'
        }), 404
    
    # Check if class exists in the timetable
    if class_id not in timetable['master_timetable']:
        return jsonify({
            'success': False,
            'message': f'Class {class_id} not found in timetable'
        }), 404
    
    # Get class data
    class_data = SCHOOL_DATA_DB['classes'].get(class_id, {'name': 'Unknown Class'})
    
    # Get class timetable
    class_timetable = timetable['master_timetable'][class_id]
    
    # Format the timetable for display
    formatted_timetable = []
    
    for day in timetable['days']:
        day_schedule = {'day': day, 'periods': []}
        
        for period in range(1, timetable['periods_per_day'] + 1):
            period_str = str(period)
            allocation = class_timetable.get(day, {}).get(period_str, {})
            
            subject_id = allocation.get('subject_id')
            teacher_id = allocation.get('teacher_id')
            room_id = allocation.get('room_id')
            
            subject_name = SCHOOL_DATA_DB['subjects'].get(subject_id, {}).get('name', 'Free Period') if subject_id else 'Free Period'
            teacher_name = SCHOOL_DATA_DB['teachers'].get(teacher_id, {}).get('name', '') if teacher_id else ''
            room_name = SCHOOL_DATA_DB['rooms'].get(room_id, {}).get('name', '') if room_id else ''
            
            day_schedule['periods'].append({
                'period': period,
                'subject': subject_name,
                'teacher': teacher_name,
                'room': room_name
            })
        
        formatted_timetable.append(day_schedule)
    
    return jsonify({
        'success': True,
        'data': {
            'timetable_id': timetable_id,
            'class_id': class_id,
            'class_name': class_data.get('name', 'Unknown Class'),
            'days': timetable['days'],
            'periods_per_day': timetable['periods_per_day'],
            'schedule': formatted_timetable
        }
    }), 200

@timetables_bp.route('/api/timetables/<timetable_id>/teacher/<teacher_id>', methods=['GET'])
@jwt_required()
def get_teacher_timetable(timetable_id, teacher_id):
    """Get timetable for a specific teacher."""
    current_user = get_jwt_identity()
    
    # Find the timetable (in a real app, this would query the database)
    timetable = next((t for t in TIMETABLES_DB if t.get('id') == timetable_id and t.get('user_id') == current_user), None)
    
    if not timetable:
        return jsonify({
            'success': False,
            'message': 'Timetable not found'
        }), 404
    
    # Check if teacher exists
    if teacher_id not in SCHOOL_DATA_DB['teachers']:
        return jsonify({
            'success': False,
            'message': f'Teacher {teacher_id} not found'
        }), 404
    
    # Get teacher data
    teacher_data = SCHOOL_DATA_DB['teachers'][teacher_id]
    
    # Extract teacher's schedule from master timetable
    teacher_schedule = {}
    
    for day in timetable['days']:
        teacher_schedule[day] = {}
        
        for period in range(1, timetable['periods_per_day'] + 1):
            period_str = str(period)
            teacher_schedule[day][period_str] = None
            
            # Check all classes for this teacher in this period
            for class_id, class_timetable in timetable['master_timetable'].items():
                allocation = class_timetable.get(day, {}).get(period_str, {})
                
                if allocation.get('teacher_id') == teacher_id:
                    subject_id = allocation.get('subject_id')
                    room_id = allocation.get('room_id')
                    
                    subject_name = SCHOOL_DATA_DB['subjects'].get(subject_id, {}).get('name', '') if subject_id else ''
                    class_name = SCHOOL_DATA_DB['classes'].get(class_id, {}).get('name', '') if class_id else ''
                    room_name = SCHOOL_DATA_DB['rooms'].get(room_id, {}).get('name', '') if room_id else ''
                    
                    teacher_schedule[day][period_str] = {
                        'class_id': class_id,
                        'class_nam
(Content truncated due to size limit. Use line ranges to read in chunks)