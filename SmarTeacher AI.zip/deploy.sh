#!/bin/bash

# SMART TEACHER AI - Deployment Script
# This script prepares and deploys the SMART TEACHER AI web application

echo "Preparing SMART TEACHER AI web application for deployment..."

# Create deployment directory
DEPLOY_DIR="deploy"
mkdir -p $DEPLOY_DIR

# Copy necessary files
echo "Copying files to deployment directory..."
cp -r api $DEPLOY_DIR/
cp -r static $DEPLOY_DIR/
cp -r templates $DEPLOY_DIR/
cp app.py $DEPLOY_DIR/
cp requirements.txt $DEPLOY_DIR/

# Create production .env file
echo "Creating production environment variables..."
cat > $DEPLOY_DIR/.env << EOL
FLASK_APP=app.py
FLASK_ENV=production
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
JWT_SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))")
EOL

# Create gunicorn configuration
echo "Creating gunicorn configuration..."
cat > $DEPLOY_DIR/gunicorn_config.py << EOL
bind = "0.0.0.0:5000"
workers = 4
timeout = 120
EOL

# Create startup script
echo "Creating startup script..."
cat > $DEPLOY_DIR/start.sh << EOL
#!/bin/bash
source venv/bin/activate
gunicorn --config gunicorn_config.py app:app
EOL
chmod +x $DEPLOY_DIR/start.sh

# Create README for deployment
echo "Creating deployment README..."
cat > $DEPLOY_DIR/README.md << EOL
# SMART TEACHER AI - Deployment

This directory contains the production-ready version of the SMART TEACHER AI web application.

## Setup Instructions

1. Create a virtual environment:
   \`\`\`
   python3 -m venv venv
   source venv/bin/activate
   \`\`\`

2. Install dependencies:
   \`\`\`
   pip install -r requirements.txt
   \`\`\`

3. Start the application:
   \`\`\`
   ./start.sh
   \`\`\`

## Deployment Options

### Option 1: Deploy with Gunicorn (included)
The start.sh script uses Gunicorn to run the application.

### Option 2: Deploy with Docker
Create a Dockerfile with the following content:

\`\`\`dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["gunicorn", "--config", "gunicorn_config.py", "app:app"]
\`\`\`

Then build and run the Docker container:
\`\`\`
docker build -t smart-teacher-ai .
docker run -p 5000:5000 smart-teacher-ai
\`\`\`

### Option 3: Deploy to a cloud platform
The application can be deployed to platforms like:
- Heroku
- AWS Elastic Beanstalk
- Google App Engine
- Azure App Service

Follow the platform-specific deployment instructions.
EOL

# Create Dockerfile
echo "Creating Dockerfile..."
cat > $DEPLOY_DIR/Dockerfile << EOL
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

EXPOSE 5000

CMD ["gunicorn", "--config", "gunicorn_config.py", "app:app"]
EOL

echo "Deployment preparation complete!"
echo "The application is ready to be deployed from the '$DEPLOY_DIR' directory."
echo "Follow the instructions in $DEPLOY_DIR/README.md for deployment options."
