"""
Human Verification Workflow for SMART TEACHER AI

This module provides a human verification workflow for essay and non-structured
answer marking, allowing teachers to review, adjust, and approve AI-generated assessments.
"""

import os
import json
import datetime
import uuid
from typing import Dict, List, Any, Optional, Tuple

class HumanVerificationWorkflow:
    """
    Manages the human verification workflow for AI-generated essay assessments.
    Provides functionality for teachers to review, adjust, and approve assessments.
    """
    
    def __init__(self, verification_dir: str = "../data/verification"):
        """
        Initialize the Human Verification Workflow.
        
        Args:
            verification_dir: Directory for storing verification data
        """
        self.verification_dir = verification_dir
        self._ensure_directory_exists()
        
        # Define verification statuses
        self.STATUSES = {
            "pending": "Pending Teacher Review",
            "in_review": "Currently Being Reviewed",
            "approved": "Approved Without Changes",
            "adjusted": "Approved With Adjustments",
            "rejected": "Rejected and Marked Manually"
        }
    
    def _ensure_directory_exists(self):
        """Ensure the verification directory exists."""
        os.makedirs(self.verification_dir, exist_ok=True)
    
    def create_verification_task(self, 
                               assessment_id: str,
                               assessment_results: Dict[str, Any],
                               essay_text: str,
                               student_info: Optional[Dict[str, Any]] = None,
                               priority: str = "normal") -> Dict[str, Any]:
        """
        Create a new verification task for teacher review.
        
        Args:
            assessment_id: Unique identifier for the assessment
            assessment_results: Results from AI-based assessment
            essay_text: Original essay text
            student_info: Optional information about the student
            priority: Priority level ("high", "normal", "low")
            
        Returns:
            Dictionary containing the verification task details
        """
        # Generate a unique verification ID
        verification_id = f"verify_{uuid.uuid4().hex[:8]}"
        
        # Create verification task
        verification_task = {
            "verification_id": verification_id,
            "assessment_id": assessment_id,
            "status": "pending",
            "created_at": datetime.datetime.now().isoformat(),
            "updated_at": datetime.datetime.now().isoformat(),
            "priority": priority,
            "original_assessment": assessment_results,
            "essay_text": essay_text,
            "teacher_adjustments": None,
            "final_assessment": None,
            "teacher_notes": None,
            "verification_metrics": {
                "ai_confidence": assessment_results.get("feedback", {}).get("ai_confidence", "Medium"),
                "adjustment_percentage": 0,
                "verification_time": 0
            }
        }
        
        # Add student info if provided
        if student_info:
            verification_task["student_info"] = student_info
        
        # Save the verification task
        self._save_verification_task(verification_task)
        
        return {
            "verification_id": verification_id,
            "status": "pending",
            "message": "Verification task created successfully"
        }
    
    def get_verification_task(self, verification_id: str) -> Dict[str, Any]:
        """
        Get a verification task by ID.
        
        Args:
            verification_id: The ID of the verification task to retrieve
            
        Returns:
            Dictionary containing the verification task details
        """
        file_path = os.path.join(self.verification_dir, f"{verification_id}.json")
        
        if not os.path.exists(file_path):
            return {"error": f"Verification task with ID '{verification_id}' not found"}
        
        try:
            with open(file_path, 'r') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            return {"error": f"Failed to load verification task: {e}"}
    
    def get_pending_verification_tasks(self, 
                                     limit: int = 10, 
                                     offset: int = 0,
                                     sort_by: str = "priority") -> List[Dict[str, Any]]:
        """
        Get a list of pending verification tasks.
        
        Args:
            limit: Maximum number of tasks to return
            offset: Number of tasks to skip
            sort_by: Field to sort by ("priority", "created_at")
            
        Returns:
            List of dictionaries containing pending verification tasks
        """
        # Ensure directory exists
        self._ensure_directory_exists()
        
        # Get all verification task files
        pending_tasks = []
        
        for filename in os.listdir(self.verification_dir):
            if filename.endswith('.json'):
                file_path = os.path.join(self.verification_dir, filename)
                try:
                    with open(file_path, 'r') as f:
                        task = json.load(f)
                        if task.get("status") == "pending":
                            # Add only essential information for listing
                            pending_tasks.append({
                                "verification_id": task["verification_id"],
                                "assessment_id": task["assessment_id"],
                                "created_at": task["created_at"],
                                "priority": task["priority"],
                                "student_name": task.get("student_info", {}).get("name", "Unknown"),
                                "subject": task["original_assessment"]["metadata"].get("subject", "Unknown"),
                                "ai_confidence": task["verification_metrics"]["ai_confidence"]
                            })
                except (json.JSONDecodeError, KeyError) as e:
                    print(f"Error loading verification task from {file_path}: {e}")
        
        # Sort tasks
        if sort_by == "priority":
            # Custom priority sorting (high > normal > low)
            priority_order = {"high": 0, "normal": 1, "low": 2}
            pending_tasks.sort(key=lambda x: (priority_order.get(x["priority"], 3), x["created_at"]))
        else:  # created_at
            pending_tasks.sort(key=lambda x: x["created_at"])
        
        # Apply pagination
        return pending_tasks[offset:offset + limit]
    
    def start_verification(self, verification_id: str, teacher_id: str) -> Dict[str, Any]:
        """
        Start the verification process for a task.
        
        Args:
            verification_id: The ID of the verification task
            teacher_id: ID of the teacher performing verification
            
        Returns:
            Dictionary containing the result of the operation
        """
        # Get the verification task
        task = self.get_verification_task(verification_id)
        if "error" in task:
            return task
        
        # Check if task is already being reviewed
        if task["status"] != "pending":
            return {"error": f"Verification task is not pending (current status: {task['status']})"}
        
        # Update task status
        task["status"] = "in_review"
        task["updated_at"] = datetime.datetime.now().isoformat()
        task["teacher_id"] = teacher_id
        task["review_started_at"] = datetime.datetime.now().isoformat()
        
        # Save the updated task
        self._save_verification_task(task)
        
        return {
            "verification_id": verification_id,
            "status": "in_review",
            "message": "Verification process started successfully"
        }
    
    def submit_verification(self, 
                          verification_id: str,
                          verification_result: str,
                          adjustments: Optional[Dict[str, Any]] = None,
                          teacher_notes: Optional[str] = None) -> Dict[str, Any]:
        """
        Submit verification results for a task.
        
        Args:
            verification_id: The ID of the verification task
            verification_result: Result of verification ("approved", "adjusted", "rejected")
            adjustments: Optional adjustments to the assessment
            teacher_notes: Optional notes from the teacher
            
        Returns:
            Dictionary containing the result of the operation
        """
        # Get the verification task
        task = self.get_verification_task(verification_id)
        if "error" in task:
            return task
        
        # Check if task is being reviewed
        if task["status"] != "in_review":
            return {"error": f"Verification task is not in review (current status: {task['status']})"}
        
        # Calculate verification time
        start_time = datetime.datetime.fromisoformat(task["review_started_at"])
        end_time = datetime.datetime.now()
        verification_time = (end_time - start_time).total_seconds()
        
        # Update task based on verification result
        task["status"] = verification_result
        task["updated_at"] = end_time.isoformat()
        task["verification_completed_at"] = end_time.isoformat()
        task["teacher_notes"] = teacher_notes
        
        # Handle different verification results
        if verification_result == "approved":
            # No changes, use original assessment as final
            task["final_assessment"] = task["original_assessment"]
            task["verification_metrics"]["adjustment_percentage"] = 0
            
        elif verification_result == "adjusted":
            # Apply teacher adjustments
            if not adjustments:
                return {"error": "Adjustments must be provided for 'adjusted' result"}
            
            task["teacher_adjustments"] = adjustments
            task["final_assessment"] = self._apply_adjustments(task["original_assessment"], adjustments)
            task["verification_metrics"]["adjustment_percentage"] = self._calculate_adjustment_percentage(
                task["original_assessment"], task["final_assessment"]
            )
            
        elif verification_result == "rejected":
            # Teacher will mark manually, no final assessment yet
            task["final_assessment"] = None
            task["verification_metrics"]["adjustment_percentage"] = 100
            
        else:
            return {"error": f"Invalid verification result: {verification_result}"}
        
        # Update verification metrics
        task["verification_metrics"]["verification_time"] = verification_time
        
        # Save the updated task
        self._save_verification_task(task)
        
        return {
            "verification_id": verification_id,
            "status": verification_result,
            "message": "Verification submitted successfully",
            "verification_time": verification_time
        }
    
    def submit_manual_assessment(self, 
                               verification_id: str,
                               manual_assessment: Dict[str, Any]) -> Dict[str, Any]:
        """
        Submit a manual assessment for a rejected verification task.
        
        Args:
            verification_id: The ID of the verification task
            manual_assessment: Manual assessment results
            
        Returns:
            Dictionary containing the result of the operation
        """
        # Get the verification task
        task = self.get_verification_task(verification_id)
        if "error" in task:
            return task
        
        # Check if task was rejected
        if task["status"] != "rejected":
            return {"error": f"Verification task was not rejected (current status: {task['status']})"}
        
        # Update task with manual assessment
        task["final_assessment"] = manual_assessment
        task["updated_at"] = datetime.datetime.now().isoformat()
        
        # Save the updated task
        self._save_verification_task(task)
        
        return {
            "verification_id": verification_id,
            "status": "rejected",
            "message": "Manual assessment submitted successfully"
        }
    
    def get_verification_statistics(self, 
                                  time_period: str = "all",
                                  teacher_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Get statistics about verification tasks.
        
        Args:
            time_period: Time period for statistics ("day", "week", "month", "all")
            teacher_id: Optional ID of teacher to filter statistics
            
        Returns:
            Dictionary containing verification statistics
        """
        # Ensure directory exists
        self._ensure_directory_exists()
        
        # Define time cutoff based on period
        now = datetime.datetime.now()
        if time_period == "day":
            cutoff = now - datetime.timedelta(days=1)
        elif time_period == "week":
            cutoff = now - datetime.timedelta(weeks=1)
        elif time_period == "month":
            cutoff = now - datetime.timedelta(days=30)
        else:  # all
            cutoff = datetime.datetime.min
        
        # Initialize statistics
        stats = {
            "total_tasks": 0,
            "status_counts": {status: 0 for status in self.STATUSES.keys()},
            "average_verification_time": 0,
            "average_adjustment_percentage": 0,
            "confidence_distribution": {"Low": 0, "Medium": 0, "High": 0},
            "priority_distribution": {"low": 0, "normal": 0, "high": 0}
        }
        
        # Collect data from verification tasks
        total_verification_time = 0
        total_adjustment_percentage = 0
        completed_tasks = 0
        
        for filename in os.listdir(self.verification_dir):
            if filename.endswith('.json'):
                file_path = os.path.join(self.verification_dir, filename)
                try:
                    with open(file_path, 'r') as f:
                        task = json.load(f)
                        
                        # Apply time period filter
                        created_at = datetime.datetime.fromisoformat(task["created_at"])
                        if created_at < cutoff:
                            continue
                        
                        # Apply teacher filter if specified
                        if teacher_id and task.get("teacher_id") != teacher_id:
                            continue
                        
                        # Update statistics
                        stats["total_tasks"] += 1
                        stats["status_counts"][task["status"]] += 1
                        stats["priority_distribution"][task["priority"]] += 1
                        
                        # Update confidence distribution
                        confidence = task["verification_metrics"]["ai_confidence"]
                        stats["confidence_distribution"][confidence] += 1
                        
                        # Update verification time and adjustment percentage for completed tasks
                        if task["status"] in ["approved", "adjusted", "rejected"]:
                            completed_tasks += 1
                            total_verification_time += task["verification_metrics"]["verification_time"]
                            total_adjustment_percentage += task["verification_metrics
(Content truncated due to size limit. Use line ranges to read in chunks)