"""
Lesson Plan & Scheme of Work Generator Module for SMART TEACHER AI

This module generates customized lesson plans and schemes of work based on
subject, class level, duration, and learning objectives.
"""

import os
import json
import datetime
from typing import Dict, List, Any, Optional

class LessonPlanGenerator:
    """
    Generates customized lesson plans based on teacher inputs.
    Integrates with AI models to create detailed, curriculum-aligned lesson content.
    """
    
    def __init__(self, templates_dir: str = "../templates/lesson_plans"):
        """
        Initialize the Lesson Plan Generator.
        
        Args:
            templates_dir: Directory containing lesson plan templates
        """
        self.templates_dir = templates_dir
        self.curriculum_standards = self._load_curriculum_standards()
        
    def _load_curriculum_standards(self) -> Dict:
        """Load curriculum standards from JSON file."""
        # In a production environment, this would load from a database or API
        # For now, we'll use a placeholder
        return {
            "primary": {
                "mathematics": {
                    "grade_1": ["Numbers", "Addition", "Subtraction", "Shapes"],
                    "grade_2": ["Place Value", "Multiplication", "Division", "Measurement"],
                    # Additional grades would be included
                },
                "science": {
                    "grade_1": ["Plants", "Animals", "Weather", "Materials"],
                    "grade_2": ["Living Things", "Habitats", "Forces", "Earth and Space"],
                    # Additional grades would be included
                }
                # Additional subjects would be included
            },
            "secondary": {
                "mathematics": {
                    "form_1": ["Algebra", "Geometry", "Statistics", "Number Theory"],
                    "form_2": ["Linear Equations", "Quadratic Equations", "Trigonometry", "Probability"],
                    # Additional forms would be included
                },
                "biology": {
                    "form_1": ["Cell Biology", "Plant Biology", "Animal Biology", "Ecology"],
                    "form_2": ["Nutrition", "Transport", "Respiration", "Excretion", "Coordination", "Reproduction"],
                    # Additional forms would be included
                }
                # Additional subjects would be included
            }
        }
    
    def get_available_templates(self) -> List[str]:
        """Return a list of available lesson plan templates."""
        # In a production environment, this would scan the templates directory
        return ["CBC Format", "8-4-4 Format", "International Baccalaureate", "Cambridge Curriculum"]
    
    def get_topics_for_subject(self, level: str, subject: str, class_level: str) -> List[str]:
        """
        Get available topics for a specific subject and class level.
        
        Args:
            level: 'primary' or 'secondary'
            subject: Subject name (e.g., 'mathematics', 'biology')
            class_level: Class level (e.g., 'grade_1', 'form_2')
            
        Returns:
            List of topics for the specified subject and class level
        """
        try:
            return self.curriculum_standards[level][subject][class_level]
        except KeyError:
            return []
    
    def generate_lesson_plan(self, 
                            subject: str, 
                            topic: str, 
                            class_level: str, 
                            duration: int, 
                            objectives: List[str],
                            template_format: str = "CBC Format") -> Dict[str, Any]:
        """
        Generate a lesson plan based on provided parameters.
        
        Args:
            subject: Subject name (e.g., 'Mathematics', 'Biology')
            topic: Specific topic for the lesson
            class_level: Class level (e.g., 'Grade 3', 'Form 2')
            duration: Lesson duration in minutes
            objectives: List of learning objectives
            template_format: Format template to use
            
        Returns:
            Dictionary containing the generated lesson plan
        """
        # In a production environment, this would call an AI API
        # For now, we'll create a structured template
        
        # Calculate time allocations based on duration
        intro_time = max(5, int(duration * 0.1))  # 10% of time or minimum 5 minutes
        activities_time = int(duration * 0.7)     # 70% of time
        assessment_time = int(duration * 0.1)     # 10% of time
        conclusion_time = duration - (intro_time + activities_time + assessment_time)  # Remaining time
        
        # Generate suggested activities based on topic and objectives
        activities = self._generate_activities(subject, topic, class_level, objectives)
        
        # Generate assessment methods
        assessment_methods = self._generate_assessment_methods(subject, topic, class_level)
        
        # Create the lesson plan structure
        lesson_plan = {
            "metadata": {
                "subject": subject,
                "topic": topic,
                "class_level": class_level,
                "duration": duration,
                "template_format": template_format,
                "date_generated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "objectives": objectives,
            "materials_needed": self._suggest_materials(subject, topic),
            "lesson_structure": {
                "introduction": {
                    "duration": f"{intro_time} minutes",
                    "activities": [
                        f"Review previous lesson on {self._get_related_topic(subject, topic, class_level)}",
                        f"Introduce {topic} with a real-world example",
                        "Explain lesson objectives to students"
                    ]
                },
                "main_activities": {
                    "duration": f"{activities_time} minutes",
                    "activities": activities
                },
                "assessment": {
                    "duration": f"{assessment_time} minutes",
                    "methods": assessment_methods
                },
                "conclusion": {
                    "duration": f"{conclusion_time} minutes",
                    "activities": [
                        "Summarize key points of the lesson",
                        "Address any questions from students",
                        "Preview next lesson"
                    ]
                }
            },
            "homework_assignment": self._generate_homework(subject, topic, class_level),
            "additional_resources": self._suggest_resources(subject, topic)
        }
        
        return lesson_plan
    
    def generate_scheme_of_work(self, 
                               subject: str, 
                               class_level: str, 
                               term: str, 
                               weeks: int,
                               template_format: str = "CBC Format") -> Dict[str, Any]:
        """
        Generate a scheme of work for a full term.
        
        Args:
            subject: Subject name
            class_level: Class level
            term: Term (e.g., 'Term 1', 'Term 2')
            weeks: Number of weeks in the term
            template_format: Format template to use
            
        Returns:
            Dictionary containing the generated scheme of work
        """
        # Determine education level (primary/secondary) from class_level
        if class_level.lower().startswith(('grade', 'std', 'standard')):
            level = 'primary'
            class_key = f"grade_{class_level.split()[-1]}"
        else:  # Assume secondary
            level = 'secondary'
            class_key = f"form_{class_level.split()[-1]}"
        
        # Get topics for this subject and class level
        try:
            available_topics = self.curriculum_standards[level][subject.lower()][class_key]
        except KeyError:
            # If not found, provide some generic topics
            available_topics = [f"Topic {i+1}" for i in range(weeks)]
        
        # Ensure we have enough topics for the number of weeks
        while len(available_topics) < weeks:
            available_topics.append(f"Review and Assessment {len(available_topics) + 1}")
        
        # Create weekly plans
        weekly_plans = []
        for week in range(1, weeks + 1):
            topic_index = min(week - 1, len(available_topics) - 1)
            topic = available_topics[topic_index]
            
            # Generate objectives for this topic
            objectives = [
                f"Understand the key concepts of {topic}",
                f"Apply {topic} principles to solve problems",
                f"Analyze and evaluate {topic} in different contexts"
            ]
            
            weekly_plan = {
                "week": week,
                "topic": topic,
                "objectives": objectives,
                "teaching_activities": self._generate_activities(subject, topic, class_level, objectives),
                "resources": self._suggest_materials(subject, topic),
                "assessment": self._generate_assessment_methods(subject, topic, class_level)
            }
            weekly_plans.append(weekly_plan)
        
        # Create the scheme of work structure
        scheme_of_work = {
            "metadata": {
                "subject": subject,
                "class_level": class_level,
                "term": term,
                "weeks": weeks,
                "template_format": template_format,
                "date_generated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "weekly_plans": weekly_plans
        }
        
        return scheme_of_work
    
    def export_to_format(self, content: Dict[str, Any], format_type: str) -> str:
        """
        Export the generated content to the specified format.
        
        Args:
            content: The lesson plan or scheme of work content
            format_type: The desired output format ('pdf', 'docx', 'google_docs')
            
        Returns:
            Path to the exported file
        """
        # In a production environment, this would convert to actual file formats
        # For now, we'll just return a placeholder
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if "lesson_structure" in content:
            # It's a lesson plan
            filename = f"lesson_plan_{content['metadata']['subject']}_{content['metadata']['topic']}_{timestamp}.{format_type}"
        else:
            # It's a scheme of work
            filename = f"scheme_of_work_{content['metadata']['subject']}_{content['metadata']['term']}_{timestamp}.{format_type}"
        
        # In a real implementation, we would save the file here
        return f"../output/{filename}"
    
    # Helper methods for generating content
    
    def _get_related_topic(self, subject: str, current_topic: str, class_level: str) -> str:
        """Get a related topic for the previous lesson reference."""
        return f"Basic {current_topic}"
    
    def _suggest_materials(self, subject: str, topic: str) -> List[str]:
        """Suggest materials needed for the lesson."""
        common_materials = ["Whiteboard", "Markers", "Textbooks", "Notebooks"]
        
        subject_specific = {
            "mathematics": ["Calculators", "Rulers", "Graph paper", "Geometric shapes"],
            "biology": ["Microscopes", "Specimen slides", "Lab equipment", "Charts"],
            "chemistry": ["Test tubes", "Chemicals", "Safety goggles", "Periodic table"],
            "physics": ["Measuring instruments", "Springs", "Weights", "Circuit components"],
            "history": ["Maps", "Timeline charts", "Historical documents", "Artifacts"],
            "geography": ["Globes", "Maps", "Atlas", "Rock samples"],
            "english": ["Reading texts", "Dictionary", "Grammar charts", "Literature books"],
            "art": ["Drawing paper", "Paints", "Brushes", "Color charts"]
        }
        
        # Get subject-specific materials or use default list
        specific_materials = subject_specific.get(subject.lower(), ["Subject-specific resources"])
        
        # Add topic-specific material
        topic_material = [f"{topic} reference chart", f"{topic} worksheet"]
        
        return common_materials + specific_materials + topic_material
    
    def _generate_activities(self, subject: str, topic: str, class_level: str, objectives: List[str]) -> List[str]:
        """Generate suggested activities based on the topic and objectives."""
        # Basic activity templates that can be adapted to most subjects
        activity_templates = [
            "Group discussion on {topic} concepts",
            "Individual problem-solving exercise on {topic}",
            "Pair work: Students explain {topic} to each other",
            "Practical demonstration of {topic} principles",
            "Interactive quiz on {topic} fundamentals",
            "Role play to illustrate {topic} concepts",
            "Visual mapping of {topic} relationships",
            "Research activity on real-world applications of {topic}",
            "Guided practice with teacher support on {topic} problems",
            "Student presentations on aspects of {topic}"
        ]
        
        # Select 3-5 activities based on subject and topic
        import random
        num_activities = random.randint(3, 5)
        selected_activities = random.sample(activity_templates, num_activities)
        
        # Format the activities with the specific topic
        formatted_activities = [activity.format(topic=topic) for activity in selected_activities]
        
        return formatted_activities
    
    def _generate_assessment_methods(self, subject: str, topic: str, class_level: str) -> List[str]:
        """Generate assessment methods appropriate for the subject and topic."""
        assessment_methods = [
            f"Oral questions on {topic} concepts",
            f"Short written quiz on {topic}",
            f"Observation of student participation during {topic} activities",
            f"Exit ticket summarizing key points of {topic}",
            f"Peer assessment of {topic} understanding"
        ]
        
        return assessment_methods
    
    def _generate_homework(self, subject: str, topic: str, class_level: str) -> Dict[str, Any]:
        """Generate a homework assignment related to the lesson topic."""
        homework = {
            "description": f"Practice exercises on {topic}",
            "instructions": f"Complete the following activities to reinforce your understanding of {topic}:",
            "tasks": [
                f"Answer questions 1-5 on page X of the textbook related to {topic}",
                f"Write a short paragraph explaining the importance of {topic}",
                f"Prepare one example of {topic} from everyday life"
            ],
            "due_date": "Next lesson"
        }
        
        return homework
    
    def _suggest_resources(self, subject: str, topic: str) -> List[Dict[str, str]]:
        """Suggest additional resources for teachers and students."""
        resources = [
            {
                "type": "Website",
                "name": f"{subject} Resource Portal",
                "description": f"Interactive lessons and exercises on {topic}",
                "url": f"https://example.com/{subject.lower()}/{topic.lower().replace(' ', '-')}"
            },
            {
                "type": "Video",
                "name": f"{topic} Explained",
                "description": f"Visual explanation of {topic} concepts
(Content truncated due to size limit. Use line ranges to read in chunks)