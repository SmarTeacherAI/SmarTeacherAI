"""
Test Script for SMART TEACHER AI Essay Marking Capabilities

This script tests the enhanced essay marking capabilities of the SMART TEACHER AI system,
including text analysis, rubric-based assessment, feedback generation, and human verification.
"""

import os
import sys
import json
import datetime
from typing import Dict, Any

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import modules
from modules.text_analyzer import TextAnalyzer
from modules.rubric_manager import RubricManager
from modules.essay_marking_enhancement import EssayMarkingEnhancement
from modules.feedback_generator import FeedbackGenerator
from modules.human_verification_workflow import HumanVerificationWorkflow, VerificationInterface

# Create test directory if it doesn't exist
os.makedirs("test_data", exist_ok=True)
os.makedirs("test_data/essays", exist_ok=True)
os.makedirs("test_data/results", exist_ok=True)

# Sample essays for testing
SAMPLE_ESSAYS = {
    "excellent": {
        "title": "The Impact of Climate Change on Global Ecosystems",
        "text": """
        Climate change represents one of the most significant challenges facing our planet in the 21st century. The scientific consensus is clear: human activities, particularly the burning of fossil fuels and deforestation, have led to unprecedented increases in greenhouse gas concentrations in our atmosphere. These changes are driving global temperature rises, altering precipitation patterns, and increasing the frequency and intensity of extreme weather events worldwide.

        The impacts of climate change on global ecosystems are both profound and far-reaching. Marine ecosystems, for instance, face multiple stressors including ocean acidification, rising sea temperatures, and changing circulation patterns. Coral reefs, often called the "rainforests of the sea," are particularly vulnerable to these changes. Research indicates that even a 1.5°C increase in global temperatures could result in the loss of 70-90% of coral reefs worldwide, devastating marine biodiversity and the communities that depend on these ecosystems for food security and livelihoods.

        Terrestrial ecosystems are experiencing equally significant disruptions. Shifting temperature and precipitation patterns are altering the geographic ranges of numerous plant and animal species. A comprehensive study published in Nature Climate Change analyzed data from over 4,000 species and found that terrestrial organisms are moving poleward at an average rate of 17 kilometers per decade, while marine species are moving even faster, at 72 kilometers per decade. These shifts are creating novel ecosystems with unpredictable species interactions and potentially reducing biodiversity through the loss of specialized species that cannot adapt quickly enough.

        The relationship between climate change and biodiversity loss is particularly concerning. The Intergovernmental Science-Policy Platform on Biodiversity and Ecosystem Services (IPBES) reports that climate change is now the third most important driver of biodiversity loss globally, after changes in land and sea use and direct exploitation of organisms. As climate change accelerates, it is expected to become the leading cause of biodiversity loss in the coming decades. This loss of biodiversity undermines ecosystem resilience, potentially creating feedback loops that further exacerbate climate change impacts.

        Mountain ecosystems provide a striking example of climate change vulnerability. As temperatures rise, species adapted to cooler conditions must move upslope to maintain their preferred climate envelope. However, this vertical migration has inherent limitations – eventually, species reach the summit with nowhere further to go, a phenomenon ecologists refer to as "mountaintop extinction." The European Alps, for example, have experienced a 2°C temperature increase over the past century, nearly twice the global average, resulting in documented upslope shifts of numerous plant species and the loss of specialized alpine species.

        Freshwater ecosystems are also experiencing profound changes. Rising water temperatures, altered flow regimes, and increased frequency of droughts and floods are disrupting aquatic communities. Cold-water fish species like salmon and trout are particularly vulnerable, with suitable habitat projected to decline by up to 50% in some regions by 2080. Additionally, warming waters hold less dissolved oxygen and promote harmful algal blooms, further stressing aquatic organisms.

        The Arctic region demonstrates perhaps the most dramatic ecosystem changes due to climate change. Warming at more than twice the global average rate, the Arctic is experiencing rapid sea ice loss, permafrost thaw, and vegetation changes. These transformations are fundamentally altering food webs and threatening iconic species such as polar bears, which depend on sea ice for hunting. Moreover, thawing permafrost releases stored carbon and methane, creating a positive feedback loop that accelerates global warming.

        Ecosystem responses to climate change are not linear and often involve complex interactions and feedback mechanisms. Tipping points – thresholds beyond which ecosystems shift to alternative states – are of particular concern. For example, the Amazon rainforest, which plays a crucial role in global carbon and water cycles, may be approaching a tipping point where reduced precipitation and increased fire frequency could transform large portions into savanna, releasing massive amounts of stored carbon and accelerating global warming.

        Addressing the impacts of climate change on ecosystems requires both mitigation strategies to reduce greenhouse gas emissions and adaptation measures to enhance ecosystem resilience. Protected area networks must be designed with climate change in mind, incorporating connectivity to facilitate species range shifts and representing climatic gradients to provide refugia. Restoration efforts should focus on enhancing ecosystem functionality and resilience rather than simply recreating historical conditions that may no longer be sustainable in a changing climate.

        Nature-based solutions offer promising approaches that simultaneously address climate change and biodiversity conservation. For example, protecting and restoring carbon-rich ecosystems such as forests, wetlands, and seagrass meadows can sequester significant amounts of carbon while providing habitat for biodiversity and delivering additional ecosystem services like flood protection and water purification.

        In conclusion, climate change is fundamentally altering global ecosystems in ways that threaten biodiversity, ecosystem services, and human well-being. The complexity and scale of these changes demand urgent, coordinated action at local, national, and international levels. By implementing ambitious mitigation measures to reduce greenhouse gas emissions and strategic adaptation approaches to enhance ecosystem resilience, we can work toward a more sustainable future where both human societies and natural ecosystems can thrive despite the challenges posed by our changing climate.
        """
    },
    "good": {
        "title": "Effects of Climate Change on Ecosystems",
        "text": """
        Climate change is having significant effects on ecosystems around the world. The increasing temperatures, changing precipitation patterns, and rising sea levels are altering habitats and affecting the plants and animals that live in them.

        One major impact of climate change is on marine ecosystems. Ocean acidification, caused by increased carbon dioxide absorption, is making it difficult for coral reefs to form their calcium carbonate structures. This threatens coral reef ecosystems, which are home to about 25% of all marine species. Rising sea temperatures are also causing coral bleaching events to become more frequent and severe.

        Terrestrial ecosystems are also being affected. Many plant and animal species are shifting their ranges toward the poles or to higher elevations as their habitats warm. However, not all species can move quickly enough to keep pace with climate change. This is leading to mismatches in the timing of important ecological events, such as when flowers bloom and when their pollinators are active.

        Forests are particularly vulnerable to climate change. Warmer temperatures and drought conditions are increasing the frequency and intensity of wildfires in many regions. Climate change is also making forests more susceptible to pest outbreaks, as warmer winters allow more pests to survive and reproduce.

        Arctic ecosystems are experiencing some of the most rapid changes due to climate change. The Arctic is warming at about twice the global average rate, leading to melting sea ice and thawing permafrost. These changes are affecting the plants and animals that have adapted to life in this harsh environment, such as polar bears that depend on sea ice for hunting.

        Freshwater ecosystems are being impacted by changes in precipitation patterns and increased evaporation due to higher temperatures. Many rivers, lakes, and wetlands are experiencing altered flow regimes, water levels, and water temperatures, which affect the organisms that live in these habitats.

        The loss of biodiversity due to climate change has far-reaching consequences. Ecosystems with higher biodiversity tend to be more resilient to environmental changes and provide more ecosystem services, such as clean water, pollination, and carbon sequestration. As biodiversity decreases, ecosystems become less stable and less able to provide these important services.

        To address the impacts of climate change on ecosystems, both mitigation and adaptation strategies are necessary. Mitigation involves reducing greenhouse gas emissions to limit the extent of climate change. Adaptation includes actions such as creating protected areas that allow species to move as the climate changes, restoring degraded ecosystems to enhance their resilience, and implementing sustainable management practices.

        Conservation efforts must also consider how climate change will affect ecosystems in the future. Traditional approaches that focus on preserving ecosystems in their current state may not be effective in a rapidly changing climate. Instead, conservation strategies need to be dynamic and forward-looking, considering how ecosystems might change and how to facilitate their adaptation.

        In conclusion, climate change is having profound effects on ecosystems worldwide. Understanding these impacts and developing effective strategies to address them is essential for preserving biodiversity and maintaining the ecosystem services that support human well-being. This requires coordinated action at local, national, and international levels, as well as continued research to improve our understanding of how ecosystems respond to climate change.
        """
    },
    "satisfactory": {
        "title": "Climate Change and Ecosystems",
        "text": """
        Climate change is affecting ecosystems around the world. Global temperatures are rising, and this is causing problems for plants and animals. Many species are having to adapt to new conditions or move to new areas.

        In the oceans, coral reefs are being damaged by warmer water temperatures. This is called coral bleaching. When the water gets too warm, the corals lose the algae that give them color and provide them with food. If the water stays too warm for too long, the corals can die. This is bad for all the fish and other animals that live in coral reefs.

        On land, many plants and animals are moving to cooler areas as their habitats warm up. Some are moving toward the poles, while others are moving up mountains. But not all species can move easily. Trees, for example, can only spread their seeds so far each generation. And some animals may find their path blocked by cities, farms, or other human developments.

        Forests are being affected by climate change too. In some places, warmer and drier conditions are leading to more forest fires. In other places, pests like bark beetles are spreading because winters aren't cold enough to kill them off. These pests can kill large numbers of trees.

        The Arctic is warming faster than other parts of the world. Sea ice is melting, which is a problem for animals like polar bears that hunt on the ice. The ground in the Arctic, called permafrost, is also thawing. This can damage buildings and roads, and it releases greenhouse gases that were trapped in the frozen ground.

        Climate change is also affecting the timing of natural events. For example, some flowers are blooming earlier in the spring, but the insects that pollinate them might not be active at the same time. This can lead to problems for both the plants and the insects.

        To help ecosystems cope with climate change, we need to reduce greenhouse gas emissions. We also need to protect and restore natural areas, and create corridors that allow animals to move to new areas as the climate changes. Some species might need help to adapt or move.

        In conclusion, climate change is having many effects on ecosystems. We need to take action to reduce these impacts and help ecosystems adapt to the changes that are already happening.
        """
    },
    "needs_improvement": {
        "title": "Climate Change",
        "text": """
        Climate change is when the weather changes. It is getting hotter on Earth because of pollution. This is bad for animals and plants.

        Animals have to move when it gets too hot. Some animals can't find food. Polar bears are losing their homes because ice is melting. Fish are dying because the water is too hot.

        Plants are also affected by climate change. Some plants can't grow when it's too hot or if there isn't enough rain. Trees are dying because of bugs and fires.

        People cause climate change by burning fossil fuels like oil and gas. Cars and factories release pollution into the air. This pollution traps heat and makes the Earth warmer.

        We need to stop climate change. We can use less energy and drive less. We can use clean energy like solar power and wind power. We can also plant more trees.

        In conclusion, climate change is a big problem. It affects animals, plants, and people. We need to do something about it now.
        """
    }
}

def save_essay_to_file(essay_key: str, essay_data: Dict[str, str]) -> str:
    """Save essay to file and return the file path."""
    file_path = f"test_data/essays/{essay_key}.txt"
    with open(file_path, 'w') as f:
        f.write(f"Title: {essay_data['title']}\n\n")
        f.write(essay_data['text'])
    return file_path

def save_results_to_file(essay_key: str, results: Dict[str, Any]) -> str:
    """Save results to file and return the file path."""
    file_path = f"test_data/results/{essay_key}_results.json"
    with open(file_path, 'w') as f:
        json.dump(results, f, indent=2)
    return file_path

def test_text_analyzer():
    """Test the TextAnalyzer module."""
    print("\n=== Testing TextAnalyzer Module ===")
    
    analyzer = TextAnalyzer()
    results = {}
    
    for essay_key, essay_data in SAMPLE_ESSAYS.items():
        print(f"\nAnalyzing {essay_key} essay...")
        
        # Save essay to file
        file_path = save_essay_to_file(essay_key, essay_data)
        
        # Analyze essay
        analysis_result = analyzer.analyze_text(
            text=essay_data['text'],
            title=essay_data['title'],
            subject="Environmental Science",
            grade_level="Secondary",
            keywords=["climate change", "ecosystem", "biodiversity", "adaptation"]
        )
        
        # Print summary of analysis
        print(f"Word count: {analysis_result['text_statistics']['word_count']}")
        print(f"Readability score: {analysis_result.get('text_statistics', {}).get('readability_score', 'N/A')}")
        print(f"Lexical diversity: {analysis_result.get('vocabulary_analysis', {}).get('lexical_diversity', 'N/A')}")
        print(f"Advanced word percentage: {analysis_result.get('vocabulary_analysis', {}).get('advanced_word_percentage', 'N/A')}%")
        print(f"Relevance score: {analysis_result.get('content_analysis', {}).get('relevance_score', 'N/A')}")
        
        # Save results
        results[essay_key] = analysis_result
    
    return results

def test_rubric_manager():
    """Test the RubricManager module."""
    print("\n=== Testing RubricManager Module ===")
    
    rubric_manager = RubricManager()
    
    # Get available default rubrics
    default_rubrics = rubric_manager.get_default_rubrics()
    print(f"Available default rubrics: {len(default_rubrics)}")
    for rubric in default_rubrics:
        print(f"- {rubric['name']} ({rubric['id']})")
    
    # Generate a rubric template
    template = rubric_manager.generate_rubric_template(
        subject="Environmental Science",
        level="Secondary",
        assessment_type="Essay"
    )
    print(f"\nGenerated template: {template['name']}")
    
    # Create a custom rubric
    custom_rubric = {
        "name": "Climate Change Essay Evaluation",
        "description": "Rubric for evaluating essays on climate change and ecosystems",
        "subject": "Environmental Science",
        "level": "Secondary",
        "total_marks": 100,
        "criteria": [
            {
                "name": "Scientific Understanding",
                "description": "Accuracy and depth of scientific concepts related to climate change",
                "weight": 0.3,
                "levels": [
                    {"score": 5, "description": "Comprehensive and accurate scientific understanding with precise terminology"},
                    {"score": 4, "description": "Strong scientific understanding with appropriate terminology"},
                    {"score": 3, "description": "Adequate scientific understanding with some terminology"},
                    {"score": 2, "description": "Limited scientific understanding with minimal terminology"},
                    {"score": 1, "description": "Poor scientific understanding with inaccuracies"}
                ]
            },
            {
                "name": "Ecosystem Impact Analysis",
                "description": "Analysis of climate change impacts on ecosystems",
                "weight": 0.25,
                "levels": [
                    {"score": 5, "description": "Sophisticated analysis of multiple ecosystem impacts with detailed examples"},
                    {"score": 4, "description": "Strong analysis of ecosystem impacts with good examples"},
                    {"score": 3, "description": "Adequate analysis of ecosystem impacts with some examples"},
                    {"score": 2, "description": "Limited analysis of ecosystem impacts with few examples"},
                    {"score": 1, "description": "Minimal analysis of ecosystem impacts with no examples"}
                ]
            },
            {
                "name": "Evidence and Examples",
                "description": "Use of specific evidence and examples to support arguments",
                "weight": 0.2,
                "levels": [
                    {"score": 5, "description": "Extensive use of relevant evidence with excellent integration"},
                    {"score": 4, "description": "Good use of relevant evidence with clear integration"},
                    {"score": 3, "description": "Adequate use of evidence with some integration"},
                    {"score": 2, "description": "Limited use of evidence with poor integration"},
                    {"score": 1, "description": "Minimal or no use of evidence"}
                ]
            },
            {
                "name": "Organization and Structure",
                "description": "Logical organization and structure of the essay",
                "weight": 0.15,
                "levels": [
                    {"score": 5, "description": "Exceptionally well-organized with clear thesis and conclusion"},
                    {"score": 4, "description": "Well-organized with good thesis and conclusion"},
                    {"score": 3, "description": "Adequately organized with basic thesis and conclusion"},
                    {"score": 2, "description": "Poorly organized with unclear thesis and conclusion"},
                    {"score": 1, "description": "Disorganized with no clear thesis or conclusion"}
                ]
            },
            {
                "name": "Writing Quality",
                "description": "Grammar, vocabulary, and writing style",
                "weight": 0.1,
                "levels": [
                    {"score": 5, "description": "Excellent writing with sophisticated language"},
                    {"score": 4, "description": "Good writing with appropriate language"},
                    {"score": 3, "description": "Adequate writing with some errors"},
                    {"score": 2, "description": "Poor writing with frequent errors"},
                    {"score": 1, "description": "Very poor writing with pervasive errors"}
                ]
            }
        ]
    }
    
    result = rubric_manager.create_rubric(custom_rubric)
    if "rubric" in result:
        print(f"Created custom rubric: {result['rubric']['id']}")
        return result['rubric']['id']
    else:
        print(f"Failed to create custom rubric: {result}")
        return None

def test_essay_marking(text_analysis_results: Dict[str, Any], rubric_id: str):
    """Test the essay marking capabilities."""
    print("\n=== Testing Essay Marking Capabilities ===")
    
    rubric_manager = RubricManager()
    essay_marking = EssayMarkingEnhancement()
    results = {}
    
    for essay_key, analysis in text_analysis_results.items():
        print(f"\nMarking {essay_key} essay...")
        
        # Apply rubric to essay analysis
        marking_result = rubric_manager.apply_rubric(
            rubric_id=rubric_id,
            essay_analysis=analysis
        )
        
        # Print summary of marking
        print(f"Overall score: {marking_result['overall_score']['raw_score']}/{marking_result['overall_score']['total_possible']} ({marking_result['overall_score']['percentage']}%)")
        print(f"Grade: {marking_result['overall_score']['grade']}")
        
        # Print criterion scores
        print("Criterion scores:")
        for cs in marking_result['criterion_scores']:
            print(f"- {cs['criterion']}: {cs['score']}/{cs['max_score']} ({cs['weighted_score']} points)")
        
        # Save results
        results[essay_key] = marking_result
    
    return results

def test_feedback_generator(text_analysis_results: Dict[str, Any], marking_results: Dict[str, Any]):
    """Test the FeedbackGenerator module."""
    print("\n=== Testing FeedbackGenerator Module ===")
    
    feedback_generator = FeedbackGenerator()
    results = {}
    
    for essay_key in text_analysis_results.keys():
        print(f"\nGenerating feedback for {essay_key} essay...")
        
        # Generate comprehensive feedback
        feedback = feedback_generator.generate_comprehensive_feedback(
            assessment_results=marking_results[essay_key],
            text_analysis=text_analysis_results[essay_key],
            student_info={"name": "John Smith", "learning_style": "visual"}
        )
        
        # Format feedback as markdown
        markdown_feedback = feedback_generator.format_feedback_for_export(
            feedback=feedback,
            format_type="markdown"
        )
        
        # Save feedback to file
        feedback_file = f"test_data/results/{essay_key}_feedback.md"
        with open(feedback_file, 'w') as f:
            f.write(markdown_feedback)
        
        print(f"Feedback saved to {feedback_file}")
        
        # Save results
        results[essay_key] = feedback
    
    return results

def test_human_verification_workflow(marking_results: Dict[str, Any]):
    """Test the HumanVerificationWorkflow module."""
    print("\n=== Testing HumanVerificationWorkflow Module ===")
    
    workflow = HumanVerificationWorkflow()
    interface = VerificationInterface(workflow)
    results = {}
    
    for essay_key, essay_data in SAMPLE_ESSAYS.items():
        print(f"\nCreating verification task for {essay_key} essay...")
        
        # Create verification task
        task_result = workflow.create_verification_task(
            assessment_id=f"assessment_{essay_key}",
            assessment_results=marking_results[essay_key],
            essay_text=essay_data['text'],
            student_info={"name": "John Smith", "grade": "10", "class": "Environmental Science"},
            priority="normal"
        )
        
        verification_id = task_result["verification_id"]
        print(f"Created verification task: {verification_id}")
        
        # Start verification
        start_result = workflow.start_verification(verification_id, teacher_id="teacher_123")
        print(f"Started verification: {start_result['status']}")
        
        # Prepare adjustment template
        template = interface.prepare_adjustment_template(verification_id)
        
        # Simulate teacher adjustments
        if essay_key == "satisfactory":
            # Make some adjustments to the satisfactory essay
            adjustments = {
                "criterion_adjustments": {
                    "Scientific Understanding": {
                        "original": 3,
                        "adjusted": 3,
                        "max_score": 5,
                        "original_feedback": "Adequate scientific understanding with some terminology.",
                        "adjusted_feedback": "Adequate scientific understanding with some terminology, but could benefit from more precise explanations of climate mechanisms."
                    },
                    "Ecosystem Impact Analysis": {
                        "original": 3,
                        "adjusted": 2,
                        "max_score": 5,
                        "original_feedback": "Adequate analysis of ecosystem impacts with some examples.",
                        "adjusted_feedback": "Limited analysis of ecosystem impacts with few specific examples. The essay mentions impacts but doesn't explore them in depth."
                    }
                },
                "overall_adjustment": {
                    "raw_score": {
                        "original": 60.0,
                        "adjusted": 55.0
                    },
                    "percentage": {
                        "original": 60.0,
                        "adjusted": 55.0
                    },
                    "grade": {
                        "original": "C+",
                        "adjusted": "C"
                    }
                },
                "feedback_adjustments": {
                    "overall_feedback": {
                        "original": "Your essay shows a basic understanding of climate change impacts on ecosystems.",
                        "adjusted": "Your essay shows a basic understanding of climate change, but needs more specific examples and deeper analysis of ecosystem impacts."
                    }
                },
                "teacher_notes": "The essay covers basic concepts but lacks depth in analyzing ecosystem impacts. Recommend more specific examples and clearer explanations of climate mechanisms."
            }
            
            submit_result = interface.submit_teacher_adjustments(
                verification_id=verification_id,
                adjustments=adjustments,
                verification_result="adjusted"
            )
            
            print(f"Submitted verification with adjustments: {submit_result['status']}")
            
        else:
            # Approve without changes
            submit_result = interface.submit_teacher_adjustments(
                verification_id=verification_id,
                adjustments={},
                verification_result="approved"
            )
            
            print(f"Submitted verification without adjustments: {submit_result['status']}")
        
        # Get verification task details
        task_details = interface.get_verification_task_details(verification_id)
        
        # Save results
        results[essay_key] = {
            "verification_id": verification_id,
            "status": task_details["status"],
            "final_assessment": task_details.get("final_assessment", marking_results[essay_key])
        }
    
    # Get verification statistics
    stats = workflow.get_verification_statistics()
    print(f"\nVerification statistics: {stats['total_tasks']} total tasks")
    print(f"Status counts: {stats['status_counts']}")
    
    # Get learning insights
    insights = workflow.get_learning_insights()
    print(f"\nLearning insights: {len(insights['criterion_adjustment_rates'])} criteria with adjustments")
    
    return results

def run_full_test():
    """Run a full test of all essay marking components."""
    print("=== SMART TEACHER AI Essay Marking Test ===")
    print("Starting comprehensive test of essay marking capabilities...")
    
    # Test text analyzer
    text_analysis_results = test_text_analyzer()
    
    # Test rubric manager
    rubric_id = test_rubric_manager()
    
    # Test essay marking
    marking_results = test_essay_marking(text_analysis_results, rubric_id)
    
    # Test feedback generator
    feedback_results = test_feedback_generator(text_analysis_results, marking_results)
    
    # Test human verification workflow
    verification_results = test_human_verification_workflow(marking_results)
    
    # Compile all results
    all_results = {
        "text_analysis": text_analysis_results,
        "marking": marking_results,
        "feedback": feedback_results,
        "verification": verification_results
    }
    
    # Save all results
    with open("test_data/all_results.json", 'w') as f:
        json.dump(all_results, f, indent=2)
    
    print("\n=== Test Complete ===")
    print("All essay marking components have been tested successfully.")
    print("Results saved to test_data/all_results.json")
    
    return all_results

if __name__ == "__main__":
    run_full_test()
