"""
AI Text Analysis Module for SMART TEACHER AI

This module provides advanced text analysis capabilities for essay and non-structured
answer marking, using NLP techniques to evaluate content quality, structure, and language.
"""

import re
import json
import nltk
import string
from typing import Dict, List, Any, Optional, Tuple
from collections import Counter

# In a production environment, we would ensure these are downloaded
# For demonstration purposes, we'll assume they're already available
# nltk.download('punkt')
# nltk.download('stopwords')
# nltk.download('wordnet')

from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.probability import FreqDist

class TextAnalyzer:
    """
    Provides advanced text analysis capabilities for essay and non-structured answer marking.
    Uses NLP techniques to evaluate content quality, structure, language usage, and more.
    """
    
    def __init__(self):
        """Initialize the Text Analyzer with necessary NLP components."""
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
        
        # Common transition words and phrases for structure analysis
        self.introduction_markers = [
            'introduction', 'to begin with', 'first', 'firstly', 'initially', 
            'to start with', 'this essay will', 'this paper will', 'the purpose of'
        ]
        
        self.conclusion_markers = [
            'conclusion', 'in conclusion', 'to conclude', 'to summarize', 'in summary',
            'finally', 'in closing', 'to sum up', 'overall', 'in the end', 'ultimately'
        ]
        
        self.transition_words = [
            'however', 'furthermore', 'moreover', 'therefore', 'consequently',
            'in addition', 'similarly', 'in contrast', 'on the other hand',
            'for example', 'for instance', 'specifically', 'in particular',
            'as a result', 'thus', 'hence', 'accordingly', 'subsequently'
        ]
        
        # Common grammar and style issues to check for
        self.grammar_patterns = {
            'double_spaces': r'  +',
            'missing_periods': r'[a-zA-Z]\s+[A-Z]',
            'repeated_words': r'\b(\w+)\s+\1\b',
            'run_on_sentences': r'[^.!?]{100,}[.!?]',
            'sentence_fragments': r'\b(Because|Since|Although|If|When|While)\b[^.!?]{10,30}[.!?]',
            'passive_voice': r'\b(am|is|are|was|were|be|being|been)\s+(\w+ed)\b'
        }
    
    def analyze_text(self, text: str, subject: str, topic: str, 
                    expected_keywords: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Perform comprehensive analysis of text content.
        
        Args:
            text: The text to analyze
            subject: The subject area (e.g., "Biology", "English")
            topic: The specific topic
            expected_keywords: Optional list of keywords expected in the text
            
        Returns:
            Dictionary containing analysis results
        """
        # Clean and prepare the text
        cleaned_text = self._clean_text(text)
        
        # Basic text statistics
        word_count = len(cleaned_text.split())
        sentences = sent_tokenize(text)
        sentence_count = len(sentences)
        avg_sentence_length = word_count / sentence_count if sentence_count > 0 else 0
        paragraphs = [p for p in text.split('\n\n') if p.strip()]
        paragraph_count = len(paragraphs)
        avg_paragraph_length = word_count / paragraph_count if paragraph_count > 0 else 0
        
        # Vocabulary analysis
        vocabulary_stats = self._analyze_vocabulary(cleaned_text)
        
        # Structure analysis
        structure_analysis = self._analyze_structure(text, paragraphs, sentences)
        
        # Content analysis
        content_analysis = self._analyze_content(cleaned_text, subject, topic, expected_keywords)
        
        # Grammar and style analysis
        grammar_analysis = self._analyze_grammar_and_style(text)
        
        # Coherence and cohesion analysis
        coherence_analysis = self._analyze_coherence(paragraphs, sentences)
        
        # Compile the complete analysis
        analysis_result = {
            "text_statistics": {
                "word_count": word_count,
                "sentence_count": sentence_count,
                "average_sentence_length": round(avg_sentence_length, 1),
                "paragraph_count": paragraph_count,
                "average_paragraph_length": round(avg_paragraph_length, 1),
                "readability_score": self._calculate_readability_score(text)
            },
            "vocabulary_analysis": vocabulary_stats,
            "structure_analysis": structure_analysis,
            "content_analysis": content_analysis,
            "grammar_analysis": grammar_analysis,
            "coherence_analysis": coherence_analysis
        }
        
        return analysis_result
    
    def extract_key_concepts(self, text: str, subject: str, topic: str) -> List[Dict[str, Any]]:
        """
        Extract key concepts from the text based on subject and topic.
        
        Args:
            text: The text to analyze
            subject: The subject area
            topic: The specific topic
            
        Returns:
            List of dictionaries containing key concepts and their context
        """
        # Clean and prepare the text
        cleaned_text = self._clean_text(text)
        
        # Tokenize the text
        words = word_tokenize(cleaned_text)
        
        # Remove stopwords and lemmatize
        filtered_words = [self.lemmatizer.lemmatize(word.lower()) for word in words 
                         if word.lower() not in self.stop_words and word.isalnum()]
        
        # Get word frequency distribution
        fdist = FreqDist(filtered_words)
        
        # Extract most common words as potential key concepts
        common_words = [word for word, freq in fdist.most_common(20)]
        
        # Generate topic-specific keywords based on subject and topic
        topic_keywords = self._generate_topic_keywords(subject, topic)
        
        # Combine common words with topic keywords
        all_keywords = list(set(common_words + topic_keywords))
        
        # Extract sentences containing these keywords
        key_concepts = []
        sentences = sent_tokenize(text)
        
        for keyword in all_keywords:
            for sentence in sentences:
                if keyword.lower() in sentence.lower():
                    # Check if this keyword is already in the list
                    existing = next((item for item in key_concepts if item["concept"].lower() == keyword.lower()), None)
                    
                    if existing:
                        # Add this sentence as additional context if it's different
                        if sentence not in existing["context"]:
                            existing["context"].append(sentence)
                            existing["frequency"] += 1
                    else:
                        # Add new concept
                        key_concepts.append({
                            "concept": keyword,
                            "context": [sentence],
                            "frequency": 1,
                            "relevance": "high" if keyword in topic_keywords else "medium"
                        })
        
        # Sort by frequency and relevance
        key_concepts.sort(key=lambda x: (x["relevance"] == "high", x["frequency"]), reverse=True)
        
        # Limit to top 10 concepts
        return key_concepts[:10]
    
    def evaluate_argument_structure(self, text: str) -> Dict[str, Any]:
        """
        Evaluate the argument structure of the text.
        
        Args:
            text: The text to analyze
            
        Returns:
            Dictionary containing evaluation of argument structure
        """
        # Split into paragraphs
        paragraphs = [p for p in text.split('\n\n') if p.strip()]
        
        # Check for introduction
        has_introduction = False
        introduction_strength = 0
        if paragraphs:
            first_paragraph = paragraphs[0].lower()
            has_introduction = any(marker in first_paragraph for marker in self.introduction_markers)
            
            # Evaluate introduction strength
            if has_introduction:
                # Check for thesis statement
                has_thesis = self._contains_thesis_statement(first_paragraph)
                # Check for preview of main points
                has_preview = self._contains_preview(first_paragraph)
                
                introduction_strength = 1  # Basic introduction
                if has_thesis:
                    introduction_strength += 1  # Has thesis
                if has_preview:
                    introduction_strength += 1  # Has preview
        
        # Check for conclusion
        has_conclusion = False
        conclusion_strength = 0
        if paragraphs and len(paragraphs) > 1:
            last_paragraph = paragraphs[-1].lower()
            has_conclusion = any(marker in last_paragraph for marker in self.conclusion_markers)
            
            # Evaluate conclusion strength
            if has_conclusion:
                # Check for thesis restatement
                has_restatement = self._contains_thesis_restatement(last_paragraph)
                # Check for summary of main points
                has_summary = self._contains_summary(last_paragraph)
                
                conclusion_strength = 1  # Basic conclusion
                if has_restatement:
                    conclusion_strength += 1  # Has thesis restatement
                if has_summary:
                    conclusion_strength += 1  # Has summary
        
        # Analyze body paragraphs
        body_paragraphs = paragraphs[1:-1] if len(paragraphs) > 2 else paragraphs
        
        topic_sentences = 0
        supporting_evidence = 0
        transitions = 0
        
        for paragraph in body_paragraphs:
            # Check for topic sentence
            if self._has_topic_sentence(paragraph):
                topic_sentences += 1
            
            # Check for supporting evidence
            if self._has_supporting_evidence(paragraph):
                supporting_evidence += 1
            
            # Check for transitions
            if self._has_transitions(paragraph):
                transitions += 1
        
        # Calculate percentages
        body_paragraph_count = len(body_paragraphs)
        topic_sentence_percentage = (topic_sentences / body_paragraph_count) * 100 if body_paragraph_count > 0 else 0
        supporting_evidence_percentage = (supporting_evidence / body_paragraph_count) * 100 if body_paragraph_count > 0 else 0
        transition_percentage = (transitions / body_paragraph_count) * 100 if body_paragraph_count > 0 else 0
        
        # Evaluate overall argument structure
        structure_score = 0
        max_score = 10
        
        # Introduction (0-3 points)
        structure_score += introduction_strength
        
        # Body paragraphs (0-4 points)
        if topic_sentence_percentage >= 75:
            structure_score += 1
        if supporting_evidence_percentage >= 75:
            structure_score += 2
        if transition_percentage >= 50:
            structure_score += 1
        
        # Conclusion (0-3 points)
        structure_score += conclusion_strength
        
        # Calculate percentage
        structure_percentage = (structure_score / max_score) * 100
        
        # Determine structure quality
        if structure_percentage >= 90:
            structure_quality = "excellent"
        elif structure_percentage >= 75:
            structure_quality = "good"
        elif structure_percentage >= 60:
            structure_quality = "satisfactory"
        elif structure_percentage >= 40:
            structure_quality = "needs improvement"
        else:
            structure_quality = "poor"
        
        # Compile the evaluation
        evaluation = {
            "introduction": {
                "present": has_introduction,
                "strength": introduction_strength,
                "has_thesis": has_introduction and introduction_strength > 1,
                "has_preview": has_introduction and introduction_strength > 2
            },
            "body_paragraphs": {
                "count": body_paragraph_count,
                "topic_sentences_percentage": round(topic_sentence_percentage, 1),
                "supporting_evidence_percentage": round(supporting_evidence_percentage, 1),
                "transitions_percentage": round(transition_percentage, 1)
            },
            "conclusion": {
                "present": has_conclusion,
                "strength": conclusion_strength,
                "has_restatement": has_conclusion and conclusion_strength > 1,
                "has_summary": has_conclusion and conclusion_strength > 2
            },
            "overall_structure": {
                "score": structure_score,
                "max_score": max_score,
                "percentage": round(structure_percentage, 1),
                "quality": structure_quality
            }
        }
        
        return evaluation
    
    def assess_evidence_usage(self, text: str) -> Dict[str, Any]:
        """
        Assess the usage of evidence in the text.
        
        Args:
            text: The text to analyze
            
        Returns:
            Dictionary containing assessment of evidence usage
        """
        # Split into paragraphs
        paragraphs = [p for p in text.split('\n\n') if p.strip()]
        
        # Patterns for different types of evidence
        evidence_patterns = {
            "quotations": r'[""].*?[""]',
            "statistics": r'\b\d+(\.\d+)?%|\b\d+\s+out of\s+\d+\b|\b\d+\s+in\s+\d+\b',
            "examples": r'\bfor example\b|\bfor instance\b|\bsuch as\b|\be\.g\.\b',
            "citations": r'\([^)]*\d{4}[^)]*\)|\b\w+\s+et al\.\b'
        }
        
        # Count occurrences of each type of evidence
        evidence_counts = {}
        for evidence_type, pattern in evidence_patterns.items():
            evidence_counts[evidence_type] = len(re.findall(pattern, text, re.IGNORECASE))
        
        # Count paragraphs with evidence
        paragraphs_with_evidence = 0
        for paragraph in paragraphs:
            has_evidence = False
            for pattern in evidence_patterns.values():
                if re.search(pattern, paragraph, re.IGNORECASE):
                    has_evidence = True
                    break
            
            if has_evidence:
                paragraphs_with_evidence += 1
        
        # Calculate percentage of paragraphs with evidence
        evidence_coverage = (paragraphs_with_evidence / len(paragraphs)) * 100 if paragraphs else 0
        
        # Calculate total evidence count
        total_evidence = sum(evidence_counts.values())
        
        # Calculate evidence density (evidence per 100 words)
        word_count = len(self._clean_text(text).split())
        evidence_density = (total_evidence / word_count) * 100 if word_count > 0 else 0
        
        # Evaluate evidence quality
        if evidence_density >= 5 and evidence_coverage >= 80:
            evidence_quality = "excellent"
        elif evidence_density >= 3 and evidence_coverage >= 60:
            evidence_quality = "good"
        elif evidence_density >= 2 and evidence_coverage >= 40:
            evidence_quality = "satisfactory"
        elif evidence_density >= 1 and evidence_coverage >= 20:
            evidence_quality = "needs improvement"
        else:
            evidence_quality = "poor"
        
        # Compile the assessment
(Content truncated due to size limit. Use line ranges to read in chunks)