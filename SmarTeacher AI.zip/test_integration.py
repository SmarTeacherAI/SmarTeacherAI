"""
Test script for the SMART TEACHER AI application with focus on the Timetable Generator.

This script tests the integration of the Timetable Generator module with the main application
and verifies that all timetable functionality works correctly.
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock
import json
from datetime import datetime

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the main application and modules
from modules.timetable_generator import TimetableGenerator

class TestTimetableGenerator(unittest.TestCase):
    """Test case for the Timetable Generator module."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.tg = TimetableGenerator()
        
        # Create sample data for testing
        self.sample_data = self.tg.create_sample_data()
    
    def test_sample_data_creation(self):
        """Test that sample data is created correctly."""
        self.assertGreater(len(self.tg.teachers), 0, "Teachers should be created")
        self.assertGreater(len(self.tg.classes), 0, "Classes should be created")
        self.assertGreater(len(self.tg.subjects), 0, "Subjects should be created")
        self.assertGreater(len(self.tg.rooms), 0, "Rooms should be created")
        
        # Check that sample data has expected structure
        for teacher_id, teacher in self.tg.teachers.items():
            self.assertIn("name", teacher, "Teacher should have a name")
            self.assertIn("subjects", teacher, "Teacher should have subjects")
        
        for class_id, class_data in self.tg.classes.items():
            self.assertIn("name", class_data, "Class should have a name")
            self.assertIn("subjects", class_data, "Class should have subjects")
    
    def test_configuration(self):
        """Test that configuration works correctly."""
        config = self.tg.configure({
            "periods_per_day": 6,
            "days_per_week": 5,
            "optimization_level": "basic"
        })
        
        self.assertEqual(config["periods_per_day"], 6, "Periods per day should be configurable")
        self.assertEqual(config["days_per_week"], 5, "Days per week should be configurable")
        self.assertEqual(config["optimization_level"], "basic", "Optimization level should be configurable")
    
    def test_timetable_generation(self):
        """Test that timetable generation works correctly."""
        # Configure the timetable generator
        self.tg.configure({
            "periods_per_day": 8,
            "days_per_week": 5,
            "optimization_level": "standard"
        })
        
        # Generate the timetable
        result = self.tg.generate_timetable()
        
        # Check that generation was successful
        self.assertTrue(result["success"], "Timetable generation should succeed")
        self.assertIn("generation_time", result, "Generation time should be reported")
        self.assertIn("statistics", result, "Statistics should be reported")
        
        # Check that master timetable was created
        self.assertIsNotNone(self.tg.master_timetable, "Master timetable should be created")
    
    def test_timetable_export(self):
        """Test that timetable export works correctly."""
        # Generate a timetable first
        self.tg.configure({"optimization_level": "basic"})
        self.tg.generate_timetable()
        
        # Test JSON export
        json_file = "test_timetable_export.json"
        json_result = self.tg.export_timetable("json", json_file)
        self.assertTrue(json_result["success"], "JSON export should succeed")
        self.assertTrue(os.path.exists(json_file), "JSON file should be created")
        
        # Clean up
        if os.path.exists(json_file):
            os.remove(json_file)
    
    def test_timetable_printing(self):
        """Test that timetable printing works correctly."""
        # Generate a timetable first
        self.tg.configure({"optimization_level": "basic"})
        self.tg.generate_timetable()
        
        # Get a sample class and teacher
        sample_class_id = list(self.tg.classes.keys())[0]
        sample_teacher_id = list(self.tg.teachers.keys())[0]
        
        # Test class timetable printing
        class_timetable = self.tg.print_class_timetable(sample_class_id)
        self.assertIsInstance(class_timetable, str, "Class timetable should be a string")
        self.assertGreater(len(class_timetable), 0, "Class timetable should not be empty")
        
        # Test teacher timetable printing
        teacher_timetable = self.tg.print_teacher_timetable(sample_teacher_id)
        self.assertIsInstance(teacher_timetable, str, "Teacher timetable should be a string")
        self.assertGreater(len(teacher_timetable), 0, "Teacher timetable should not be empty")
    
    def test_data_management(self):
        """Test that data management functions work correctly."""
        # Clear existing data
        self.tg.teachers = {}
        self.tg.classes = {}
        self.tg.subjects = {}
        self.tg.rooms = {}
        
        # Test adding a teacher
        teacher_result = self.tg.add_teacher(
            teacher_id="T1",
            name="John Smith",
            subjects=["MATH", "PHYS"],
            max_hours=25
        )
        self.assertIn("T1", self.tg.teachers, "Teacher should be added")
        self.assertEqual(self.tg.teachers["T1"]["name"], "John Smith", "Teacher name should be set")
        
        # Test adding a subject
        subject_result = self.tg.add_subject(
            subject_id="MATH",
            name="Mathematics",
            requires_specialized_room=False,
            consecutive_periods_preferred=True
        )
        self.assertIn("MATH", self.tg.subjects, "Subject should be added")
        self.assertEqual(self.tg.subjects["MATH"]["name"], "Mathematics", "Subject name should be set")
        
        # Test adding a room
        room_result = self.tg.add_room(
            room_id="R1",
            name="Room 101",
            capacity=30,
            room_type="general"
        )
        self.assertIn("R1", self.tg.rooms, "Room should be added")
        self.assertEqual(self.tg.rooms["R1"]["name"], "Room 101", "Room name should be set")
        
        # Test adding a class
        class_result = self.tg.add_class(
            class_id="C1",
            name="Class 10A",
            homeroom_teacher="T1",
            grade_level=10
        )
        self.assertIn("C1", self.tg.classes, "Class should be added")
        self.assertEqual(self.tg.classes["C1"]["name"], "Class 10A", "Class name should be set")
        
        # Test adding a subject to a class
        class_subject_result = self.tg.add_class_subject(
            class_id="C1",
            subject_id="MATH",
            hours_per_week=5,
            teacher_id="T1"
        )
        self.assertGreater(len(self.tg.classes["C1"]["subjects"]), 0, "Subject should be added to class")
        self.assertEqual(self.tg.classes["C1"]["subjects"][0]["subject_id"], "MATH", "Subject ID should be set")
        self.assertEqual(self.tg.classes["C1"]["subjects"][0]["hours_per_week"], 5, "Hours per week should be set")
    
    def test_data_export_import(self):
        """Test that data export and import work correctly."""
        # Create some data
        self.tg.create_sample_data()
        
        # Export data
        export_file = "test_timetable_data_export.json"
        export_result = self.tg.export_data(export_file)
        self.assertTrue(os.path.exists(export_file), "Export file should be created")
        
        # Clear existing data
        original_teachers = len(self.tg.teachers)
        self.tg.teachers = {}
        self.tg.classes = {}
        self.tg.subjects = {}
        self.tg.rooms = {}
        
        # Import data
        import_result = self.tg.import_data(export_file)
        self.assertEqual(len(self.tg.teachers), original_teachers, "Teachers should be imported")
        
        # Clean up
        if os.path.exists(export_file):
            os.remove(export_file)

class TestTimetableIntegration(unittest.TestCase):
    """Test case for the integration of Timetable Generator with the main application."""
    
    @patch('builtins.input', side_effect=['8', '0'])
    def test_timetable_menu_access(self, mock_input):
        """Test that the timetable menu can be accessed from the main menu."""
        # This would normally import and test the SmartTeacherAI class,
        # but for simplicity, we'll just verify the timetable module can be imported
        # and that it has the expected methods
        
        # Import the main module
        import main
        
        # Check that the SmartTeacherAI class exists
        self.assertTrue(hasattr(main, 'SmartTeacherAI'), "SmartTeacherAI class should exist")
        
        # Create an instance with mocked modules
        with patch.object(main, 'TimetableGenerator', return_value=MagicMock()):
            app = main.SmartTeacherAI()
            
            # Check that the timetable module is initialized
            self.assertIn('timetable', app.modules, "Timetable module should be initialized")
            
            # Check that the timetable menu method exists
            self.assertTrue(hasattr(app, '_timetable_menu'), "Timetable menu method should exist")
            
            # Check that the timetable workflow methods exist
            self.assertTrue(hasattr(app, '_create_timetable_workflow'), "Create timetable workflow method should exist")
            self.assertTrue(hasattr(app, '_manage_school_data_workflow'), "Manage school data workflow method should exist")
            self.assertTrue(hasattr(app, '_view_timetables_workflow'), "View timetables workflow method should exist")

def main():
    """Run the tests."""
    unittest.main(argv=['first-arg-is-ignored'], exit=False)

if __name__ == "__main__":
    main()
