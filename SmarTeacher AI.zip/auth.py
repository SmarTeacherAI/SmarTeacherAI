"""
SMART TEACHER AI - Authentication API

This module provides API endpoints for user authentication.
"""

from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity
import json
import os
from datetime import datetime, timedelta
import bcrypt

# Create blueprint
auth_bp = Blueprint('auth', __name__)

# Mock database for development (will be replaced with actual database)
USERS_DB = [
    {
        'id': 'user_1',
        'name': 'Demo Teacher',
        'email': 'teacher@example.com',
        'password_hash': bcrypt.hashpw('password123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
        'role': 'teacher',
        'created_at': datetime.now().isoformat()
    }
]

@auth_bp.route('/api/auth/register', methods=['POST'])
def register():
    """Register a new user."""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['name', 'email', 'password']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # Check if email already exists
    if any(user['email'] == data['email'] for user in USERS_DB):
        return jsonify({
            'success': False,
            'message': 'Email already registered'
        }), 400
    
    # Create new user
    new_user = {
        'id': f'user_{len(USERS_DB) + 1}',
        'name': data['name'],
        'email': data['email'],
        'password_hash': bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
        'role': data.get('role', 'teacher'),
        'created_at': datetime.now().isoformat()
    }
    
    # Save to database (in a real app, this would insert into the database)
    USERS_DB.append(new_user)
    
    # Create tokens
    access_token = create_access_token(identity=new_user['id'])
    refresh_token = create_refresh_token(identity=new_user['id'])
    
    return jsonify({
        'success': True,
        'message': 'User registered successfully',
        'data': {
            'access_token': access_token,
            'refresh_token': refresh_token,
            'user': {
                'id': new_user['id'],
                'name': new_user['name'],
                'email': new_user['email'],
                'role': new_user['role']
            }
        }
    }), 201

@auth_bp.route('/api/auth/login', methods=['POST'])
def login():
    """Login a user."""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['email', 'password']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # Find user by email
    user = next((user for user in USERS_DB if user['email'] == data['email']), None)
    
    if not user:
        return jsonify({
            'success': False,
            'message': 'Invalid email or password'
        }), 401
    
    # Verify password
    if not bcrypt.checkpw(data['password'].encode('utf-8'), user['password_hash'].encode('utf-8')):
        return jsonify({
            'success': False,
            'message': 'Invalid email or password'
        }), 401
    
    # Create tokens
    access_token = create_access_token(identity=user['id'])
    refresh_token = create_refresh_token(identity=user['id'])
    
    return jsonify({
        'success': True,
        'message': 'Login successful',
        'data': {
            'access_token': access_token,
            'refresh_token': refresh_token,
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'role': user['role']
            }
        }
    }), 200

@auth_bp.route('/api/auth/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """Refresh access token."""
    current_user = get_jwt_identity()
    
    # Find user by ID
    user = next((user for user in USERS_DB if user['id'] == current_user), None)
    
    if not user:
        return jsonify({
            'success': False,
            'message': 'User not found'
        }), 404
    
    # Create new access token
    access_token = create_access_token(identity=current_user)
    
    return jsonify({
        'success': True,
        'message': 'Token refreshed successfully',
        'data': {
            'access_token': access_token,
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'role': user['role']
            }
        }
    }), 200

@auth_bp.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user information."""
    current_user = get_jwt_identity()
    
    # Find user by ID
    user = next((user for user in USERS_DB if user['id'] == current_user), None)
    
    if not user:
        return jsonify({
            'success': False,
            'message': 'User not found'
        }), 404
    
    return jsonify({
        'success': True,
        'data': {
            'user': {
                'id': user['id'],
                'name': user['name'],
                'email': user['email'],
                'role': user['role']
            }
        }
    }), 200

@auth_bp.route('/api/auth/change-password', methods=['POST'])
@jwt_required()
def change_password():
    """Change user password."""
    current_user = get_jwt_identity()
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['current_password', 'new_password']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # Find user by ID
    user_index = next((i for i, user in enumerate(USERS_DB) if user['id'] == current_user), None)
    
    if user_index is None:
        return jsonify({
            'success': False,
            'message': 'User not found'
        }), 404
    
    # Verify current password
    if not bcrypt.checkpw(data['current_password'].encode('utf-8'), USERS_DB[user_index]['password_hash'].encode('utf-8')):
        return jsonify({
            'success': False,
            'message': 'Current password is incorrect'
        }), 401
    
    # Update password
    USERS_DB[user_index]['password_hash'] = bcrypt.hashpw(data['new_password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    return jsonify({
        'success': True,
        'message': 'Password changed successfully'
    }), 200

@auth_bp.route('/api/auth/forgot-password', methods=['POST'])
def forgot_password():
    """Initiate password reset process."""
    data = request.get_json()
    
    # Validate required fields
    if 'email' not in data:
        return jsonify({
            'success': False,
            'message': 'Missing required field: email'
        }), 400
    
    # Find user by email
    user = next((user for user in USERS_DB if user['email'] == data['email']), None)
    
    if not user:
        # For security reasons, don't reveal if email exists or not
        return jsonify({
            'success': True,
            'message': 'If your email is registered, you will receive a password reset link'
        }), 200
    
    # In a real app, this would send an email with a reset link
    # For now, we'll just return a success message
    
    return jsonify({
        'success': True,
        'message': 'If your email is registered, you will receive a password reset link'
    }), 200

@auth_bp.route('/api/auth/reset-password', methods=['POST'])
def reset_password():
    """Reset user password with token."""
    data = request.get_json()
    
    # Validate required fields
    required_fields = ['token', 'new_password']
    for field in required_fields:
        if field not in data:
            return jsonify({
                'success': False,
                'message': f'Missing required field: {field}'
            }), 400
    
    # In a real app, this would verify the token and reset the password
    # For now, we'll just return a success message
    
    return jsonify({
        'success': True,
        'message': 'Password reset successfully'
    }), 200
