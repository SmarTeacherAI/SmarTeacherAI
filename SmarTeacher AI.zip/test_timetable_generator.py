"""
Test script for the Timetable Generator module of SMART TEACHER AI.

This script demonstrates the functionality of the timetable generator
by creating sample data, generating a timetable, and displaying the results.
"""

import os
import sys
import json
from datetime import datetime

# Add parent directory to path to import modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import the TimetableGenerator class
from modules.timetable_generator import TimetableGenerator

def test_timetable_generator():
    """Test the TimetableGenerator functionality."""
    print("=== SMART TEACHER AI: Timetable Generator Test ===")
    
    # Create a new TimetableGenerator instance
    tg = TimetableGenerator()
    print("\nTimetable Generator initialized.")
    
    # Create sample data
    print("\nCreating sample data...")
    sample_data = tg.create_sample_data()
    print(f"Created {sample_data['teachers']} teachers, {sample_data['classes']} classes, "
          f"{sample_data['subjects']} subjects, and {sample_data['rooms']} rooms.")
    
    # Configure the timetable generator
    print("\nConfiguring timetable generator...")
    config = tg.configure({
        "periods_per_day": 8,
        "days_per_week": 5,
        "optimization_level": "standard"
    })
    print(f"Configuration updated: {config}")
    
    # Generate the timetable
    print("\nGenerating timetable...")
    result = tg.generate_timetable()
    
    if result["success"]:
        print(f"Timetable generated successfully in {result['generation_time']:.2f} seconds.")
        
        if "warnings" in result and result["warnings"]:
            print("\nWarnings:")
            for warning in result["warnings"]:
                print(f"- {warning}")
        
        # Print statistics
        stats = result["statistics"]
        print("\nTimetable Statistics:")
        print(f"Total allocations: {stats['total_allocations']}")
        
        print("\nTeacher Hours:")
        for teacher_id, hours in stats["teacher_hours"].items():
            teacher_name = tg.teachers[teacher_id]["name"]
            print(f"- {teacher_name}: {hours} hours")
        
        print("\nRoom Utilization:")
        for room_id, data in stats["room_utilization"].items():
            room_name = tg.rooms[room_id]["name"]
            print(f"- {room_name}: {data['hours']} hours ({data['utilization_percent']:.1f}%)")
        
        # Export the timetable to JSON
        output_file = "timetable_export.json"
        export_result = tg.export_timetable("json", output_file)
        
        if "success" in export_result and export_result["success"]:
            print(f"\nTimetable exported to {output_file}")
        else:
            print(f"\nFailed to export timetable: {export_result.get('error', 'Unknown error')}")
        
        # Print sample timetables
        print("\n=== Sample Class Timetable ===")
        class_id = list(tg.classes.keys())[0]
        class_name = tg.classes[class_id]["name"]
        print(f"Timetable for {class_name}:")
        print(tg.print_class_timetable(class_id))
        
        print("\n=== Sample Teacher Timetable ===")
        teacher_id = list(tg.teachers.keys())[0]
        teacher_name = tg.teachers[teacher_id]["name"]
        print(f"Timetable for {teacher_name}:")
        print(tg.print_teacher_timetable(teacher_id))
        
    else:
        print("Failed to generate timetable.")
        if "errors" in result:
            print("\nErrors:")
            for error in result["errors"]:
                print(f"- {error}")

def main():
    """Main function to run the test."""
    test_timetable_generator()

if __name__ == "__main__":
    main()
