import React, { useState, useEffect } from 'react';
import axios from 'axios';
import LoadingSpinner from '../common/LoadingSpinner';
import Alert from '../common/Alert';

const ClassTimetable = ({ timetableId, classId }) => {
  const [timetable, setTimetable] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (timetableId && classId) {
      fetchClassTimetable();
    }
  }, [timetableId, classId]);

  const fetchClassTimetable = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/api/timetables/${timetableId}/class/${classId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setTimetable(response.data.data);
      setError(null);
    } catch (err) {
      console.error('Error fetching class timetable:', err);
      setError('Failed to load class timetable. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <Alert type="danger" message={error} />;
  }

  if (!timetable) {
    return <Alert type="warning" message="No timetable data available for this class." />;
  }

  return (
    <div>
      <h4 className="mb-3">Timetable for {timetable.class_name}</h4>
      
      <div className="timetable-grid">
        <div className="timetable-header">Period</div>
        {timetable.days.map(day => (
          <div key={day} className="timetable-header">{day}</div>
        ))}
        
        {Array.from({ length: timetable.periods_per_day }, (_, i) => i + 1).map(period => (
          <React.Fragment key={period}>
            <div className="timetable-period">{period}</div>
            
            {timetable.days.map(day => {
              const periodData = timetable.schedule
                .find(d => d.day === day)?.periods
                .find(p => p.period === period);
                
              return (
                <div key={`${day}-${period}`} className="timetable-cell">
                  {periodData ? (
                    <>
                      <div className="timetable-subject">{periodData.subject}</div>
                      <div className="timetable-teacher">{periodData.teacher}</div>
                      <div className="timetable-room">{periodData.room}</div>
                    </>
                  ) : (
                    <div className="text-muted">Free Period</div>
                  )}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
};

export default ClassTimetable;
