"""
Timetable Generator Module for SMART TEACHER AI

This module provides functionality for creating and managing school timetables,
including class schedules, teacher assignments, and resource allocation.
"""

import random
import datetime
import json
import os
from typing import Dict, List, Tuple, Set, Optional, Any, Union
import numpy as np
import pandas as pd
from collections import defaultdict

class TimetableGenerator:
    """
    Class for generating and managing school timetables.
    
    Features:
    - Create master timetables for entire schools
    - Generate individual teacher schedules
    - Create class timetables
    - Manage room allocations
    - Handle subject constraints and preferences
    - Export timetables in various formats
    """
    
    def __init__(self):
        """Initialize the TimetableGenerator with default settings."""
        # Core data structures
        self.teachers = {}  # teacher_id -> teacher data
        self.classes = {}   # class_id -> class data
        self.subjects = {}  # subject_id -> subject data
        self.rooms = {}     # room_id -> room data
        self.periods = []   # list of period definitions
        self.days = []      # list of days in timetable
        
        # Constraints and preferences
        self.teacher_preferences = {}  # teacher_id -> preferences
        self.subject_constraints = {}  # subject_id -> constraints
        self.room_constraints = {}     # room_id -> constraints
        
        # Generated timetables
        self.master_timetable = {}     # Complete school timetable
        self.teacher_timetables = {}   # Individual teacher timetables
        self.class_timetables = {}     # Individual class timetables
        self.room_timetables = {}      # Room usage timetables
        
        # Configuration
        self.config = {
            "periods_per_day": 8,
            "days_per_week": 5,
            "max_consecutive_periods": 3,
            "lunch_period": 4,
            "allow_split_subjects": True,
            "prioritize_teacher_preferences": True,
            "balance_subject_distribution": True,
            "optimization_level": "standard"  # basic, standard, advanced
        }
        
        # Default period structure
        self._initialize_default_periods()
        
        # Default days
        self._initialize_default_days()
        
        print("Timetable Generator initialized")
    
    def _initialize_default_periods(self):
        """Set up default period structure."""
        self.periods = [
            {"id": 1, "name": "Period 1", "start_time": "08:00", "end_time": "08:50"},
            {"id": 2, "name": "Period 2", "start_time": "08:55", "end_time": "09:45"},
            {"id": 3, "name": "Period 3", "start_time": "09:50", "end_time": "10:40"},
            {"id": 4, "name": "Break", "start_time": "10:40", "end_time": "11:00"},
            {"id": 5, "name": "Period 4", "start_time": "11:00", "end_time": "11:50"},
            {"id": 6, "name": "Period 5", "start_time": "11:55", "end_time": "12:45"},
            {"id": 7, "name": "Lunch", "start_time": "12:45", "end_time": "13:30"},
            {"id": 8, "name": "Period 6", "start_time": "13:30", "end_time": "14:20"},
            {"id": 9, "name": "Period 7", "start_time": "14:25", "end_time": "15:15"},
            {"id": 10, "name": "Period 8", "start_time": "15:20", "end_time": "16:10"}
        ]
    
    def _initialize_default_days(self):
        """Set up default days of the week."""
        self.days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
    
    def configure(self, config_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update configuration settings.
        
        Args:
            config_dict: Dictionary of configuration settings to update
            
        Returns:
            Updated configuration dictionary
        """
        for key, value in config_dict.items():
            if key in self.config:
                self.config[key] = value
            else:
                print(f"Warning: Unknown configuration key '{key}'")
        
        return self.config
    
    def add_teacher(self, teacher_id: str, name: str, subjects: List[str], 
                   max_hours: int = 30, **kwargs) -> Dict[str, Any]:
        """
        Add a teacher to the system.
        
        Args:
            teacher_id: Unique identifier for the teacher
            name: Teacher's name
            subjects: List of subject IDs the teacher can teach
            max_hours: Maximum teaching hours per week
            **kwargs: Additional teacher attributes
            
        Returns:
            Teacher data dictionary
        """
        if teacher_id in self.teachers:
            print(f"Warning: Teacher ID '{teacher_id}' already exists. Updating.")
        
        teacher_data = {
            "id": teacher_id,
            "name": name,
            "subjects": subjects,
            "max_hours": max_hours,
            **kwargs
        }
        
        self.teachers[teacher_id] = teacher_data
        return teacher_data
    
    def add_class(self, class_id: str, name: str, homeroom_teacher: str,
                 grade_level: int, **kwargs) -> Dict[str, Any]:
        """
        Add a class to the system.
        
        Args:
            class_id: Unique identifier for the class
            name: Class name
            homeroom_teacher: Teacher ID of homeroom teacher
            grade_level: Grade level of the class
            **kwargs: Additional class attributes
            
        Returns:
            Class data dictionary
        """
        if class_id in self.classes:
            print(f"Warning: Class ID '{class_id}' already exists. Updating.")
        
        class_data = {
            "id": class_id,
            "name": name,
            "homeroom_teacher": homeroom_teacher,
            "grade_level": grade_level,
            "subjects": [],  # Will be populated with add_class_subject
            **kwargs
        }
        
        self.classes[class_id] = class_data
        return class_data
    
    def add_class_subject(self, class_id: str, subject_id: str, 
                         hours_per_week: int, teacher_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Add a subject to a class's curriculum.
        
        Args:
            class_id: Class identifier
            subject_id: Subject identifier
            hours_per_week: Number of hours per week for this subject
            teacher_id: Preferred teacher for this subject (optional)
            
        Returns:
            Updated class subject entry
        """
        if class_id not in self.classes:
            raise ValueError(f"Class ID '{class_id}' not found")
        
        if subject_id not in self.subjects:
            raise ValueError(f"Subject ID '{subject_id}' not found")
        
        # Check if subject already exists for this class
        for i, subj in enumerate(self.classes[class_id]["subjects"]):
            if subj["subject_id"] == subject_id:
                # Update existing subject
                self.classes[class_id]["subjects"][i]["hours_per_week"] = hours_per_week
                if teacher_id:
                    self.classes[class_id]["subjects"][i]["teacher_id"] = teacher_id
                return self.classes[class_id]["subjects"][i]
        
        # Add new subject to class
        subject_entry = {
            "subject_id": subject_id,
            "hours_per_week": hours_per_week,
            "teacher_id": teacher_id
        }
        
        self.classes[class_id]["subjects"].append(subject_entry)
        return subject_entry
    
    def add_subject(self, subject_id: str, name: str, requires_specialized_room: bool = False,
                   consecutive_periods_preferred: bool = False, **kwargs) -> Dict[str, Any]:
        """
        Add a subject to the system.
        
        Args:
            subject_id: Unique identifier for the subject
            name: Subject name
            requires_specialized_room: Whether this subject needs a specialized room
            consecutive_periods_preferred: Whether consecutive periods are preferred
            **kwargs: Additional subject attributes
            
        Returns:
            Subject data dictionary
        """
        if subject_id in self.subjects:
            print(f"Warning: Subject ID '{subject_id}' already exists. Updating.")
        
        subject_data = {
            "id": subject_id,
            "name": name,
            "requires_specialized_room": requires_specialized_room,
            "consecutive_periods_preferred": consecutive_periods_preferred,
            **kwargs
        }
        
        self.subjects[subject_id] = subject_data
        return subject_data
    
    def add_room(self, room_id: str, name: str, capacity: int, 
                room_type: str = "general", **kwargs) -> Dict[str, Any]:
        """
        Add a room to the system.
        
        Args:
            room_id: Unique identifier for the room
            name: Room name or number
            capacity: Maximum capacity of the room
            room_type: Type of room (general, science, computer, etc.)
            **kwargs: Additional room attributes
            
        Returns:
            Room data dictionary
        """
        if room_id in self.rooms:
            print(f"Warning: Room ID '{room_id}' already exists. Updating.")
        
        room_data = {
            "id": room_id,
            "name": name,
            "capacity": capacity,
            "room_type": room_type,
            **kwargs
        }
        
        self.rooms[room_id] = room_data
        return room_data
    
    def set_teacher_preferences(self, teacher_id: str, preferences: Dict[str, Any]) -> Dict[str, Any]:
        """
        Set preferences for a teacher.
        
        Args:
            teacher_id: Teacher identifier
            preferences: Dictionary of preferences (e.g., preferred_days, preferred_times)
            
        Returns:
            Updated preferences dictionary
        """
        if teacher_id not in self.teachers:
            raise ValueError(f"Teacher ID '{teacher_id}' not found")
        
        if teacher_id not in self.teacher_preferences:
            self.teacher_preferences[teacher_id] = {}
        
        self.teacher_preferences[teacher_id].update(preferences)
        return self.teacher_preferences[teacher_id]
    
    def set_subject_constraints(self, subject_id: str, constraints: Dict[str, Any]) -> Dict[str, Any]:
        """
        Set constraints for a subject.
        
        Args:
            subject_id: Subject identifier
            constraints: Dictionary of constraints
            
        Returns:
            Updated constraints dictionary
        """
        if subject_id not in self.subjects:
            raise ValueError(f"Subject ID '{subject_id}' not found")
        
        if subject_id not in self.subject_constraints:
            self.subject_constraints[subject_id] = {}
        
        self.subject_constraints[subject_id].update(constraints)
        return self.subject_constraints[subject_id]
    
    def import_data(self, data_file: str) -> Dict[str, int]:
        """
        Import timetable data from a JSON file.
        
        Args:
            data_file: Path to JSON data file
            
        Returns:
            Dictionary with counts of imported items
        """
        try:
            with open(data_file, 'r') as f:
                data = json.load(f)
            
            # Import teachers
            if "teachers" in data:
                for teacher in data["teachers"]:
                    self.add_teacher(**teacher)
            
            # Import subjects
            if "subjects" in data:
                for subject in data["subjects"]:
                    self.add_subject(**subject)
            
            # Import rooms
            if "rooms" in data:
                for room in data["rooms"]:
                    self.add_room(**room)
            
            # Import classes
            if "classes" in data:
                for class_data in data["classes"]:
                    class_subjects = class_data.pop("subjects", [])
                    self.add_class(**class_data)
                    
                    # Add subjects to class
                    for subject in class_subjects:
                        self.add_class_subject(
                            class_id=class_data["class_id"],
                            **subject
                        )
            
            # Import teacher preferences
            if "teacher_preferences" in data:
                for teacher_id, preferences in data["teacher_preferences"].items():
                    self.set_teacher_preferences(teacher_id, preferences)
            
            # Import subject constraints
            if "subject_constraints" in data:
                for subject_id, constraints in data["subject_constraints"].items():
                    self.set_subject_constraints(subject_id, constraints)
            
            # Import configuration
            if "config" in data:
                self.configure(data["config"])
            
            return {
                "teachers": len(self.teachers),
                "classes": len(self.classes),
                "subjects": len(self.subjects),
                "rooms": len(self.rooms)
            }
            
        except Exception as e:
            print(f"Error importing data: {str(e)}")
            return {"error": str(e)}
    
    def export_data(self, output_file: str) -> bool:
        """
        Export timetable data to a JSON file.
        
        Args:
            output_file: Path to output JSON file
            
        Returns:
            True if successful, False otherwise
        """
        try:
            data = {
                "teachers": list(self.teachers.values()),
                "classes": list(self.classes.values()),
                "subjects": list(self.subjects.values()),
                "rooms": list(self.rooms.values()),
                "teacher_preferences": self.teacher_preferences,
                "subject_constraints": self.subject_constraints,
                "config": self.config
            }
            
            with open(output_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            print(f"Error exporting data: {str(e)}")
            return False
    
    def generate_timetable(self) -> Dict[str, Any]:
        """
        Generate a complete school timetable.
        
        Returns:
            Dictionary with generation results and statistics
        """
        print("Generating timetable...")
        start_time = datetime.datetime.now()
        
        # Initialize empty timetable structures
        self._initialize_timetable_structures()
        
        # Validate input data
        validation_result = self._validate_input_data()
        if not validation_result["valid"]:
            return {"success": False, "errors": validation_result["errors"]}
        
        # Generate initial timetable
        self._generate_initial_timetable()
        
        # Optimize timetable
        optimization_level = self.config["optimization_level"]
        if optimization_level == "basic":
            self._basic_optimization()
        elif optimization_level == "standard":
            self._standard_optimization()
        elif optimization_level == "advanced":
            self._advanced_optimization()
        
        # Validate final timetable
        validation_result = self._validate_timetable()
        
        # Generate individual timetables
        self._generate_individual_timetables()
        
        end_time = datetime.datetime.now()
        generation_time = (end_time - start_time).total_seconds()
        
        # Prepare result statistics
        stats = self._calculate_timetable_statistics()
        
        result = {
            "success": validation_result["valid"],
            "errors": validation_result.get("errors", []),
            "warnings": validation_result.get("warnings", []),
            "statistics": stats,
            "generation_time": generation_time
        }
        
        print(f"Timetable generation completed in {generation_time:.2f} seconds")
        return result
    
    def _initialize_timetable_structures(self):
        """Initialize empty timetable data structures."""
        # Master timetable: day -> period -> class_id -> {subject_id, teacher_id, room_id}
        self.master_timetable = {}
        for day in self.days:
            self.master_timetable[day] = {}
            for period in self.periods:
                self.master_timetable[day][period["id"]] = {}
        
        # Empty teacher, class, and room timetables
        self.teacher_timetables = {teacher_id: {} for teacher_id in self.teachers}
        self.class_timetables = {class_id: {} for class_id in self.classes}
        self.room_timetables = {room_id: {} for room_id in self.rooms}
    
    def _validate_input_data(self) -> Dict[str, Any]:
        """
        Validate input data before timetable generation.
        
        Returns:
            Dictionary with validation results
        """
        errors = []
        warnings = []
        
        # Check if we have teachers, classes, subjects, and rooms
        if not self.teachers:
            errors.append("No teachers defined")
        if not self.classes:
            errors.append("No classes defined")
        if not self.subjects:
            errors.append("No subjects defined")
        if not self.rooms:
            errors.append("No rooms defined")
        
        # Check if classes have subjects assigned
        for class_id, class_data in self.classes.items():
            if not class_data["subjects"]:
                errors.append(f"Class '{class_id}' has no subjects assigned")
        
        # Check if teachers can cover all required subjects
        subject_teachers = defaultdict(list)
        for teacher_id, teacher_data in self.teachers.items():
            for subject_id in teacher_data["subjects"]:
                subject_teachers[subject_id].append(teacher_id)
        
        for subject_id in self.subjects:
            if not subject_teachers[subject_id]:
                errors.append(f"No teachers available for subject '{subject_id}'")
        
        # Check if specialized rooms are available for subjects that need them
        specialized_rooms = defaultdict(list)
        for room_id, room_data in self.rooms.items():
            if room_data["room_type"] != "general":
                specialized_rooms[room_data["room_type"]].append(room_id)
        
        for subject_id, subject_data in self.subjects.items():
            if subject_data["requires_specialized_room"]:
                room_type = subject_data.get("preferred_room_type", "")
                if not room_type:
                    warnings.append(f"Subject '{subject_id}' requires specialized room but no preferred room type specified")
                elif not specialized_rooms[room_type]:
                    errors.append(f"Subject '{subject_id}' requires room type '{room_type}' but none available")
        
        # Check teacher workload
        for class_id, class_data in self.classes.items():
            for subject in class_data["subjects"]:
                teacher_id = subject.get("teacher_id")
                if teacher_id and teacher_id not in self.teachers:
                    errors.append(f"Unknown teacher '{teacher_id}' assigned to class '{class_id}'")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
    
    def _generate_initial_timetable(self):
        """Generate initial timetable using constraint-based approach."""
        # For each class, distribute subjects across the week
        for class_id, class_data in self.classes.items():
            self._allocate_class_subjects(class_id, class_data)
    
    def _allocate_class_subjects(self, class_id: str, class_data: Dict[str, Any]):
        """
        Allocate subjects for a specific class across the timetable.
        
        Args:
            class_id: Class identifier
            class_data: Class data dictionary
        """
        # Calculate total hours per week for this class
        total_hours = sum(subject["hours_per_week"] for subject in class_data["subjects"])
        
        # Get available periods (excluding breaks, lunch)
        available_periods = [p["id"] for p in self.periods if p["name"] not in ["Break", "Lunch"]]
        total_available_periods = len(available_periods) * len(self.days)
        
        if total_hours > total_available_periods:
            print(f"Warning: Class '{class_id}' has more subject hours ({total_hours}) than available periods ({total_available_periods})")
        
        # Sort subjects by hours (descending) to allocate larger subjects first
        sorted_subjects = sorted(class_data["subjects"], key=lambda x: x["hours_per_week"], reverse=True)
        
        # For each subject, allocate required hours
        for subject in sorted_subjects:
            subject_id = subject["subject_id"]
            hours_needed = subject["hours_per_week"]
            preferred_teacher = subject.get("teacher_id")
            
            # Find suitable teachers if not specified
            suitable_teachers = self._find_suitable_teachers(subject_id, preferred_teacher)
            
            # Get subject constraints
            subject_data = self.subjects[subject_id]
            consecutive_preferred = subject_data.get("consecutive_periods_preferred", False)
            requires_specialized_room = subject_data.get("requires_specialized_room", False)
            preferred_room_type = subject_data.get("preferred_room_type", "")
            
            # Allocate hours
            hours_allocated = 0
            
            # If consecutive periods preferred, try to allocate in blocks
            if consecutive_preferred and hours_needed >= 2:
                # Allocate in blocks of 2 or 3 periods
                while hours_allocated < hours_needed:
                    block_size = min(3, hours_needed - hours_allocated)
                    if block_size < 2:
                        break  # Allocate remaining single periods normally
                    
                    # Try to find a suitable block
                    allocated = self._allocate_consecutive_periods(
                        class_id, subject_id, suitable_teachers, 
                        requires_specialized_room, preferred_room_type, block_size
                    )
                    
                    if allocated:
                        hours_allocated += block_size
                    else:
                        # If can't allocate a block, try smaller block
                        if block_size > 2:
                            block_size = 2
                            allocated = self._allocate_consecutive_periods(
                                class_id, subject_id, suitable_teachers, 
                                requires_specialized_room, preferred_room_type, block_size
                            )
                            if allocated:
                                hours_allocated += block_size
                            else:
                                break  # Can't allocate blocks, switch to single periods
                        else:
                            break  # Can't allocate blocks, switch to single periods
            
            # Allocate remaining hours as single periods
            while hours_allocated < hours_needed:
                allocated = self._allocate_single_period(
                    class_id, subject_id, suitable_teachers,
                    requires_specialized_room, preferred_room_type
                )
                
                if allocated:
                    hours_allocated += 1
                else:
                    print(f"Warning: Could not allocate all hours for subject '{subject_id}' in class '{class_id}'")
                    break
    
    def _find_suitable_teachers(self, subject_id: str, preferred_teacher: Optional[str] = None) -> List[str]:
        """
        Find suitable teachers for a subject.
        
        Args:
            subject_id: Subject identifier
            preferred_teacher: Preferred teacher ID (optional)
            
        Returns:
            List of suitable teacher IDs, sorted by preference
        """
        suitable_teachers = []
        
        # If preferred teacher is specified and can teach the subject, prioritize them
        if preferred_teacher and preferred_teacher in self.teachers:
            teacher_data = self.teachers[preferred_teacher]
            if subject_id in teacher_data["subjects"]:
                suitable_teachers.append(preferred_teacher)
        
        # Add other teachers who can teach this subject
        for teacher_id, teacher_data in self.teachers.items():
            if teacher_id != preferred_teacher and subject_id in teacher_data["subjects"]:
                suitable_teachers.append(teacher_id)
        
        return suitable_teachers
    
    def _allocate_consecutive_periods(self, class_id: str, subject_id: str, 
                                     teacher_ids: List[str], requires_specialized_room: bool,
                                     preferred_room_type: str, block_size: int) -> bool:
        """
        Allocate consecutive periods for a subject.
        
        Args:
            class_id: Class identifier
            subject_id: Subject identifier
            teacher_ids: List of suitable teacher IDs
            requires_specialized_room: Whether subject requires specialized room
            preferred_room_type: Preferred room type
            block_size: Number of consecutive periods to allocate
            
        Returns:
            True if allocation successful, False otherwise
        """
        # Try each day and starting period
        for day in self.days:
            # Get teaching periods (exclude breaks, lunch)
            teaching_periods = [p["id"] for p in self.periods if p["name"] not in ["Break", "Lunch"]]
            
            # Check each possible starting period
            for start_idx in range(len(teaching_periods) - block_size + 1):
                period_block = teaching_periods[start_idx:start_idx + block_size]
                
                # Check if all periods in block are available for this class
                if not all(class_id not in self.master_timetable[day][period] 
                          for period in period_block):
                    continue
                
                # Try to find a teacher available for all periods in the block
                for teacher_id in teacher_ids:
                    teacher_available = True
                    for period in period_block:
                        # Check if teacher is already teaching in this period
                        for c_id, allocation in self.master_timetable[day][period].items():
                            if allocation.get("teacher_id") == teacher_id:
                                teacher_available = False
                                break
                        if not teacher_available:
                            break
                    
                    if not teacher_available:
                        continue
                    
                    # Find a suitable room for all periods in the block
                    suitable_room = self._find_suitable_room(
                        day, period_block, requires_specialized_room, preferred_room_type
                    )
                    
                    if not suitable_room:
                        continue
                    
                    # Allocate all periods in the block
                    for period in period_block:
                        self.master_timetable[day][period][class_id] = {
                            "subject_id": subject_id,
                            "teacher_id": teacher_id,
                            "room_id": suitable_room
                        }
                    
                    return True
        
        return False
    
    def _allocate_single_period(self, class_id: str, subject_id: str,
                               teacher_ids: List[str], requires_specialized_room: bool,
                               preferred_room_type: str) -> bool:
        """
        Allocate a single period for a subject.
        
        Args:
            class_id: Class identifier
            subject_id: Subject identifier
            teacher_ids: List of suitable teacher IDs
            requires_specialized_room: Whether subject requires specialized room
            preferred_room_type: Preferred room type
            
        Returns:
            True if allocation successful, False otherwise
        """
        # Try to distribute subjects evenly across the week
        # First, count current allocations by day
        day_counts = {day: 0 for day in self.days}
        for day in self.days:
            for period in self.periods:
                if class_id in self.master_timetable[day][period["id"]]:
                    if self.master_timetable[day][period["id"]][class_id].get("subject_id") == subject_id:
                        day_counts[day] += 1
        
        # Sort days by current allocation count (ascending)
        sorted_days = sorted(self.days, key=lambda d: day_counts[d])
        
        # Try each day and period
        for day in sorted_days:
            # Get teaching periods (exclude breaks, lunch)
            teaching_periods = [p["id"] for p in self.periods if p["name"] not in ["Break", "Lunch"]]
            
            # Randomize period order to avoid always starting from the same period
            random.shuffle(teaching_periods)
            
            for period in teaching_periods:
                # Check if period is available for this class
                if class_id in self.master_timetable[day][period]:
                    continue
                
                # Try to find an available teacher
                for teacher_id in teacher_ids:
                    # Check if teacher is already teaching in this period
                    teacher_available = True
                    for c_id, allocation in self.master_timetable[day][period].items():
                        if allocation.get("teacher_id") == teacher_id:
                            teacher_available = False
                            break
                    
                    if not teacher_available:
                        continue
                    
                    # Find a suitable room
                    suitable_room = self._find_suitable_room(
                        day, [period], requires_specialized_room, preferred_room_type
                    )
                    
                    if not suitable_room:
                        continue
                    
                    # Allocate the period
                    self.master_timetable[day][period][class_id] = {
                        "subject_id": subject_id,
                        "teacher_id": teacher_id,
                        "room_id": suitable_room
                    }
                    
                    return True
        
        return False
    
    def _find_suitable_room(self, day: str, periods: List[int], 
                           requires_specialized_room: bool, 
                           preferred_room_type: str) -> Optional[str]:
        """
        Find a suitable room available for all specified periods.
        
        Args:
            day: Day of the week
            periods: List of period IDs
            requires_specialized_room: Whether subject requires specialized room
            preferred_room_type: Preferred room type
            
        Returns:
            Room ID if found, None otherwise
        """
        # Filter rooms by type if needed
        candidate_rooms = []
        if requires_specialized_room and preferred_room_type:
            for room_id, room_data in self.rooms.items():
                if room_data["room_type"] == preferred_room_type:
                    candidate_rooms.append(room_id)
        else:
            candidate_rooms = list(self.rooms.keys())
        
        # Check each room for availability in all periods
        for room_id in candidate_rooms:
            room_available = True
            for period in periods:
                for class_allocation in self.master_timetable[day][period].values():
                    if class_allocation.get("room_id") == room_id:
                        room_available = False
                        break
                if not room_available:
                    break
            
            if room_available:
                return room_id
        
        return None
    
    def _basic_optimization(self):
        """Perform basic timetable optimization."""
        # Simple optimization: try to reduce teacher "holes" in schedule
        self._reduce_teacher_gaps()
    
    def _standard_optimization(self):
        """Perform standard timetable optimization."""
        # Run basic optimization first
        self._basic_optimization()
        
        # Additional optimizations
        self._balance_teacher_workload()
        self._improve_room_utilization()
    
    def _advanced_optimization(self):
        """Perform advanced timetable optimization using metaheuristics."""
        # Run standard optimization first
        self._standard_optimization()
        
        # Additional advanced optimizations
        self._apply_simulated_annealing()
    
    def _reduce_teacher_gaps(self):
        """Try to reduce gaps in teacher schedules."""
        # Implementation would involve identifying and swapping periods
        # to minimize gaps in teacher schedules
        pass
    
    def _balance_teacher_workload(self):
        """Try to balance daily workload for teachers."""
        # Implementation would involve identifying and swapping periods
        # to balance the number of teaching periods per day for each teacher
        pass
    
    def _improve_room_utilization(self):
        """Try to improve room utilization."""
        # Implementation would involve identifying and swapping room allocations
        # to maximize utilization of specialized rooms
        pass
    
    def _apply_simulated_annealing(self):
        """Apply simulated annealing algorithm for timetable optimization."""
        # Implementation would involve a more sophisticated optimization approach
        # using simulated annealing to find near-optimal solutions
        pass
    
    def _validate_timetable(self) -> Dict[str, Any]:
        """
        Validate the generated timetable.
        
        Returns:
            Dictionary with validation results
        """
        errors = []
        warnings = []
        
        # Check for teacher conflicts (teaching multiple classes in same period)
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                teacher_classes = defaultdict(list)
                
                for class_id, allocation in self.master_timetable[day][period].items():
                    teacher_id = allocation.get("teacher_id")
                    if teacher_id:
                        teacher_classes[teacher_id].append(class_id)
                
                for teacher_id, classes in teacher_classes.items():
                    if len(classes) > 1:
                        errors.append(f"Teacher '{teacher_id}' assigned to multiple classes {classes} on {day}, period {period}")
        
        # Check for room conflicts (multiple classes in same room in same period)
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                room_classes = defaultdict(list)
                
                for class_id, allocation in self.master_timetable[day][period].items():
                    room_id = allocation.get("room_id")
                    if room_id:
                        room_classes[room_id].append(class_id)
                
                for room_id, classes in room_classes.items():
                    if len(classes) > 1:
                        errors.append(f"Room '{room_id}' assigned to multiple classes {classes} on {day}, period {period}")
        
        # Check if all required subject hours are allocated
        for class_id, class_data in self.classes.items():
            for subject in class_data["subjects"]:
                subject_id = subject["subject_id"]
                required_hours = subject["hours_per_week"]
                
                # Count allocated hours
                allocated_hours = 0
                for day in self.days:
                    for period_data in self.periods:
                        period = period_data["id"]
                        if class_id in self.master_timetable[day][period]:
                            if self.master_timetable[day][period][class_id].get("subject_id") == subject_id:
                                allocated_hours += 1
                
                if allocated_hours < required_hours:
                    warnings.append(f"Subject '{subject_id}' for class '{class_id}' has {allocated_hours}/{required_hours} hours allocated")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors,
            "warnings": warnings
        }
    
    def _generate_individual_timetables(self):
        """Generate individual timetables for teachers, classes, and rooms."""
        # Generate teacher timetables
        for teacher_id in self.teachers:
            self.teacher_timetables[teacher_id] = self._extract_teacher_timetable(teacher_id)
        
        # Generate class timetables
        for class_id in self.classes:
            self.class_timetables[class_id] = self._extract_class_timetable(class_id)
        
        # Generate room timetables
        for room_id in self.rooms:
            self.room_timetables[room_id] = self._extract_room_timetable(room_id)
    
    def _extract_teacher_timetable(self, teacher_id: str) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Extract timetable for a specific teacher.
        
        Args:
            teacher_id: Teacher identifier
            
        Returns:
            Teacher timetable dictionary
        """
        timetable = {day: {} for day in self.days}
        
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                
                # Check all class allocations for this period
                for class_id, allocation in self.master_timetable[day][period].items():
                    if allocation.get("teacher_id") == teacher_id:
                        timetable[day][period] = {
                            "class_id": class_id,
                            "subject_id": allocation.get("subject_id"),
                            "room_id": allocation.get("room_id")
                        }
        
        return timetable
    
    def _extract_class_timetable(self, class_id: str) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Extract timetable for a specific class.
        
        Args:
            class_id: Class identifier
            
        Returns:
            Class timetable dictionary
        """
        timetable = {day: {} for day in self.days}
        
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                
                if class_id in self.master_timetable[day][period]:
                    allocation = self.master_timetable[day][period][class_id]
                    timetable[day][period] = {
                        "subject_id": allocation.get("subject_id"),
                        "teacher_id": allocation.get("teacher_id"),
                        "room_id": allocation.get("room_id")
                    }
        
        return timetable
    
    def _extract_room_timetable(self, room_id: str) -> Dict[str, Dict[int, Dict[str, Any]]]:
        """
        Extract timetable for a specific room.
        
        Args:
            room_id: Room identifier
            
        Returns:
            Room timetable dictionary
        """
        timetable = {day: {} for day in self.days}
        
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                
                # Check all class allocations for this period
                for class_id, allocation in self.master_timetable[day][period].items():
                    if allocation.get("room_id") == room_id:
                        timetable[day][period] = {
                            "class_id": class_id,
                            "subject_id": allocation.get("subject_id"),
                            "teacher_id": allocation.get("teacher_id")
                        }
        
        return timetable
    
    def _calculate_timetable_statistics(self) -> Dict[str, Any]:
        """
        Calculate statistics for the generated timetable.
        
        Returns:
            Dictionary with timetable statistics
        """
        stats = {
            "total_allocations": 0,
            "teacher_hours": {},
            "subject_hours": {},
            "room_utilization": {},
            "class_hours": {}
        }
        
        # Count total allocations
        for day in self.days:
            for period_data in self.periods:
                period = period_data["id"]
                stats["total_allocations"] += len(self.master_timetable[day][period])
        
        # Calculate teacher hours
        for teacher_id in self.teachers:
            hours = 0
            for day in self.days:
                for period in self.teacher_timetables[teacher_id].get(day, {}):
                    hours += 1
            stats["teacher_hours"][teacher_id] = hours
        
        # Calculate subject hours
        for subject_id in self.subjects:
            hours = 0
            for day in self.days:
                for period_data in self.periods:
                    period = period_data["id"]
                    for allocation in self.master_timetable[day][period].values():
                        if allocation.get("subject_id") == subject_id:
                            hours += 1
            stats["subject_hours"][subject_id] = hours
        
        # Calculate room utilization
        for room_id in self.rooms:
            hours = 0
            for day in self.days:
                for period in self.room_timetables[room_id].get(day, {}):
                    hours += 1
            
            # Calculate as percentage of available teaching periods
            teaching_periods = len([p for p in self.periods if p["name"] not in ["Break", "Lunch"]])
            total_available = teaching_periods * len(self.days)
            utilization = (hours / total_available) * 100 if total_available > 0 else 0
            stats["room_utilization"][room_id] = {
                "hours": hours,
                "utilization_percent": utilization
            }
        
        # Calculate class hours
        for class_id in self.classes:
            hours = 0
            for day in self.days:
                for period in self.class_timetables[class_id].get(day, {}):
                    hours += 1
            stats["class_hours"][class_id] = hours
        
        return stats
    
    def get_teacher_timetable(self, teacher_id: str) -> Dict[str, Any]:
        """
        Get timetable for a specific teacher.
        
        Args:
            teacher_id: Teacher identifier
            
        Returns:
            Teacher timetable with additional information
        """
        if teacher_id not in self.teachers:
            return {"error": f"Teacher ID '{teacher_id}' not found"}
        
        if teacher_id not in self.teacher_timetables:
            return {"error": "Timetable not generated yet"}
        
        result = {
            "teacher": self.teachers[teacher_id],
            "timetable": self.teacher_timetables[teacher_id],
            "statistics": {
                "total_hours": 0,
                "hours_by_subject": {},
                "hours_by_class": {},
                "hours_by_day": {day: 0 for day in self.days}
            }
        }
        
        # Calculate statistics
        for day, periods in self.teacher_timetables[teacher_id].items():
            for period, allocation in periods.items():
                result["statistics"]["total_hours"] += 1
                result["statistics"]["hours_by_day"][day] += 1
                
                subject_id = allocation.get("subject_id")
                if subject_id:
                    if subject_id not in result["statistics"]["hours_by_subject"]:
                        result["statistics"]["hours_by_subject"][subject_id] = 0
                    result["statistics"]["hours_by_subject"][subject_id] += 1
                
                class_id = allocation.get("class_id")
                if class_id:
                    if class_id not in result["statistics"]["hours_by_class"]:
                        result["statistics"]["hours_by_class"][class_id] = 0
                    result["statistics"]["hours_by_class"][class_id] += 1
        
        return result
    
    def get_class_timetable(self, class_id: str) -> Dict[str, Any]:
        """
        Get timetable for a specific class.
        
        Args:
            class_id: Class identifier
            
        Returns:
            Class timetable with additional information
        """
        if class_id not in self.classes:
            return {"error": f"Class ID '{class_id}' not found"}
        
        if class_id not in self.class_timetables:
            return {"error": "Timetable not generated yet"}
        
        result = {
            "class": self.classes[class_id],
            "timetable": self.class_timetables[class_id],
            "statistics": {
                "total_hours": 0,
                "hours_by_subject": {},
                "hours_by_teacher": {},
                "hours_by_day": {day: 0 for day in self.days}
            }
        }
        
        # Calculate statistics
        for day, periods in self.class_timetables[class_id].items():
            for period, allocation in periods.items():
                result["statistics"]["total_hours"] += 1
                result["statistics"]["hours_by_day"][day] += 1
                
                subject_id = allocation.get("subject_id")
                if subject_id:
                    if subject_id not in result["statistics"]["hours_by_subject"]:
                        result["statistics"]["hours_by_subject"][subject_id] = 0
                    result["statistics"]["hours_by_subject"][subject_id] += 1
                
                teacher_id = allocation.get("teacher_id")
                if teacher_id:
                    if teacher_id not in result["statistics"]["hours_by_teacher"]:
                        result["statistics"]["hours_by_teacher"][teacher_id] = 0
                    result["statistics"]["hours_by_teacher"][teacher_id] += 1
        
        return result
    
    def export_timetable(self, output_format: str = "json", output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Export timetable in specified format.
        
        Args:
            output_format: Format to export (json, csv, html, pdf)
            output_file: Output file path (optional)
            
        Returns:
            Dictionary with export results
        """
        if not self.master_timetable:
            return {"error": "Timetable not generated yet"}
        
        if output_format == "json":
            return self._export_json(output_file)
        elif output_format == "csv":
            return self._export_csv(output_file)
        elif output_format == "html":
            return self._export_html(output_file)
        elif output_format == "pdf":
            return self._export_pdf(output_file)
        else:
            return {"error": f"Unsupported output format: {output_format}"}
    
    def _export_json(self, output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Export timetable as JSON.
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Dictionary with export results
        """
        data = {
            "master_timetable": self.master_timetable,
            "teacher_timetables": self.teacher_timetables,
            "class_timetables": self.class_timetables,
            "room_timetables": self.room_timetables,
            "metadata": {
                "generated_at": datetime.datetime.now().isoformat(),
                "days": self.days,
                "periods": self.periods
            }
        }
        
        if output_file:
            try:
                with open(output_file, 'w') as f:
                    json.dump(data, f, indent=2)
                return {"success": True, "file": output_file}
            except Exception as e:
                return {"error": f"Failed to write JSON file: {str(e)}"}
        else:
            return {"success": True, "data": data}
    
    def _export_csv(self, output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Export timetable as CSV.
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Dictionary with export results
        """
        # Implementation would create CSV files for different timetable views
        return {"error": "CSV export not implemented yet"}
    
    def _export_html(self, output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Export timetable as HTML.
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Dictionary with export results
        """
        # Implementation would create HTML tables for different timetable views
        return {"error": "HTML export not implemented yet"}
    
    def _export_pdf(self, output_file: Optional[str] = None) -> Dict[str, Any]:
        """
        Export timetable as PDF.
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Dictionary with export results
        """
        # Implementation would create PDF documents for different timetable views
        return {"error": "PDF export not implemented yet"}
    
    def print_timetable(self, timetable_type: str, identifier: Optional[str] = None) -> str:
        """
        Generate a printable text representation of a timetable.
        
        Args:
            timetable_type: Type of timetable (master, teacher, class, room)
            identifier: Specific ID for teacher, class, or room (optional)
            
        Returns:
            Formatted timetable string
        """
        if not self.master_timetable:
            return "Timetable not generated yet"
        
        if timetable_type == "master":
            return self._print_master_timetable()
        elif timetable_type == "teacher" and identifier:
            return self._print_teacher_timetable(identifier)
        elif timetable_type == "class" and identifier:
            return self._print_class_timetable(identifier)
        elif timetable_type == "room" and identifier:
            return self._print_room_timetable(identifier)
        else:
            return f"Invalid timetable type or missing identifier: {timetable_type}, {identifier}"
    
    def _print_master_timetable(self) -> str:
        """
        Generate a printable text representation of the master timetable.
        
        Returns:
            Formatted master timetable string
        """
        # This would be a complex implementation to format the master timetable
        # as a readable text table
        return "Master timetable printing not implemented yet"
    
    def _print_teacher_timetable(self, teacher_id: str) -> str:
        """
        Generate a printable text representation of a teacher's timetable.
        
        Args:
            teacher_id: Teacher identifier
            
        Returns:
            Formatted teacher timetable string
        """
        if teacher_id not in self.teachers:
            return f"Teacher ID '{teacher_id}' not found"
        
        if teacher_id not in self.teacher_timetables:
            return "Timetable not generated yet"
        
        teacher_name = self.teachers[teacher_id]["name"]
        timetable = self.teacher_timetables[teacher_id]
        
        output = [f"Timetable for {teacher_name} ({teacher_id})"]
        output.append("=" * 80)
        
        # Header row with periods
        header = "Day       "
        for period in self.periods:
            header += f"| {period['name']:<10} "
        output.append(header)
        output.append("-" * len(header))
        
        # Timetable rows
        for day in self.days:
            row = f"{day:<10}"
            for period in self.periods:
                period_id = period["id"]
                if period_id in timetable.get(day, {}):
                    allocation = timetable[day][period_id]
                    class_id = allocation.get("class_id", "")
                    subject_id = allocation.get("subject_id", "")
                    class_name = self.classes.get(class_id, {}).get("name", class_id)
                    subject_name = self.subjects.get(subject_id, {}).get("name", subject_id)
                    cell = f"{class_name}/{subject_name}"
                    row += f"| {cell:<10} "
                else:
                    row += f"| {'':<10} "
            output.append(row)
        
        return "\n".join(output)
    
    def _print_class_timetable(self, class_id: str) -> str:
        """
        Generate a printable text representation of a class's timetable.
        
        Args:
            class_id: Class identifier
            
        Returns:
            Formatted class timetable string
        """
        if class_id not in self.classes:
            return f"Class ID '{class_id}' not found"
        
        if class_id not in self.class_timetables:
            return "Timetable not generated yet"
        
        class_name = self.classes[class_id]["name"]
        timetable = self.class_timetables[class_id]
        
        output = [f"Timetable for Class {class_name} ({class_id})"]
        output.append("=" * 80)
        
        # Header row with periods
        header = "Day       "
        for period in self.periods:
            header += f"| {period['name']:<10} "
        output.append(header)
        output.append("-" * len(header))
        
        # Timetable rows
        for day in self.days:
            row = f"{day:<10}"
            for period in self.periods:
                period_id = period["id"]
                if period_id in timetable.get(day, {}):
                    allocation = timetable[day][period_id]
                    subject_id = allocation.get("subject_id", "")
                    teacher_id = allocation.get("teacher_id", "")
                    subject_name = self.subjects.get(subject_id, {}).get("name", subject_id)
                    teacher_name = self.teachers.get(teacher_id, {}).get("name", teacher_id)
                    cell = f"{subject_name}"
                    row += f"| {cell:<10} "
                else:
                    row += f"| {'':<10} "
            output.append(row)
        
        return "\n".join(output)
    
    def _print_room_timetable(self, room_id: str) -> str:
        """
        Generate a printable text representation of a room's timetable.
        
        Args:
            room_id: Room identifier
            
        Returns:
            Formatted room timetable string
        """
        if room_id not in self.rooms:
            return f"Room ID '{room_id}' not found"
        
        if room_id not in self.room_timetables:
            return "Timetable not generated yet"
        
        room_name = self.rooms[room_id]["name"]
        timetable = self.room_timetables[room_id]
        
        output = [f"Timetable for Room {room_name} ({room_id})"]
        output.append("=" * 80)
        
        # Header row with periods
        header = "Day       "
        for period in self.periods:
            header += f"| {period['name']:<10} "
        output.append(header)
        output.append("-" * len(header))
        
        # Timetable rows
        for day in self.days:
            row = f"{day:<10}"
            for period in self.periods:
                period_id = period["id"]
                if period_id in timetable.get(day, {}):
                    allocation = timetable[day][period_id]
                    class_id = allocation.get("class_id", "")
                    subject_id = allocation.get("subject_id", "")
                    class_name = self.classes.get(class_id, {}).get("name", class_id)
                    subject_name = self.subjects.get(subject_id, {}).get("name", subject_id)
                    cell = f"{class_name}/{subject_name}"
                    row += f"| {cell:<10} "
                else:
                    row += f"| {'':<10} "
            output.append(row)
        
        return "\n".join(output)
    
    def create_sample_data(self) -> Dict[str, int]:
        """
        Create sample data for demonstration purposes.
        
        Returns:
            Dictionary with counts of created items
        """
        # Create sample subjects
        subjects = [
            {"subject_id": "MATH", "name": "Mathematics", "requires_specialized_room": False},
            {"subject_id": "ENG", "name": "English", "requires_specialized_room": False},
            {"subject_id": "SCI", "name": "Science", "requires_specialized_room": True, "preferred_room_type": "science"},
            {"subject_id": "HIST", "name": "History", "requires_specialized_room": False},
            {"subject_id": "GEO", "name": "Geography", "requires_specialized_room": False},
            {"subject_id": "PE", "name": "Physical Education", "requires_specialized_room": True, "preferred_room_type": "gym"},
            {"subject_id": "ART", "name": "Art", "requires_specialized_room": True, "preferred_room_type": "art"},
            {"subject_id": "MUS", "name": "Music", "requires_specialized_room": True, "preferred_room_type": "music"},
            {"subject_id": "CS", "name": "Computer Science", "requires_specialized_room": True, "preferred_room_type": "computer"}
        ]
        
        for subject in subjects:
            self.add_subject(
                subject_id=subject["subject_id"],
                name=subject["name"],
                requires_specialized_room=subject["requires_specialized_room"],
                preferred_room_type=subject.get("preferred_room_type", ""),
                consecutive_periods_preferred=subject["subject_id"] in ["PE", "ART", "MUS"]
            )
        
        # Create sample teachers
        teachers = [
            {"teacher_id": "T1", "name": "Mr. Smith", "subjects": ["MATH", "CS"]},
            {"teacher_id": "T2", "name": "Ms. Johnson", "subjects": ["ENG", "HIST"]},
            {"teacher_id": "T3", "name": "Dr. Brown", "subjects": ["SCI", "MATH"]},
            {"teacher_id": "T4", "name": "Mrs. Davis", "subjects": ["HIST", "GEO"]},
            {"teacher_id": "T5", "name": "Mr. Wilson", "subjects": ["PE"]},
            {"teacher_id": "T6", "name": "Ms. Taylor", "subjects": ["ART", "MUS"]},
            {"teacher_id": "T7", "name": "Mr. Anderson", "subjects": ["CS", "MATH"]},
            {"teacher_id": "T8", "name": "Dr. Thomas", "subjects": ["SCI", "GEO"]}
        ]
        
        for teacher in teachers:
            self.add_teacher(
                teacher_id=teacher["teacher_id"],
                name=teacher["name"],
                subjects=teacher["subjects"],
                max_hours=25
            )
        
        # Create sample rooms
        rooms = [
            {"room_id": "R1", "name": "Room 101", "capacity": 30, "room_type": "general"},
            {"room_id": "R2", "name": "Room 102", "capacity": 30, "room_type": "general"},
            {"room_id": "R3", "name": "Room 103", "capacity": 30, "room_type": "general"},
            {"room_id": "R4", "name": "Science Lab", "capacity": 25, "room_type": "science"},
            {"room_id": "R5", "name": "Computer Lab", "capacity": 25, "room_type": "computer"},
            {"room_id": "R6", "name": "Gymnasium", "capacity": 50, "room_type": "gym"},
            {"room_id": "R7", "name": "Art Studio", "capacity": 25, "room_type": "art"},
            {"room_id": "R8", "name": "Music Room", "capacity": 25, "room_type": "music"}
        ]
        
        for room in rooms:
            self.add_room(
                room_id=room["room_id"],
                name=room["name"],
                capacity=room["capacity"],
                room_type=room["room_type"]
            )
        
        # Create sample classes
        classes = [
            {"class_id": "C1", "name": "Class 9A", "homeroom_teacher": "T1", "grade_level": 9},
            {"class_id": "C2", "name": "Class 9B", "homeroom_teacher": "T2", "grade_level": 9},
            {"class_id": "C3", "name": "Class 10A", "homeroom_teacher": "T3", "grade_level": 10},
            {"class_id": "C4", "name": "Class 10B", "homeroom_teacher": "T4", "grade_level": 10}
        ]
        
        for class_data in classes:
            self.add_class(
                class_id=class_data["class_id"],
                name=class_data["name"],
                homeroom_teacher=class_data["homeroom_teacher"],
                grade_level=class_data["grade_level"]
            )
        
        # Add subjects to classes
        class_subjects = [
            # Class 9A
            {"class_id": "C1", "subject_id": "MATH", "hours_per_week": 5, "teacher_id": "T1"},
            {"class_id": "C1", "subject_id": "ENG", "hours_per_week": 5, "teacher_id": "T2"},
            {"class_id": "C1", "subject_id": "SCI", "hours_per_week": 4, "teacher_id": "T3"},
            {"class_id": "C1", "subject_id": "HIST", "hours_per_week": 3, "teacher_id": "T2"},
            {"class_id": "C1", "subject_id": "GEO", "hours_per_week": 2, "teacher_id": "T4"},
            {"class_id": "C1", "subject_id": "PE", "hours_per_week": 2, "teacher_id": "T5"},
            {"class_id": "C1", "subject_id": "ART", "hours_per_week": 2, "teacher_id": "T6"},
            {"class_id": "C1", "subject_id": "CS", "hours_per_week": 2, "teacher_id": "T7"},
            
            # Class 9B
            {"class_id": "C2", "subject_id": "MATH", "hours_per_week": 5, "teacher_id": "T7"},
            {"class_id": "C2", "subject_id": "ENG", "hours_per_week": 5, "teacher_id": "T2"},
            {"class_id": "C2", "subject_id": "SCI", "hours_per_week": 4, "teacher_id": "T8"},
            {"class_id": "C2", "subject_id": "HIST", "hours_per_week": 3, "teacher_id": "T4"},
            {"class_id": "C2", "subject_id": "GEO", "hours_per_week": 2, "teacher_id": "T4"},
            {"class_id": "C2", "subject_id": "PE", "hours_per_week": 2, "teacher_id": "T5"},
            {"class_id": "C2", "subject_id": "MUS", "hours_per_week": 2, "teacher_id": "T6"},
            {"class_id": "C2", "subject_id": "CS", "hours_per_week": 2, "teacher_id": "T1"},
            
            # Class 10A
            {"class_id": "C3", "subject_id": "MATH", "hours_per_week": 5, "teacher_id": "T1"},
            {"class_id": "C3", "subject_id": "ENG", "hours_per_week": 5, "teacher_id": "T2"},
            {"class_id": "C3", "subject_id": "SCI", "hours_per_week": 4, "teacher_id": "T3"},
            {"class_id": "C3", "subject_id": "HIST", "hours_per_week": 3, "teacher_id": "T4"},
            {"class_id": "C3", "subject_id": "GEO", "hours_per_week": 2, "teacher_id": "T8"},
            {"class_id": "C3", "subject_id": "PE", "hours_per_week": 2, "teacher_id": "T5"},
            {"class_id": "C3", "subject_id": "ART", "hours_per_week": 2, "teacher_id": "T6"},
            {"class_id": "C3", "subject_id": "CS", "hours_per_week": 2, "teacher_id": "T7"},
            
            # Class 10B
            {"class_id": "C4", "subject_id": "MATH", "hours_per_week": 5, "teacher_id": "T7"},
            {"class_id": "C4", "subject_id": "ENG", "hours_per_week": 5, "teacher_id": "T2"},
            {"class_id": "C4", "subject_id": "SCI", "hours_per_week": 4, "teacher_id": "T8"},
            {"class_id": "C4", "subject_id": "HIST", "hours_per_week": 3, "teacher_id": "T4"},
            {"class_id": "C4", "subject_id": "GEO", "hours_per_week": 2, "teacher_id": "T4"},
            {"class_id": "C4", "subject_id": "PE", "hours_per_week": 2, "teacher_id": "T5"},
            {"class_id": "C4", "subject_id": "MUS", "hours_per_week": 2, "teacher_id": "T6"},
            {"class_id": "C4", "subject_id": "CS", "hours_per_week": 2, "teacher_id": "T1"}
        ]
        
        for subject in class_subjects:
            self.add_class_subject(
                class_id=subject["class_id"],
                subject_id=subject["subject_id"],
                hours_per_week=subject["hours_per_week"],
                teacher_id=subject["teacher_id"]
            )
        
        # Set some teacher preferences
        self.set_teacher_preferences("T1", {
            "preferred_days": ["Monday", "Tuesday", "Wednesday"],
            "max_consecutive_periods": 3
        })
        
        self.set_teacher_preferences("T5", {
            "preferred_days": ["Monday", "Wednesday", "Friday"],
            "max_hours_per_day": 4
        })
        
        # Set some subject constraints
        self.set_subject_constraints("PE", {
            "preferred_periods": [6, 7, 8, 9],  # Afternoon periods
            "avoid_consecutive_days": True
        })
        
        self.set_subject_constraints("MATH", {
            "preferred_periods": [1, 2, 3, 5],  # Morning periods
            "max_periods_per_day": 2
        })
        
        return {
            "teachers": len(self.teachers),
            "classes": len(self.classes),
            "subjects": len(self.subjects),
            "rooms": len(self.rooms)
        }
