import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

// Components
import TimetableView from '../components/timetables/TimetableView';
import ClassTimetable from '../components/timetables/ClassTimetable';
import TeacherTimetable from '../components/timetables/TeacherTimetable';
import RoomTimetable from '../components/timetables/RoomTimetable';
import LoadingSpinner from '../components/common/LoadingSpinner';
import Alert from '../components/common/Alert';

const TimetableView = ({ timetables, selectedTimetable, onTimetableSelect, onTimetableDelete }) => {
  const [viewType, setViewType] = useState('class');
  const [selectedClass, setSelectedClass] = useState(null);
  const [selectedTeacher, setSelectedTeacher] = useState(null);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [classes, setClasses] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [rooms, setRooms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (selectedTimetable) {
      fetchSchoolData();
    }
  }, [selectedTimetable]);

  const fetchSchoolData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = {
        'Authorization': `Bearer ${token}`
      };

      // Fetch classes, teachers, and rooms
      const [classesRes, teachersRes, roomsRes] = await Promise.all([
        axios.get('/api/school-data/classes', { headers }),
        axios.get('/api/school-data/teachers', { headers }),
        axios.get('/api/school-data/rooms', { headers })
      ]);

      setClasses(Object.entries(classesRes.data.data).map(([id, data]) => ({ id, ...data })));
      setTeachers(Object.entries(teachersRes.data.data).map(([id, data]) => ({ id, ...data })));
      setRooms(Object.entries(roomsRes.data.data).map(([id, data]) => ({ id, ...data })));

      // Set default selections
      if (classes.length > 0 && !selectedClass) {
        setSelectedClass(Object.keys(classesRes.data.data)[0]);
      }
      if (teachers.length > 0 && !selectedTeacher) {
        setSelectedTeacher(Object.keys(teachersRes.data.data)[0]);
      }
      if (rooms.length > 0 && !selectedRoom) {
        setSelectedRoom(Object.keys(roomsRes.data.data)[0]);
      }

      setError(null);
    } catch (err) {
      console.error('Error fetching school data:', err);
      setError('Failed to load school data. Please try again later.');
    } finally {
      setLoading(false);
    }
  };

  if (!selectedTimetable) {
    return (
      <div className="col-12">
        <div className="card">
          <div className="card-body text-center">
            <p>No timetable selected. Please select a timetable from the list or create a new one.</p>
            {timetables.length === 0 && (
              <p>No timetables available. Go to the "Generate Timetable" tab to create one.</p>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="col-12">
      <div className="card mb-4">
        <div className="card-header d-flex justify-content-between align-items-center">
          <h5 className="mb-0">Timetable: {selectedTimetable.name}</h5>
          <div>
            <button 
              className="btn btn-sm btn-danger ms-2"
              onClick={() => onTimetableDelete(selectedTimetable.id)}
            >
              Delete
            </button>
          </div>
        </div>
        <div className="card-body">
          <div className="row mb-3">
            <div className="col-md-6">
              <p><strong>School Year:</strong> {selectedTimetable.school_year}</p>
              <p><strong>Term:</strong> {selectedTimetable.term}</p>
            </div>
            <div className="col-md-6">
              <p><strong>Days per Week:</strong> {selectedTimetable.days_per_week}</p>
              <p><strong>Periods per Day:</strong> {selectedTimetable.periods_per_day}</p>
            </div>
          </div>

          <div className="mb-4">
            <div className="btn-group">
              <button 
                className={`btn ${viewType === 'class' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => setViewType('class')}
              >
                Class View
              </button>
              <button 
                className={`btn ${viewType === 'teacher' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => setViewType('teacher')}
              >
                Teacher View
              </button>
              <button 
                className={`btn ${viewType === 'room' ? 'btn-primary' : 'btn-outline-primary'}`}
                onClick={() => setViewType('room')}
              >
                Room View
              </button>
            </div>
          </div>

          {loading ? (
            <LoadingSpinner />
          ) : error ? (
            <Alert type="danger" message={error} />
          ) : (
            <>
              {viewType === 'class' && (
                <div>
                  <div className="mb-3">
                    <label htmlFor="classSelect" className="form-label">Select Class:</label>
                    <select 
                      id="classSelect" 
                      className="form-select"
                      value={selectedClass || ''}
                      onChange={(e) => setSelectedClass(e.target.value)}
                    >
                      {classes.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  {selectedClass && (
                    <ClassTimetable 
                      timetableId={selectedTimetable.id}
                      classId={selectedClass}
                    />
                  )}
                </div>
              )}

              {viewType === 'teacher' && (
                <div>
                  <div className="mb-3">
                    <label htmlFor="teacherSelect" className="form-label">Select Teacher:</label>
                    <select 
                      id="teacherSelect" 
                      className="form-select"
                      value={selectedTeacher || ''}
                      onChange={(e) => setSelectedTeacher(e.target.value)}
                    >
                      {teachers.map(t => (
                        <option key={t.id} value={t.id}>{t.name}</option>
                      ))}
                    </select>
                  </div>
                  {selectedTeacher && (
                    <TeacherTimetable 
                      timetableId={selectedTimetable.id}
                      teacherId={selectedTeacher}
                    />
                  )}
                </div>
              )}

              {viewType === 'room' && (
                <div>
                  <div className="mb-3">
                    <label htmlFor="roomSelect" className="form-label">Select Room:</label>
                    <select 
                      id="roomSelect" 
                      className="form-select"
                      value={selectedRoom || ''}
                      onChange={(e) => setSelectedRoom(e.target.value)}
                    >
                      {rooms.map(r => (
                        <option key={r.id} value={r.id}>{r.name}</option>
                      ))}
                    </select>
                  </div>
                  {selectedRoom && (
                    <RoomTimetable 
                      timetableId={selectedTimetable.id}
                      roomId={selectedRoom}
                    />
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h5 className="mb-0">Available Timetables</h5>
        </div>
        <div className="card-body">
          <div className="list-group">
            {timetables.map(timetable => (
              <button
                key={timetable.id}
                className={`list-group-item list-group-item-action ${selectedTimetable && selectedTimetable.id === timetable.id ? 'active' : ''}`}
                onClick={() => onTimetableSelect(timetable.id)}
              >
                <div className="d-flex w-100 justify-content-between">
                  <h5 className="mb-1">{timetable.name}</h5>
                  <small>{timetable.school_year} - {timetable.term}</small>
                </div>
                <p className="mb-1">Days: {timetable.days_per_week}, Periods: {timetable.periods_per_day}</p>
                <small>Created: {new Date(timetable.created_at).toLocaleDateString()}</small>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TimetableView;
