"""
SMART TEACHER AI - API Integration Module

This module updates the main Flask application to include all API endpoints.
"""

from flask import Flask, jsonify, render_template, send_from_directory
from flask_jwt_extended import JWTManager
from flask_cors import CORS
import os
from datetime import timedelta

# Import API blueprints
from api.auth import auth_bp
from api.lesson_plans import lesson_plans_bp
from api.assessments import assessments_bp
from api.timetables import timetables_bp

# Create Flask app
app = Flask(__name__, 
            static_folder='static',
            template_folder='templates')

# Configure app
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'dev-jwt-secret-key')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
app.config['JWT_REFRESH_TOKEN_EXPIRES'] = timedelta(days=30)

# Initialize extensions
jwt = JWTManager(app)
CORS(app)

# Register blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(lesson_plans_bp)
app.register_blueprint(assessments_bp)
app.register_blueprint(timetables_bp)

# Routes
@app.route('/')
def index():
    """Serve the index page."""
    return render_template('index.html')

@app.route('/<path:path>')
def serve_react(path):
    """Serve React app routes."""
    return render_template('index.html')

@app.route('/api/health')
def health_check():
    """Health check endpoint."""
    return jsonify({
        'status': 'healthy',
        'version': '1.0.0'
    })

# Error handlers
@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors."""
    return jsonify({
        'success': False,
        'message': 'Resource not found'
    }), 404

@app.errorhandler(500)
def server_error(e):
    """Handle 500 errors."""
    return jsonify({
        'success': False,
        'message': 'Internal server error'
    }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
