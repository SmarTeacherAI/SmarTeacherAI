"""
Rubric Management System for SMART TEACHER AI

This module provides a comprehensive rubric management system for essay and
non-structured answer assessment, allowing teachers to create, customize,
and apply assessment rubrics.
"""

import os
import json
import datetime
import uuid
from typing import Dict, List, Any, Optional, Union

class RubricManager:
    """
    Manages assessment rubrics for essay and non-structured answer marking.
    Provides functionality to create, customize, store, retrieve, and apply rubrics.
    """
    
    def __init__(self, rubrics_dir: str = "../data/rubrics"):
        """
        Initialize the Rubric Manager.
        
        Args:
            rubrics_dir: Directory for storing rubric files
        """
        self.rubrics_dir = rubrics_dir
        self._ensure_directory_exists()
        self.default_rubrics = self._load_default_rubrics()
        
    def _ensure_directory_exists(self):
        """Ensure the rubrics directory exists."""
        os.makedirs(self.rubrics_dir, exist_ok=True)
    
    def _load_default_rubrics(self) -> Dict[str, Any]:
        """Load default rubric templates."""
        return {
            "english_essay": {
                "id": "default_english_essay",
                "name": "English Essay Evaluation",
                "description": "Standard rubric for evaluating English essays",
                "subject": "English",
                "level": "Secondary",
                "total_marks": 100,
                "criteria": [
                    {
                        "name": "Content and Understanding",
                        "description": "Depth of understanding of the topic and quality of content",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Exceptional depth of understanding with insightful content"},
                            {"score": 4, "description": "Strong understanding with relevant and detailed content"},
                            {"score": 3, "description": "Adequate understanding with mostly relevant content"},
                            {"score": 2, "description": "Limited understanding with some irrelevant content"},
                            {"score": 1, "description": "Poor understanding with mostly irrelevant content"}
                        ]
                    },
                    {
                        "name": "Organization and Structure",
                        "description": "Logical flow and organization of ideas",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Exceptionally well-organized with seamless transitions"},
                            {"score": 4, "description": "Well-organized with clear transitions"},
                            {"score": 3, "description": "Adequately organized with some transitions"},
                            {"score": 2, "description": "Somewhat disorganized with abrupt transitions"},
                            {"score": 1, "description": "Poorly organized with little logical flow"}
                        ]
                    },
                    {
                        "name": "Language and Style",
                        "description": "Grammar, vocabulary, and writing style",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Sophisticated language with flawless grammar"},
                            {"score": 4, "description": "Strong language with minor grammatical errors"},
                            {"score": 3, "description": "Adequate language with some grammatical errors"},
                            {"score": 2, "description": "Limited language with frequent grammatical errors"},
                            {"score": 1, "description": "Poor language with pervasive grammatical errors"}
                        ]
                    },
                    {
                        "name": "Critical Thinking",
                        "description": "Analysis, evaluation, and original insights",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Exceptional analysis with original insights"},
                            {"score": 4, "description": "Strong analysis with some original thinking"},
                            {"score": 3, "description": "Adequate analysis with conventional thinking"},
                            {"score": 2, "description": "Limited analysis with minimal original thought"},
                            {"score": 1, "description": "Poor analysis with no original thinking"}
                        ]
                    },
                    {
                        "name": "Evidence and Support",
                        "description": "Use of examples, quotations, and supporting details",
                        "weight": 0.1,
                        "levels": [
                            {"score": 5, "description": "Comprehensive evidence with excellent integration"},
                            {"score": 4, "description": "Strong evidence with good integration"},
                            {"score": 3, "description": "Adequate evidence with some integration"},
                            {"score": 2, "description": "Limited evidence with poor integration"},
                            {"score": 1, "description": "Minimal or no evidence"}
                        ]
                    }
                ],
                "created_at": datetime.datetime.now().isoformat(),
                "modified_at": datetime.datetime.now().isoformat(),
                "is_default": True
            },
            "science_explanation": {
                "id": "default_science_explanation",
                "name": "Science Explanation Evaluation",
                "description": "Standard rubric for evaluating scientific explanations",
                "subject": "Science",
                "level": "Secondary",
                "total_marks": 50,
                "criteria": [
                    {
                        "name": "Scientific Accuracy",
                        "description": "Accuracy of scientific concepts and principles",
                        "weight": 0.4,
                        "levels": [
                            {"score": 5, "description": "Completely accurate with precise terminology"},
                            {"score": 4, "description": "Mostly accurate with appropriate terminology"},
                            {"score": 3, "description": "Generally accurate with some terminology errors"},
                            {"score": 2, "description": "Several inaccuracies with terminology problems"},
                            {"score": 1, "description": "Mostly inaccurate with incorrect terminology"}
                        ]
                    },
                    {
                        "name": "Clarity of Explanation",
                        "description": "Clarity and comprehensibility of the explanation",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Exceptionally clear and easy to understand"},
                            {"score": 4, "description": "Clear and mostly easy to understand"},
                            {"score": 3, "description": "Adequately clear with some confusing parts"},
                            {"score": 2, "description": "Somewhat unclear and difficult to follow"},
                            {"score": 1, "description": "Very unclear and confusing"}
                        ]
                    },
                    {
                        "name": "Use of Examples",
                        "description": "Use of relevant examples to illustrate concepts",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Excellent examples that perfectly illustrate concepts"},
                            {"score": 4, "description": "Good examples that clearly illustrate concepts"},
                            {"score": 3, "description": "Adequate examples that somewhat illustrate concepts"},
                            {"score": 2, "description": "Limited examples with weak connection to concepts"},
                            {"score": 1, "description": "No examples or irrelevant examples"}
                        ]
                    },
                    {
                        "name": "Completeness",
                        "description": "Completeness of the explanation covering all aspects",
                        "weight": 0.1,
                        "levels": [
                            {"score": 5, "description": "Comprehensive coverage of all aspects"},
                            {"score": 4, "description": "Thorough coverage of most aspects"},
                            {"score": 3, "description": "Adequate coverage of key aspects"},
                            {"score": 2, "description": "Partial coverage with significant omissions"},
                            {"score": 1, "description": "Minimal coverage with major omissions"}
                        ]
                    }
                ],
                "created_at": datetime.datetime.now().isoformat(),
                "modified_at": datetime.datetime.now().isoformat(),
                "is_default": True
            },
            "mathematics_problem": {
                "id": "default_mathematics_problem",
                "name": "Mathematics Problem Solution Evaluation",
                "description": "Standard rubric for evaluating mathematics problem solutions",
                "subject": "Mathematics",
                "level": "Secondary",
                "total_marks": 50,
                "criteria": [
                    {
                        "name": "Mathematical Accuracy",
                        "description": "Accuracy of calculations and mathematical operations",
                        "weight": 0.4,
                        "levels": [
                            {"score": 5, "description": "All calculations are accurate with correct final answer"},
                            {"score": 4, "description": "Minor calculation errors but correct approach"},
                            {"score": 3, "description": "Some calculation errors with mostly correct approach"},
                            {"score": 2, "description": "Significant calculation errors with partially correct approach"},
                            {"score": 1, "description": "Major calculation errors with incorrect approach"}
                        ]
                    },
                    {
                        "name": "Problem-Solving Strategy",
                        "description": "Appropriateness and efficiency of problem-solving approach",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Optimal strategy with elegant solution"},
                            {"score": 4, "description": "Effective strategy with clear solution path"},
                            {"score": 3, "description": "Workable strategy with reasonable solution path"},
                            {"score": 2, "description": "Inefficient strategy with convoluted solution path"},
                            {"score": 1, "description": "Inappropriate strategy or no clear approach"}
                        ]
                    },
                    {
                        "name": "Mathematical Communication",
                        "description": "Clarity of mathematical notation and explanation",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Excellent notation with clear step-by-step explanation"},
                            {"score": 4, "description": "Good notation with mostly clear explanation"},
                            {"score": 3, "description": "Adequate notation with some explanation"},
                            {"score": 2, "description": "Poor notation with minimal explanation"},
                            {"score": 1, "description": "Confusing notation with no explanation"}
                        ]
                    },
                    {
                        "name": "Completeness",
                        "description": "Completeness of the solution addressing all parts of the problem",
                        "weight": 0.1,
                        "levels": [
                            {"score": 5, "description": "Complete solution addressing all aspects of the problem"},
                            {"score": 4, "description": "Nearly complete solution with minor omissions"},
                            {"score": 3, "description": "Partial solution addressing main aspects of the problem"},
                            {"score": 2, "description": "Incomplete solution with significant omissions"},
                            {"score": 1, "description": "Minimal attempt with major omissions"}
                        ]
                    }
                ],
                "created_at": datetime.datetime.now().isoformat(),
                "modified_at": datetime.datetime.now().isoformat(),
                "is_default": True
            },
            "history_essay": {
                "id": "default_history_essay",
                "name": "History Essay Evaluation",
                "description": "Standard rubric for evaluating history essays",
                "subject": "History",
                "level": "Secondary",
                "total_marks": 100,
                "criteria": [
                    {
                        "name": "Historical Knowledge",
                        "description": "Accuracy and depth of historical knowledge",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Comprehensive and accurate historical knowledge"},
                            {"score": 4, "description": "Substantial and mostly accurate historical knowledge"},
                            {"score": 3, "description": "Adequate historical knowledge with some inaccuracies"},
                            {"score": 2, "description": "Limited historical knowledge with several inaccuracies"},
                            {"score": 1, "description": "Minimal historical knowledge with major inaccuracies"}
                        ]
                    },
                    {
                        "name": "Historical Analysis",
                        "description": "Analysis and interpretation of historical events and sources",
                        "weight": 0.3,
                        "levels": [
                            {"score": 5, "description": "Sophisticated analysis with insightful interpretation"},
                            {"score": 4, "description": "Strong analysis with thoughtful interpretation"},
                            {"score": 3, "description": "Adequate analysis with some interpretation"},
                            {"score": 2, "description": "Limited analysis with minimal interpretation"},
                            {"score": 1, "description": "No analysis or interpretation"}
                        ]
                    },
                    {
                        "name": "Use of Evidence",
                        "description": "Use of historical sources and evidence to support arguments",
                        "weight": 0.2,
                        "levels": [
                            {"score": 5, "description": "Extensive use of relevant evidence with excellent integration"},
                            {"score": 4, "description": "Go
(Content truncated due to size limit. Use line ranges to read in chunks)