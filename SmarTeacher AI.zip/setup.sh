#!/bin/bash

# SMART TEACHER AI - Setup Script
# This script sets up the development environment for the SMART TEACHER AI web application

echo "Setting up SMART TEACHER AI web application..."

# Create virtual environment
echo "Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Create necessary directories if they don't exist
echo "Creating necessary directories..."
mkdir -p static/js/components/common
mkdir -p static/js/components/auth
mkdir -p static/js/components/lesson-plans
mkdir -p static/js/components/assessments
mkdir -p static/js/components/essay-marking
mkdir -p static/js/components/performance
mkdir -p static/js/components/communication
mkdir -p static/js/components/report-cards
mkdir -p static/js/components/timetables
mkdir -p static/js/pages
mkdir -p static/js/context
mkdir -p static/js/utils
mkdir -p static/css
mkdir -p static/images
mkdir -p templates
mkdir -p api

# Set up environment variables
echo "Setting up environment variables..."
cat > .env << EOL
FLASK_APP=app.py
FLASK_ENV=development
SECRET_KEY=dev-secret-key
JWT_SECRET_KEY=dev-jwt-secret-key
EOL

echo "Setup complete! You can now run the application with:"
echo "source venv/bin/activate && flask run --host=0.0.0.0 --port=5000"
