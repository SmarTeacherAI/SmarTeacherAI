"""
Student Performance Analyzer Module for SMART TEACHER AI

This module helps teachers analyze student performance data, generate insights,
and visualize results through various metrics and charts.
"""

import os
import json
import datetime
import statistics
from typing import Dict, List, Any, Optional

class PerformanceAnalyzer:
    """
    Analyzes student performance data and generates insights and visualizations.
    Processes raw marks data to provide meaningful analytics for teachers.
    """
    
    def __init__(self, output_dir: str = "../output/performance_analysis"):
        """
        Initialize the Performance Analyzer.
        
        Args:
            output_dir: Directory for saving analysis outputs
        """
        self.output_dir = output_dir
        
    def analyze_class_performance(self, 
                                 class_data: Dict[str, Any],
                                 analysis_types: List[str] = None) -> Dict[str, Any]:
        """
        Analyze performance data for an entire class.
        
        Args:
            class_data: Dictionary containing class performance data
                {
                    "class_info": {"name": "Form 4A", "term": "Term 1", "year": "2025"},
                    "subjects": ["Mathematics", "English", "Biology", ...],
                    "students": [
                        {
                            "id": "001",
                            "name": "John Doe",
                            "marks": {"Mathematics": 85, "English": 78, "Biology": 92, ...}
                        },
                        ...
                    ]
                }
            analysis_types: List of analysis types to perform
                
        Returns:
            Dictionary containing analysis results
        """
        # Default analysis types if none specified
        if analysis_types is None:
            analysis_types = ["summary", "ranking", "distribution", "subject_comparison", "improvement"]
        
        # Initialize results dictionary
        results = {
            "metadata": {
                "class_name": class_data["class_info"]["name"],
                "term": class_data["class_info"]["term"],
                "year": class_data["class_info"]["year"],
                "date_analyzed": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "num_students": len(class_data["students"]),
                "num_subjects": len(class_data["subjects"])
            },
            "analyses": {}
        }
        
        # Perform requested analyses
        for analysis_type in analysis_types:
            if analysis_type == "summary":
                results["analyses"]["summary"] = self._generate_summary_statistics(class_data)
            elif analysis_type == "ranking":
                results["analyses"]["ranking"] = self._generate_rankings(class_data)
            elif analysis_type == "distribution":
                results["analyses"]["distribution"] = self._generate_grade_distribution(class_data)
            elif analysis_type == "subject_comparison":
                results["analyses"]["subject_comparison"] = self._compare_subjects(class_data)
            elif analysis_type == "improvement":
                # This would require historical data, which we don't have in this example
                # In a real implementation, this would compare with previous terms
                results["analyses"]["improvement"] = {"note": "Improvement analysis requires historical data"}
        
        return results
    
    def analyze_student_performance(self, 
                                   student_data: Dict[str, Any],
                                   class_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Analyze performance data for an individual student.
        
        Args:
            student_data: Dictionary containing student performance data
                {
                    "id": "001",
                    "name": "John Doe",
                    "class": "Form 4A",
                    "term": "Term 1",
                    "year": "2025",
                    "marks": {"Mathematics": 85, "English": 78, "Biology": 92, ...}
                }
            class_data: Optional dictionary containing class performance data for comparison
                
        Returns:
            Dictionary containing analysis results
        """
        # Initialize results dictionary
        results = {
            "metadata": {
                "student_id": student_data["id"],
                "student_name": student_data["name"],
                "class": student_data["class"],
                "term": student_data["term"],
                "year": student_data["year"],
                "date_analyzed": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "num_subjects": len(student_data["marks"])
            },
            "analyses": {}
        }
        
        # Calculate basic statistics
        marks = list(student_data["marks"].values())
        total_marks = sum(marks)
        average_mark = total_marks / len(marks) if marks else 0
        
        # Generate student summary
        results["analyses"]["summary"] = {
            "total_marks": total_marks,
            "average_mark": round(average_mark, 1),
            "highest_mark": max(marks) if marks else 0,
            "lowest_mark": min(marks) if marks else 0,
            "grade": self._calculate_grade(average_mark),
            "subjects_above_average": [subject for subject, mark in student_data["marks"].items() if mark > average_mark],
            "subjects_below_average": [subject for subject, mark in student_data["marks"].items() if mark < average_mark]
        }
        
        # Generate subject breakdown
        results["analyses"]["subject_breakdown"] = {
            subject: {
                "mark": mark,
                "grade": self._calculate_grade(mark),
                "comment": self._generate_subject_comment(subject, mark)
            } for subject, mark in student_data["marks"].items()
        }
        
        # Compare with class if class data is provided
        if class_data:
            results["analyses"]["class_comparison"] = self._compare_with_class(student_data, class_data)
        
        # Generate recommendations
        results["analyses"]["recommendations"] = self._generate_recommendations(student_data)
        
        return results
    
    def analyze_subject_performance(self, 
                                   subject_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze performance data for a specific subject across a class.
        
        Args:
            subject_data: Dictionary containing subject performance data
                {
                    "subject": "Mathematics",
                    "class_info": {"name": "Form 4A", "term": "Term 1", "year": "2025"},
                    "students": [
                        {"id": "001", "name": "John Doe", "mark": 85},
                        {"id": "002", "name": "Jane Smith", "mark": 92},
                        ...
                    ]
                }
                
        Returns:
            Dictionary containing analysis results
        """
        # Initialize results dictionary
        results = {
            "metadata": {
                "subject": subject_data["subject"],
                "class_name": subject_data["class_info"]["name"],
                "term": subject_data["class_info"]["term"],
                "year": subject_data["class_info"]["year"],
                "date_analyzed": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "num_students": len(subject_data["students"])
            },
            "analyses": {}
        }
        
        # Extract marks
        marks = [student["mark"] for student in subject_data["students"]]
        
        # Calculate basic statistics
        results["analyses"]["summary"] = {
            "average_mark": round(statistics.mean(marks) if marks else 0, 1),
            "median_mark": round(statistics.median(marks) if marks else 0, 1),
            "highest_mark": max(marks) if marks else 0,
            "lowest_mark": min(marks) if marks else 0,
            "standard_deviation": round(statistics.stdev(marks) if len(marks) > 1 else 0, 2),
            "pass_rate": round((sum(1 for mark in marks if mark >= 50) / len(marks) * 100) if marks else 0, 1)
        }
        
        # Generate grade distribution
        results["analyses"]["grade_distribution"] = self._calculate_grade_distribution(marks)
        
        # Generate student rankings
        ranked_students = sorted(subject_data["students"], key=lambda x: x["mark"], reverse=True)
        results["analyses"]["rankings"] = [
            {
                "rank": i + 1,
                "student_id": student["id"],
                "student_name": student["name"],
                "mark": student["mark"],
                "grade": self._calculate_grade(student["mark"])
            } for i, student in enumerate(ranked_students)
        ]
        
        # Generate insights
        results["analyses"]["insights"] = self._generate_subject_insights(subject_data["subject"], marks)
        
        return results
    
    def generate_visualizations(self, 
                               analysis_results: Dict[str, Any],
                               visualization_types: List[str] = None) -> Dict[str, str]:
        """
        Generate visualization data based on analysis results.
        
        Args:
            analysis_results: Dictionary containing analysis results
            visualization_types: List of visualization types to generate
                
        Returns:
            Dictionary mapping visualization types to data representations
            (In a real implementation, this would generate actual charts or visualization data)
        """
        # Default visualization types if none specified
        if visualization_types is None:
            visualization_types = ["bar_chart", "pie_chart", "line_chart", "heatmap"]
        
        # Initialize visualizations dictionary
        visualizations = {}
        
        # In a real implementation, this would generate actual visualization data
        # For now, we'll just return placeholders
        
        for viz_type in visualization_types:
            if viz_type == "bar_chart":
                visualizations["bar_chart"] = "Data for bar chart visualization"
            elif viz_type == "pie_chart":
                visualizations["pie_chart"] = "Data for pie chart visualization"
            elif viz_type == "line_chart":
                visualizations["line_chart"] = "Data for line chart visualization"
            elif viz_type == "heatmap":
                visualizations["heatmap"] = "Data for heatmap visualization"
        
        return visualizations
    
    def export_to_format(self, 
                        analysis_results: Dict[str, Any], 
                        format_type: str) -> str:
        """
        Export the analysis results to the specified format.
        
        Args:
            analysis_results: The analysis results dictionary
            format_type: The desired output format ('pdf', 'xlsx', 'google_sheets')
            
        Returns:
            Path to the exported file
        """
        # In a production environment, this would convert to actual file formats
        # For now, we'll just return a placeholder
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        if "student_name" in analysis_results["metadata"]:
            # It's a student analysis
            filename = f"student_analysis_{analysis_results['metadata']['student_name']}_{timestamp}.{format_type}"
        elif "subject" in analysis_results["metadata"]:
            # It's a subject analysis
            filename = f"subject_analysis_{analysis_results['metadata']['subject']}_{timestamp}.{format_type}"
        else:
            # It's a class analysis
            filename = f"class_analysis_{analysis_results['metadata']['class_name']}_{timestamp}.{format_type}"
        
        # In a real implementation, we would save the file here
        return f"{self.output_dir}/{filename}"
    
    # Helper methods for analysis
    
    def _generate_summary_statistics(self, class_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate summary statistics for the class."""
        # Extract all marks for all students and subjects
        all_marks = []
        for student in class_data["students"]:
            all_marks.extend(student["marks"].values())
        
        # Calculate statistics
        summary = {
            "class_average": round(statistics.mean(all_marks) if all_marks else 0, 1),
            "class_median": round(statistics.median(all_marks) if all_marks else 0, 1),
            "highest_overall_mark": max(all_marks) if all_marks else 0,
            "lowest_overall_mark": min(all_marks) if all_marks else 0,
            "standard_deviation": round(statistics.stdev(all_marks) if len(all_marks) > 1 else 0, 2),
            "pass_rate": round((sum(1 for mark in all_marks if mark >= 50) / len(all_marks) * 100) if all_marks else 0, 1)
        }
        
        # Calculate subject averages
        subject_averages = {}
        for subject in class_data["subjects"]:
            subject_marks = [student["marks"].get(subject, 0) for student in class_data["students"]]
            subject_averages[subject] = round(statistics.mean(subject_marks) if subject_marks else 0, 1)
        
        summary["subject_averages"] = subject_averages
        
        # Identify highest and lowest performing subjects
        if subject_averages:
            highest_subject = max(subject_averages.items(), key=lambda x: x[1])
            lowest_subject = min(subject_averages.items(), key=lambda x: x[1])
            
            summary["highest_performing_subject"] = {
                "subject": highest_subject[0],
                "average": highest_subject[1]
            }
            
            summary["lowest_performing_subject"] = {
                "subject": lowest_subject[0],
                "average": lowest_subject[1]
            }
        
        return summary
    
    def _generate_rankings(self, class_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate student rankings based on average marks."""
        # Calculate average mark for each student
        student_averages = []
        for student in class_data["students"]:
            marks = list(student["marks"].values())
            average = statistics.mean(marks) if marks else 0
            student_averages.append({
                "id": student["id"],
                "name": student["name"],
                "average": round(average, 1),
                "total": sum(marks),
                "grade": self._calculate_grade(average)
            })
        
        # Sort by average mark (descending)
        ranked_students = sorted(student_averages, key=lambda x: x["average"], reverse=True)
        
        # Add rank
        for i, student in enumerate(ranked_students):
            student["rank"] = i + 1
        
        # Generate subject-specific rankings
        subject_rankings = {}
        for subject in class_data["subjects"]:
            subject_marks = []
            for student in class_data["students"]:
                if subject in student["marks"]:
                    subject_marks.append({
                        "id": student["id"],
                        "name": student["name"],
                        "mark": student["marks"][subject]
                    })
            
            # Sort by mark (descending)
            ranked_subject = sorted(subject_marks, key=lambda x: x["mark"], reverse=True)
            
            # Add rank
            for i, student in enumerate(ranked_subject):
               
(Content truncated due to size limit. Use line ranges to read in chunks)