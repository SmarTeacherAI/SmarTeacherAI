"""
Report Card Generator Module for SMART TEACHER AI

This module helps teachers generate comprehensive report cards for students,
automating the process of compiling grades, comments, and other assessment data.
"""

import os
import json
import datetime
from typing import Dict, List, Any, Optional

class ReportCardGenerator:
    """
    Generates customized report cards based on student performance data.
    Integrates with AI models to create personalized and informative report cards.
    """
    
    def __init__(self, templates_dir: str = "../templates/report_cards"):
        """
        Initialize the Report Card Generator.
        
        Args:
            templates_dir: Directory containing report card templates
        """
        self.templates_dir = templates_dir
        self.templates = self._load_templates()
        
    def _load_templates(self) -> Dict:
        """Load report card templates from JSON file."""
        # In a production environment, this would load from a database or API
        # For now, we'll use a placeholder
        return {
            "primary": {
                "standard": "Standard primary school report card template",
                "detailed": "Detailed primary school report card with expanded comments",
                "cbc": "Competency-Based Curriculum report card for primary schools"
            },
            "secondary": {
                "standard": "Standard secondary school report card template",
                "detailed": "Detailed secondary school report card with expanded comments",
                "8-4-4": "8-4-4 system report card for secondary schools"
            }
        }
    
    def get_available_templates(self, school_level: str) -> Dict[str, str]:
        """
        Get available templates for a specific school level.
        
        Args:
            school_level: School level ('primary' or 'secondary')
            
        Returns:
            Dictionary of template names and descriptions
        """
        return self.templates.get(school_level, {})
    
    def generate_student_report_card(self, 
                                    student_info: Dict[str, Any],
                                    term_data: Dict[str, Any],
                                    school_info: Dict[str, Any],
                                    template_type: str = "standard") -> Dict[str, Any]:
        """
        Generate a report card for an individual student.
        
        Args:
            student_info: Dictionary containing student information
            term_data: Dictionary containing term performance data
            school_info: Dictionary containing school information
            template_type: Type of report card template to use
            
        Returns:
            Dictionary containing the generated report card
        """
        # Determine school level from class/form
        school_level = "primary" if "grade" in student_info.get("class", "").lower() else "secondary"
        
        # Validate template type
        if template_type not in self.templates.get(school_level, {}):
            template_type = "standard"  # Default to standard if invalid
        
        # Calculate overall statistics
        overall_stats = self._calculate_overall_statistics(term_data["subjects"])
        
        # Create the report card structure
        report_card = {
            "metadata": {
                "student_name": student_info.get("name", ""),
                "student_id": student_info.get("id", ""),
                "class": student_info.get("class", ""),
                "term": term_data.get("term", ""),
                "academic_year": term_data.get("academic_year", ""),
                "template_type": template_type,
                "date_generated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "school_info": {
                "name": school_info.get("name", ""),
                "address": school_info.get("address", ""),
                "logo": school_info.get("logo", ""),
                "motto": school_info.get("motto", "")
            },
            "student_details": {
                "name": student_info.get("name", ""),
                "id": student_info.get("id", ""),
                "class": student_info.get("class", ""),
                "admission_number": student_info.get("admission_number", ""),
                "gender": student_info.get("gender", ""),
                "date_of_birth": student_info.get("date_of_birth", "")
            },
            "term_info": {
                "term": term_data.get("term", ""),
                "academic_year": term_data.get("academic_year", ""),
                "start_date": term_data.get("start_date", ""),
                "end_date": term_data.get("end_date", ""),
                "next_term_begins": term_data.get("next_term_begins", "")
            },
            "academic_performance": {
                "subjects": term_data["subjects"],
                "overall_statistics": overall_stats
            },
            "attendance": term_data.get("attendance", {
                "days_present": 0,
                "days_absent": 0,
                "total_days": 0,
                "attendance_percentage": 0
            }),
            "behavior_and_conduct": term_data.get("behavior", {
                "rating": "",
                "comments": ""
            }),
            "co_curricular_activities": term_data.get("co_curricular", []),
            "class_teacher_comment": self._generate_class_teacher_comment(student_info, overall_stats),
            "principal_comment": self._generate_principal_comment(student_info, overall_stats),
            "grading_system": self._get_grading_system(school_level)
        }
        
        return report_card
    
    def generate_class_report_cards(self, 
                                   class_data: Dict[str, Any],
                                   school_info: Dict[str, Any],
                                   template_type: str = "standard") -> List[Dict[str, Any]]:
        """
        Generate report cards for an entire class.
        
        Args:
            class_data: Dictionary containing class performance data
            school_info: Dictionary containing school information
            template_type: Type of report card template to use
            
        Returns:
            List of dictionaries containing generated report cards for each student
        """
        report_cards = []
        
        for student in class_data["students"]:
            # Extract student information
            student_info = {
                "name": student["name"],
                "id": student["id"],
                "class": class_data["class_info"]["name"],
                "admission_number": student.get("admission_number", ""),
                "gender": student.get("gender", ""),
                "date_of_birth": student.get("date_of_birth", "")
            }
            
            # Extract term data for this student
            term_data = {
                "term": class_data["class_info"]["term"],
                "academic_year": class_data["class_info"]["year"],
                "subjects": []
            }
            
            # Convert marks to subject data structure
            for subject, mark in student["marks"].items():
                subject_data = {
                    "name": subject,
                    "mark": mark,
                    "grade": self._calculate_grade(mark),
                    "comment": self._generate_subject_comment(subject, mark)
                }
                term_data["subjects"].append(subject_data)
            
            # Add attendance if available
            if "attendance" in student:
                term_data["attendance"] = student["attendance"]
            
            # Add behavior if available
            if "behavior" in student:
                term_data["behavior"] = student["behavior"]
            
            # Add co-curricular activities if available
            if "co_curricular" in student:
                term_data["co_curricular"] = student["co_curricular"]
            
            # Generate report card
            report_card = self.generate_student_report_card(
                student_info=student_info,
                term_data=term_data,
                school_info=school_info,
                template_type=template_type
            )
            
            report_cards.append(report_card)
        
        return report_cards
    
    def export_to_format(self, report_card: Dict[str, Any], format_type: str) -> str:
        """
        Export the generated report card to the specified format.
        
        Args:
            report_card: The report card content
            format_type: The desired output format ('pdf', 'docx', 'html')
            
        Returns:
            Path to the exported file
        """
        # In a production environment, this would convert to actual file formats
        # For now, we'll just return a placeholder
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        
        filename = f"report_card_{report_card['metadata']['student_name']}_{report_card['metadata']['term']}_{timestamp}.{format_type}"
        
        # In a real implementation, we would save the file here
        return f"../output/{filename}"
    
    # Helper methods for generating content
    
    def _calculate_overall_statistics(self, subjects: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate overall statistics from subject marks."""
        if not subjects:
            return {
                "total_marks": 0,
                "average_mark": 0,
                "average_grade": "N/A",
                "rank": "N/A",
                "out_of": "N/A"
            }
        
        # Extract marks
        marks = [subject["mark"] for subject in subjects]
        
        # Calculate statistics
        total_marks = sum(marks)
        average_mark = total_marks / len(marks) if marks else 0
        average_grade = self._calculate_grade(average_mark)
        
        return {
            "total_marks": total_marks,
            "average_mark": round(average_mark, 1),
            "average_grade": average_grade,
            "rank": "N/A",  # Would be calculated based on class data in a real implementation
            "out_of": "N/A"  # Would be calculated based on class data in a real implementation
        }
    
    def _generate_class_teacher_comment(self, student_info: Dict[str, Any], overall_stats: Dict[str, Any]) -> str:
        """Generate a class teacher comment based on overall performance."""
        student_name = student_info.get("name", "The student")
        average_mark = overall_stats.get("average_mark", 0)
        
        if average_mark >= 80:
            return f"{student_name} has demonstrated exceptional academic performance this term. Their dedication to learning and active participation in class activities are commendable. Keep up the excellent work!"
        elif average_mark >= 70:
            return f"{student_name} has performed well this term, showing good understanding across most subjects. With continued focus and effort, they have the potential to achieve even better results next term."
        elif average_mark >= 60:
            return f"{student_name} has shown satisfactory progress this term. While their performance is acceptable, there is room for improvement. More consistent study habits would help enhance their academic achievement."
        elif average_mark >= 50:
            return f"{student_name} has achieved the minimum passing standard this term. However, significant improvement is needed in several subjects. I recommend a more structured study routine and seeking help when facing difficulties."
        else:
            return f"{student_name} has struggled academically this term. Immediate intervention is necessary to address the challenges they are facing. I recommend a parent-teacher meeting to discuss strategies for improvement."
    
    def _generate_principal_comment(self, student_info: Dict[str, Any], overall_stats: Dict[str, Any]) -> str:
        """Generate a principal comment based on overall performance."""
        student_name = student_info.get("name", "The student")
        average_mark = overall_stats.get("average_mark", 0)
        
        if average_mark >= 80:
            return f"{student_name}'s outstanding academic performance reflects their commitment to excellence. The school is proud of their achievements and encourages them to maintain this high standard."
        elif average_mark >= 70:
            return f"{student_name} has demonstrated good academic potential this term. The school acknowledges their efforts and encourages them to strive for even greater achievements in the coming term."
        elif average_mark >= 60:
            return f"{student_name} has shown acceptable academic progress. The school encourages them to work more diligently to improve their performance in the next term."
        elif average_mark >= 50:
            return f"{student_name} needs to put in more effort to improve their academic performance. The school advises closer monitoring and support from parents to help them achieve better results."
        else:
            return f"{student_name} requires significant academic support. The school recommends an urgent intervention plan involving parents, teachers, and counselors to address their learning challenges."
    
    def _generate_subject_comment(self, subject: str, mark: float) -> str:
        """Generate a comment for a specific subject based on the mark."""
        if mark >= 90:
            return f"Excellent performance in {subject}. Shows exceptional understanding and application of concepts."
        elif mark >= 80:
            return f"Very good performance in {subject}. Demonstrates strong grasp of the subject material."
        elif mark >= 70:
            return f"Good performance in {subject}. Shows solid understanding with some areas for improvement."
        elif mark >= 60:
            return f"Satisfactory performance in {subject}. Understands basic concepts but needs to develop deeper understanding."
        elif mark >= 50:
            return f"Adequate performance in {subject}. Meets minimum requirements but needs significant improvement."
        else:
            return f"Below expected performance in {subject}. Requires immediate attention and support to improve understanding."
    
    def _calculate_grade(self, percentage: float) -> str:
        """Calculate grade based on percentage."""
        if percentage >= 90:
            return "A+"
        elif percentage >= 80:
            return "A"
        elif percentage >= 75:
            return "B+"
        elif percentage >= 70:
            return "B"
        elif percentage >= 65:
            return "C+"
        elif percentage >= 60:
            return "C"
        elif percentage >= 55:
            return "D+"
        elif percentage >= 50:
            return "D"
        else:
            return "F"
    
    def _get_grading_system(self, school_level: str) -> Dict[str, Dict[str, Any]]:
        """Get the grading system based on school level."""
        if school_level == "primary":
            return {
                "A+": {"range": "90-100", "description": "Outstanding"},
                "A": {"range": "80-89", "description": "Excellent"},
                "B+": {"range": "75-79", "description": "Very Good"},
                "B": {"range": "70-74", "description": "Good"},
                "C+": {"range": "65-69", "description": "Above Average"},
                "C": {"range": "60-64", "description": "Average"},
                "D+": {"range": "55-59", "description": "Below Average"},
                "D": {"range": "50-54", "description": "Poor"},
                "F": {"range": "0-49", "description": "Fail"}
         
(Content truncated due to size limit. Use line ranges to read in chunks)