"""
Assessment Tools & Auto-Marking Module for SMART TEACHER AI

This module helps teachers generate assessments such as tests and quizzes,
and provides auto-marking capabilities for multiple-choice questions.
"""

import os
import json
import random
import datetime
from typing import Dict, List, Any, Optional

class AssessmentTools:
    """
    Generates customized assessments and provides auto-marking capabilities.
    Integrates with AI models to create relevant and effective assessment materials.
    """
    
    def __init__(self, templates_dir: str = "../templates/assessments"):
        """
        Initialize the Assessment Tools.
        
        Args:
            templates_dir: Directory containing assessment templates
        """
        self.templates_dir = templates_dir
        self.question_bank = self._initialize_question_bank()
        
    def _initialize_question_bank(self) -> Dict:
        """Initialize a sample question bank for demonstration purposes."""
        # In a production environment, this would load from a database or API
        # For now, we'll use a placeholder with sample questions
        return {
            "primary": {
                "mathematics": {
                    "addition": [
                        {
                            "type": "multiple_choice",
                            "question": "What is 5 + 7?",
                            "options": ["10", "11", "12", "13"],
                            "correct_answer": "12",
                            "difficulty": "easy"
                        },
                        {
                            "type": "short_answer",
                            "question": "Calculate 15 + 23.",
                            "correct_answer": "38",
                            "difficulty": "medium"
                        }
                    ],
                    "subtraction": [
                        {
                            "type": "multiple_choice",
                            "question": "What is 15 - 7?",
                            "options": ["5", "7", "8", "10"],
                            "correct_answer": "8",
                            "difficulty": "easy"
                        },
                        {
                            "type": "short_answer",
                            "question": "Calculate 45 - 17.",
                            "correct_answer": "28",
                            "difficulty": "medium"
                        }
                    ]
                },
                "science": {
                    "plants": [
                        {
                            "type": "multiple_choice",
                            "question": "What do plants need to grow?",
                            "options": ["Only water", "Only sunlight", "Water, sunlight, and air", "Just soil"],
                            "correct_answer": "Water, sunlight, and air",
                            "difficulty": "easy"
                        },
                        {
                            "type": "true_false",
                            "question": "Plants make their own food through photosynthesis.",
                            "correct_answer": "True",
                            "difficulty": "medium"
                        }
                    ]
                }
            },
            "secondary": {
                "mathematics": {
                    "algebra": [
                        {
                            "type": "multiple_choice",
                            "question": "Solve for x: 2x + 5 = 13",
                            "options": ["x = 3", "x = 4", "x = 5", "x = 6"],
                            "correct_answer": "x = 4",
                            "difficulty": "medium"
                        },
                        {
                            "type": "short_answer",
                            "question": "Solve for x: 3x - 7 = 14",
                            "correct_answer": "x = 7",
                            "difficulty": "medium"
                        }
                    ],
                    "geometry": [
                        {
                            "type": "multiple_choice",
                            "question": "What is the formula for the area of a circle?",
                            "options": ["A = πr", "A = 2πr", "A = πr²", "A = 2πr²"],
                            "correct_answer": "A = πr²",
                            "difficulty": "medium"
                        },
                        {
                            "type": "short_answer",
                            "question": "Calculate the area of a circle with radius 5 cm. Use π = 3.14.",
                            "correct_answer": "78.5 cm²",
                            "difficulty": "hard"
                        }
                    ]
                },
                "biology": {
                    "photosynthesis": [
                        {
                            "type": "multiple_choice",
                            "question": "What is the primary pigment involved in photosynthesis?",
                            "options": ["Chlorophyll", "Melanin", "Carotene", "Xanthophyll"],
                            "correct_answer": "Chlorophyll",
                            "difficulty": "medium"
                        },
                        {
                            "type": "true_false",
                            "question": "Photosynthesis releases oxygen as a byproduct.",
                            "correct_answer": "True",
                            "difficulty": "easy"
                        },
                        {
                            "type": "essay",
                            "question": "Explain the light-dependent and light-independent reactions of photosynthesis.",
                            "marking_guide": "Student should describe both stages, including the role of chlorophyll, electron transport chain, ATP production, and Calvin cycle.",
                            "difficulty": "hard"
                        }
                    ],
                    "respiration": [
                        {
                            "type": "multiple_choice",
                            "question": "Which of the following is NOT a stage of cellular respiration?",
                            "options": ["Glycolysis", "Krebs cycle", "Photolysis", "Electron transport chain"],
                            "correct_answer": "Photolysis",
                            "difficulty": "hard"
                        },
                        {
                            "type": "short_answer",
                            "question": "What is the net ATP production from one glucose molecule during aerobic respiration?",
                            "correct_answer": "30-32 ATP",
                            "difficulty": "hard"
                        }
                    ]
                }
            }
        }
    
    def get_available_assessment_types(self) -> List[str]:
        """Return a list of available assessment types."""
        return ["Quiz", "Test", "Exam", "Homework", "Project"]
    
    def get_available_question_types(self) -> List[str]:
        """Return a list of available question types."""
        return ["multiple_choice", "true_false", "short_answer", "essay", "matching", "fill_in_blank"]
    
    def generate_assessment(self, 
                           subject: str, 
                           topic: str, 
                           class_level: str,
                           assessment_type: str = "Quiz",
                           difficulty: str = "medium",
                           num_questions: int = 10,
                           question_types: List[str] = None) -> Dict[str, Any]:
        """
        Generate an assessment based on provided parameters.
        
        Args:
            subject: Subject name (e.g., 'Mathematics', 'Biology')
            topic: Specific topic for the assessment
            class_level: Class level (e.g., 'Grade 3', 'Form 2')
            assessment_type: Type of assessment ('Quiz', 'Test', 'Exam', etc.)
            difficulty: Overall difficulty level ('easy', 'medium', 'hard', 'mixed')
            num_questions: Number of questions to include
            question_types: List of question types to include (if None, includes all types)
            
        Returns:
            Dictionary containing the generated assessment
        """
        # Determine education level (primary/secondary) from class_level
        if class_level.lower().startswith(('grade', 'std', 'standard')):
            level = 'primary'
        else:  # Assume secondary
            level = 'secondary'
        
        # Default to all question types if none specified
        if question_types is None:
            question_types = self.get_available_question_types()
        
        # Generate questions based on parameters
        questions = self._generate_questions(level, subject, topic, difficulty, num_questions, question_types)
        
        # Create the assessment structure
        assessment = {
            "metadata": {
                "subject": subject,
                "topic": topic,
                "class_level": class_level,
                "assessment_type": assessment_type,
                "difficulty": difficulty,
                "num_questions": len(questions),
                "date_generated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "title": f"{subject} {assessment_type}: {topic}",
            "instructions": self._generate_instructions(assessment_type),
            "time_allowed": self._calculate_time_allowed(assessment_type, num_questions),
            "total_marks": self._calculate_total_marks(questions),
            "questions": questions
        }
        
        return assessment
    
    def generate_answer_key(self, assessment: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate an answer key for the given assessment.
        
        Args:
            assessment: The assessment dictionary
            
        Returns:
            Dictionary containing the answer key
        """
        answer_key = {
            "metadata": {
                "subject": assessment["metadata"]["subject"],
                "topic": assessment["metadata"]["topic"],
                "class_level": assessment["metadata"]["class_level"],
                "assessment_type": assessment["metadata"]["assessment_type"],
                "date_generated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "title": f"Answer Key: {assessment['title']}",
            "answers": []
        }
        
        for i, question in enumerate(assessment["questions"]):
            answer = {
                "question_number": i + 1,
                "question_type": question["type"]
            }
            
            if question["type"] in ["multiple_choice", "true_false"]:
                answer["correct_answer"] = question["correct_answer"]
            elif question["type"] == "short_answer":
                answer["correct_answer"] = question["correct_answer"]
                answer["alternative_answers"] = question.get("alternative_answers", [])
            elif question["type"] == "essay":
                answer["marking_guide"] = question.get("marking_guide", "")
                answer["sample_answer"] = question.get("sample_answer", "")
            elif question["type"] == "matching":
                answer["correct_matches"] = question["correct_matches"]
            elif question["type"] == "fill_in_blank":
                answer["correct_answers"] = question["correct_answers"]
            
            answer["marks"] = question.get("marks", 1)
            answer_key["answers"].append(answer)
        
        return answer_key
    
    def auto_mark_assessment(self, assessment: Dict[str, Any], student_answers: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Automatically mark an assessment based on student answers.
        
        Args:
            assessment: The assessment dictionary
            student_answers: List of student answers, each containing question_number and answer
            
        Returns:
            Dictionary containing marking results
        """
        total_marks = assessment["total_marks"]
        earned_marks = 0
        question_results = []
        
        for answer in student_answers:
            question_number = answer["question_number"]
            student_response = answer["answer"]
            
            # Get the corresponding question from the assessment
            if question_number <= len(assessment["questions"]):
                question = assessment["questions"][question_number - 1]
                question_type = question["type"]
                marks_available = question.get("marks", 1)
                
                result = {
                    "question_number": question_number,
                    "question_type": question_type,
                    "marks_available": marks_available
                }
                
                # Mark based on question type
                if question_type == "multiple_choice" or question_type == "true_false":
                    correct = student_response == question["correct_answer"]
                    marks_earned = marks_available if correct else 0
                    result["correct"] = correct
                    result["marks_earned"] = marks_earned
                    result["correct_answer"] = question["correct_answer"]
                    
                elif question_type == "short_answer":
                    # Simple exact match for now
                    # In a real implementation, this would use more sophisticated matching
                    correct_answers = [question["correct_answer"]]
                    if "alternative_answers" in question:
                        correct_answers.extend(question["alternative_answers"])
                    
                    correct = any(student_response.lower().strip() == ans.lower().strip() for ans in correct_answers)
                    marks_earned = marks_available if correct else 0
                    result["correct"] = correct
                    result["marks_earned"] = marks_earned
                    result["correct_answer"] = question["correct_answer"]
                    
                elif question_type in ["essay", "fill_in_blank", "matching"]:
                    # These types require manual marking or more complex logic
                    result["requires_manual_marking"] = True
                    result["marks_earned"] = 0  # Placeholder until manually marked
                    
                earned_marks += result["marks_earned"]
                question_results.append(result)
        
        # Calculate percentage
        percentage = (earned_marks / total_marks) * 100 if total_marks > 0 else 0
        
        # Determine grade based on percentage
        grade = self._calculate_grade(percentage)
        
        marking_results = {
            "student_info": student_answers[0].get("student_info", {"name": "Student"}),
            "assessment_info": {
                "title": assessment["title"],
                "subject": assessment["metadata"]["subject"],
                "topic": assessment["metadata"]["topic"],
                "class_level": assessment["metadata"]["class_level"],
                "assessment_type": assessment["metadata"]["assessment_type"]
            },
            "marks": {
                "earned": earned_marks,
                "total": total_marks,
                "percentage": round(percentage, 1),
                "grade": grade
            },
            "question_results": question_results,
            "date_marked": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),

(Content truncated due to size limit. Use line ranges to read in chunks)