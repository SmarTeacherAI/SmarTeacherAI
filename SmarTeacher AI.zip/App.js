import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Layout Components
import Navbar from './components/layout/Navbar';
import Sidebar from './components/layout/Sidebar';
import Footer from './components/layout/Footer';

// Auth Components
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import ForgotPassword from './components/auth/ForgotPassword';

// Page Components
import Dashboard from './pages/Dashboard';
import LessonPlans from './pages/LessonPlans';
import TeachingMaterials from './pages/TeachingMaterials';
import Assessments from './pages/Assessments';
import EssayMarking from './pages/EssayMarking';
import Performance from './pages/Performance';
import Communication from './pages/Communication';
import ReportCards from './pages/ReportCards';
import Timetables from './pages/Timetables';
import Settings from './pages/Settings';
import Help from './pages/Help';
import NotFound from './pages/NotFound';

// Context
import { AuthProvider } from './context/AuthContext';
import { AlertProvider } from './context/AlertContext';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const isAuthenticated = localStorage.getItem('token') !== null;
  return isAuthenticated ? children : <Navigate to="/login" />;
};

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <Router>
      <AuthProvider>
        <AlertProvider>
          <div className="app-container">
            <Routes>
              {/* Auth Routes */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              
              {/* App Routes */}
              <Route path="/" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Dashboard />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/lesson-plans/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <LessonPlans />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/teaching-materials/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <TeachingMaterials />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/assessments/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Assessments />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/essay-marking/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <EssayMarking />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/performance/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Performance />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/communication/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Communication />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/report-cards/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <ReportCards />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/timetables/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Timetables />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/settings/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Settings />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              <Route path="/help/*" element={
                <ProtectedRoute>
                  <Navbar toggleSidebar={toggleSidebar} />
                  <div className="d-flex">
                    <Sidebar isOpen={sidebarOpen} />
                    <main className={`main-content ${sidebarOpen ? 'content-with-sidebar' : 'content-with-sidebar-collapsed'}`}>
                      <Help />
                      <Footer />
                    </main>
                  </div>
                </ProtectedRoute>
              } />
              
              {/* 404 Route */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </AlertProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
